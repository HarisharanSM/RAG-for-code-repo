# Release validation: 0.2.0

Authoring checks completed on 2026-10-01 using Python3.12.14/Linux and MCP SDK1.30.0. Version0.2.0 adds Windows execution support, portable path handling, AWS EC2/Docker configuration and platform CI.

## Completed evidence

- Final Linux suite: 50 tests ran in 9.170 seconds; 47 passed and 3 skipped. Skips: Docker runtime absent and two Windows-only alias/junction checks.
- Python source and tests compiled successfully with compileall.
- Real MCP stdio server/client discovery, source read and search passed.
- Local HTTP fake-model integration, real index, worktree patch and configured test execution passed. The original checkout stayed unchanged.
- Bounded output tests cover both pipes, paths/argv with spaces, descendant timeout cleanup, and a live parent with closed output handles.
- Windows backend routing and Job Object assignment-failure cleanup are explicitly mocked. They do not prove native Windows execution.
- Shared path tests cover Windows drives, ADS colons, reserved devices, .git case aliases, trailing dot/space aliases, traversal, and source exclusions. Native Windows case-insensitive file alias and junction tests are included for Windows CI.
- Deployment tests generated and loaded real TOML paths, created and patched a registered Git worktree and preserved the main checkout. CPU/private model service, mount namespace, numeric user and GPU override YAML were inspected.
- CI YAML parses and declares Windows/Linux/macOS, Python3.11/3.12 coverage and a Linux Docker build/config/CLI smoke job.
- The version0.2.0 wheel built and installed without dependencies in a clean virtual environment; its fixture command passed. Wheel Python modules match the source bytes.

## Pending runtime checks

Native Windows and macOS CI results have not been obtained yet. The authoring environment has no Docker executable or AWS instance; live Docker build/startup, EC2, SSH MCP and GPU inference remain unverified. The CI workflow is configured to run platform and Docker checks when published; configuration is not a passing run.

No actual Ollama model was available; generation and embedding integration used a fake loopback endpoint. Retrieval quality, model latency, C++/C# compilation, TypeScript execution and huge-repository performance were not established by these tests.

The language index remains heuristic. Refresh scans source bytes; vector search scans stored embeddings. Commands run with the caller's filesystem/network permissions. Neither Job Objects nor the current container setup constitutes a complete hostile-code sandbox.

## Agent execution

Windows implementation used Sol gpt-6.1-sol/high. AWS implementation used Sol gpt-6.1-sol/medium. The primary agent integrated, reviewed, configured CI and verified packaging. No escalation was used. Live token usage was unavailable; no measured cost or cache savings are claimed.
