# Module interfaces
Python 3.11+, standard-library core. Package src/repo_rag.
Config in config.py is authoritative. Config.load TOML paths relative to config file.
Indexer in index.py: Index(config), .index() -> dict stats, .search(query, limit=8, language=None) -> list[dict], .symbols(name) -> list[dict], .related(path) -> list[dict], .status() -> dict.
Search hits: path (repo-relative POSIX), start_line, end_line, text, language, score, optional symbol. Persistent SQLite; incremental freshness.
llm.py: OllamaClient(config).generate(prompt)->str, .embed(texts:list[str])->list[list[float]]. Validate localhost unless allow_remote_model. HTTP timeout.
workflow.py: Workflow(config).run(task, mode='analyze', limit=8)->dict with answer, sources, mode and optional patch. Modes analyze/review/develop; retrieval calls Index. Proposed patches never automatically apply.
execution.py: read_source(config,path,start_line=1,end_line=None)->dict; GitTools(config).status(), .diff(), .history(limit=10), .create_worktree()->str, .apply_patch(patch,worktree)->dict; Runner(config).run(name,worktree=None)->dict. Worktree patch application must validate paths, no shell invocation. Explicit configured commands only. Not an OS sandbox.
mcp_server.py: serve(config), official optional MCP SDK, stdio, structured tool functions. Do not expose automatic arbitrary shell or arbitrary writes; command execution and patch application gated explicit server flags if desired, default read-only.

## Dependency excerpt retrieval
Index.file_chunks(path, limit=4) -> list[dict] with normal search hit fields, stable source order. Used for dependency snippets without relying on filename lexical matching. Index.related records have path, target, kind, optional line/label/reason and resolved_path for a locally resolved opposite file. Workflows must distinguish incoming relationships (record.path differs from queried file) from outgoing imports.

## Platform execution

The _bounded_process result schema is unchanged across POSIX and Windows. Windows uses windows_process.py to assign a suspended process to a kill-on-close Job Object and drain pipes without selectors. Repository API paths remain forward-slash relative strings on every platform; native absolute paths are accepted for configuration and managed worktree handles. Source/patch admission rejects Windows drive and ADS syntax, device names, trailing dot/space aliases, and symlink/reparse aliases.
