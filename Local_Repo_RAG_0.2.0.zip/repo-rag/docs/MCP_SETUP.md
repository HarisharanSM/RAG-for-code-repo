# MCP stdio setup

The optional MCP server exposes repository search, source reads, symbol and relationship lookup, and Git status/diff/history. It uses stdio, so configure it in a compatible MCP host that can launch a local process.

Install the package with the MCP extra in the same Python environment the host will use:

```sh
python3 -m venv .venv
. .venv/bin/activate
python -m pip install '.[mcp]'
```

Create `repo-rag.toml` from the sample and set its `repo` to the target repository. For a reliable host launch, use absolute paths to both the virtual-environment Python executable and the TOML file. Example MCP server entry (adjust `/absolute/path/to/repo-rag`):

```json
{
  "mcpServers": {
    "repo-rag": {
      "command": "/absolute/path/to/repo-rag/.venv/bin/python",
      "args": [
        "-m",
        "repo_rag",
        "--config",
        "/absolute/path/to/repo-rag/repo-rag.toml",
        "mcp"
      ]
    }
  }
}
```

The package must also be installed into that interpreter's environment (editable install from the project root is fine). Do not use a shell wrapper; the host launches the executable with the listed arguments. MCP uses stdin/stdout for its protocol, so keep diagnostics on stderr.

Source and Git read tools are available by default; searches refresh the local index database. They do not expose repository patching or configured command execution. To expose configured command execution, add `--enable-execution` after `mcp`; it only runs names listed in `[commands]`. To expose worktree creation and patch application, add `--enable-writes`. These are independent opt-ins: `--enable-writes` does not enable command execution, and command execution does not enable writes. Example args with both enabled:

```json
"args": ["-m", "repo_rag", "--config", "/absolute/path/to/repo-rag/repo-rag.toml", "mcp", "--enable-execution", "--enable-writes"]
```

Treat execution as access to the configured command's ambient filesystem/network permissions. The runner bounds time and captured output but is not an OS sandbox. Use a restricted container or VM for untrusted code. Patch writes are limited to validated paths in a managed Git worktree.

The `source` and Git diff tools honor the source filename exclusions and omit the state directory. Git diff covers unstaged admitted files only; it does not expose excluded credential files. Files admitted by name may still contain sensitive data, so set project-specific exclusions and use a host you trust. Git tools require the configured repository to be the Git checkout root.

For Windows interpreter paths and AWS SSH stdio transport, use the platform-specific examples in [WINDOWS.md](WINDOWS.md) and [AWS.md](AWS.md).
