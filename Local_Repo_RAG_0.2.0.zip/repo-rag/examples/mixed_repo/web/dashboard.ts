export interface AxisPositionMessage {
  axis: string;
  position_mm: number;
}

export function formatAxisPosition(message: AxisPositionMessage): string {
  return `${message.axis}: ${message.position_mm.toFixed(2)} mm`;
}
