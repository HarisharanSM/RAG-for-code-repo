# Mixed-language axis contract fixture

`motion.cpp` publishes an axis update described by `axis_protocol.hpp`. `csharp/AxisConsumer.cs` and `web/dashboard.ts` illustrate consumers of the same JSON field names. This is a source-retrieval fixture, not a deployed transport or complete application. The cross-language connection is explicit in the example TOML link; imports alone do not infer it.

Run `python3 smoke_test.py` from this directory for a source-contract check. It does not compile C++/C# or execute TypeScript. For isolated patch application, initialize and commit this directory as its own Git checkout first, as shown in the main README.
