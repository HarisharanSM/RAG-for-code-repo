#pragma once

namespace telemetry {

// Wire contract consumed by the dashboard's axis-position handler.
struct AxisPosition {
    const char* axis;
    double position_mm;
};

}  // namespace telemetry
