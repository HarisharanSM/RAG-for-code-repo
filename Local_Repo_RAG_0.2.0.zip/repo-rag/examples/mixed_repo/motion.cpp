#include "axis_protocol.hpp"

namespace motion {

// The transport adapter serializes these fields as the dashboard's JSON message.
telemetry::AxisPosition publish_axis_position(const char* axis, double position_mm) {
    return telemetry::AxisPosition{axis, position_mm};
}

}  // namespace motion
