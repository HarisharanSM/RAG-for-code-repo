"""Source-level protocol smoke check; this does not compile native or C# code."""
from pathlib import Path
import re
import unittest

ROOT = Path(__file__).resolve().parent


class MixedLanguageProtocolSmokeTest(unittest.TestCase):
    def test_axis_position_fields_are_consistent(self):
        header = (ROOT / "axis_protocol.hpp").read_text(encoding="utf-8")
        motion = (ROOT / "motion.cpp").read_text(encoding="utf-8")
        csharp = (ROOT / "csharp" / "AxisConsumer.cs").read_text(encoding="utf-8")
        dashboard = (ROOT / "web" / "dashboard.ts").read_text(encoding="utf-8")

        self.assertRegex(header, r"const char\s*\*\s*axis\s*;")
        self.assertRegex(header, r"double\s+position_mm\s*;")
        self.assertIn('AxisPosition{axis, position_mm}', motion)
        self.assertRegex(csharp, r"record AxisPositionMessage\(string Axis, double PositionMm\)")
        self.assertRegex(dashboard, r"axis\s*:\s*string\s*;")
        self.assertRegex(dashboard, r"position_mm\s*:\s*number\s*;")
        self.assertIn("message.position_mm.toFixed(2)", dashboard)

        wire_fields = set(re.findall(r"\b(axis|position_mm)\b", header))
        self.assertEqual(wire_fields, {"axis", "position_mm"})


if __name__ == "__main__":
    unittest.main()
