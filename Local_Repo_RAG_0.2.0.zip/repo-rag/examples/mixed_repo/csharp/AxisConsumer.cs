namespace MixedRepo.Consumer;

// Illustrates a second consumer that maps the same wire fields into a C# record.
public sealed record AxisPositionMessage(string Axis, double PositionMm);
