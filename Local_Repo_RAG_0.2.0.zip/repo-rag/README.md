# Local Repo RAG

Local Repo RAG indexes a repository into SQLite, retrieves source excerpts with line citations, and can ask a local Ollama model for an analysis, review, or proposed unified diff. It is a Python 3.11+ CLI with an optional MCP stdio server.

The `examples/mixed_repo/` fixture demonstrates an explicit C++ to TypeScript relationship that ordinary import scanning cannot discover. Its Python smoke check validates the shared message contract by inspecting source text; it does not compile the C++ or C# samples.

## Install

Install Git and Python 3.11 or newer. The commands below are for macOS/Linux; use the PowerShell instructions in [docs/WINDOWS.md](docs/WINDOWS.md) on Windows. Windows, Linux and macOS are covered by the platform CI workflow; see validation evidence for actual completed runs.

```sh
python3 --version
python3 -m venv .venv
. .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install '.[mcp]'
```

For a core-only install without fetching runtime or build dependencies, the archive also includes a wheel:

```sh
python -m pip install --no-deps wheelhouse/local_repo_rag-0.2.0-py3-none-any.whl
```

The core CLI has no third-party runtime dependencies. The `mcp` extra installs the official MCP Python SDK for MCP support.

## Configure and index

From the project root, make a working copy of the sample configuration:

```sh
cp repo-rag.example.toml repo-rag.toml
```

The example points `repo` at `examples/mixed_repo`. TOML `repo` and `state_dir` paths are resolved relative to the configuration file. Edit those values to use a different repository and state directory. The state directory holds the SQLite index and managed worktrees; keep it out of source control.

```sh
repo-rag --config repo-rag.toml index
repo-rag --config repo-rag.toml status
repo-rag --config repo-rag.toml search 'axis position update' --limit 5
repo-rag --config repo-rag.toml related motion.cpp
```

`index` incrementally refreshes indexed files. Search uses SQLite keyword retrieval when `embedding_model` is empty. It does not contact Ollama in that configuration. Semantic retrieval requires a locally available embedding model configured separately; Ollama model names and resource needs vary, so retrieval quality and speed depend on the selected model and machine.

## Optional local model

Analysis, review, and develop workflows call Ollama's local HTTP API. Install Ollama using its official instructions, start its service, and pull a model that your machine can run. For example:

```sh
ollama pull qwen2.5-coder:7b
```

The sample config uses `http://127.0.0.1:11434` and `qwen2.5-coder:7b`; change `model` to another installed generation model if needed. To enable semantic retrieval, set `embedding_model` to an installed embedding model you have pulled, for example an appropriate `nomic-embed-text` tag, and pull that exact tag. Model choice is configurable; no hardware or response-time guarantee is implied. Keep `allow_remote_model = false` for localhost-only model access unless you have a deliberate reason to use a remote endpoint.

Without a reachable Ollama service, `index`, `status`, and `search` remain usable in keyword-only mode. The analysis/review/develop commands require a reachable configured generation endpoint. Tests use mocks and do not require a live Ollama service or download model weights.

## Analyze and propose changes

```sh
repo-rag --config repo-rag.toml analyze 'Where is axis position published and consumed?'
repo-rag --config repo-rag.toml review 'Check axis position handling for concrete defects'
repo-rag --config repo-rag.toml develop 'Add validation for invalid axis positions' --output /tmp/repo-rag-result.json
```

The JSON result includes the answer, source excerpts, and mode. A `develop` result may include a `patch` field only when a plausible unified diff can be extracted from the model response. The workflow only proposes changes; it does not apply them. Inspect a patch before applying it.

## Run the fixture command

The example config includes a named `smoke` command. Runner commands are explicit argv arrays and do not invoke a shell implicitly.

```sh
repo-rag --config repo-rag.toml run smoke
```

The smoke check is a lightweight protocol example, not a build or compiler test. For real projects, configure commands appropriate to that repository and review their effects: configured build scripts can access the filesystem and network available to the user.

## Worktree and patch flow

Git worktrees are detached from a committed baseline. Commit the current fixture or project files before creating one; tracked uncommitted changes cause worktree creation to fail. Untracked files are not included in the new worktree, so commit new files as part of the baseline too.

```sh
git -C examples/mixed_repo init
git -C examples/mixed_repo status --short
git -C examples/mixed_repo add .
git -C examples/mixed_repo commit -m 'Create mixed-language fixture baseline'
repo-rag --config repo-rag.toml worktree
```

The command prints the managed worktree path. `apply` requires that path, validates the patch paths, checks applicability, then applies only in that worktree. If a result contains a patch, extract it to a patch file and inspect it before applying. This example uses Python's JSON parser to avoid copying answer prose by mistake:

```sh
python - <<'PY'
import json
from pathlib import Path
result = json.loads(Path('/tmp/repo-rag-result.json').read_text())
patch = result.get('patch')
if not patch:
    raise SystemExit('The model response did not contain an extractable unified diff.')
Path('/tmp/repo-rag.patch').write_text(patch)
print(patch)
PY
repo-rag --config repo-rag.toml apply /tmp/repo-rag.patch --worktree /absolute/path/printed/by/worktree
repo-rag --config repo-rag.toml run smoke --worktree /absolute/path/printed/by/worktree
```

Replace the example worktree path with the actual path printed by the `worktree` command. Review `git -C /absolute/path/to/worktree diff` and test results before deciding what to keep. Applying a patch or running a command is an explicit user-invoked step. These controls reduce accidental writes but are not an operating-system sandbox; use a restricted container or VM for untrusted repositories.

## MCP

See [docs/MCP_SETUP.md](docs/MCP_SETUP.md) for stdio host setup. MCP exposes source and Git read tools by default; indexing may update its state database, while command execution and patch/worktree tools require explicit flags.

## More detail

- [Architecture and boundaries](docs/ARCHITECTURE.md)
- [Shared module contract](docs/CONTRACT.md)

## Verify installation

```sh
python -m unittest discover -s tests -v
```

See [validation evidence](docs/VALIDATION.md) for the checks run on this release. Source exclusions are filename rules rather than content-based secret detection; configure `excludes` for project-specific confidential files. Git tools require `repo` to be the checkout root.

## Windows and AWS

- [Windows setup and process behavior](docs/WINDOWS.md)
- [AWS EC2 / Docker setup and persistent storage](docs/AWS.md)

The AWS deployment files configure an EC2-hosted checkout and model service. They do not create an EC2 instance or upload the repository from your PC automatically.
