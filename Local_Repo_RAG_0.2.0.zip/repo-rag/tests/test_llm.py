import io
import json
import tempfile
import threading
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.error import URLError

from repo_rag.config import Config
from repo_rag.llm import OllamaClient, OllamaError


class FakeOpener:
    def __init__(self, response):
        self.response = response
        self.calls = []

    def open(self, req, timeout):
        self.calls.append((req, timeout))
        if isinstance(self.response, Exception):
            raise self.response
        return io.BytesIO(json.dumps(self.response).encode("utf-8"))


class OllamaClientTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        root = Path(self.temp.name)
        self.config = Config(repo=root, state_dir=root / "state", timeout=7,
                             embedding_model="embed-model")

    def test_generate_posts_nonstreaming_with_timeout(self):
        client = OllamaClient(self.config)
        client._opener = fake = FakeOpener({"response": "Answer"})
        self.assertEqual(client.generate("question"), "Answer")
        req, timeout = fake.calls[0]
        self.assertEqual(req.full_url, "http://127.0.0.1:11434/api/generate")
        self.assertEqual(timeout, 7)
        self.assertEqual(json.loads(req.data), {
            "model": self.config.model, "prompt": "question", "stream": False,
        })

    def test_embed_uses_embedding_model_and_validates_shape(self):
        client = OllamaClient(self.config)
        client._opener = fake = FakeOpener({"embeddings": [[1, 2], [3, 4.5]]})
        self.assertEqual(client.embed(["a", "b"]), [[1.0, 2.0], [3.0, 4.5]])
        self.assertEqual(json.loads(fake.calls[0][0].data), {
            "model": "embed-model", "input": ["a", "b"],
        })
        self.assertEqual(client.embed([]), [])
        self.assertEqual(len(fake.calls), 1)
        fake.response = {"embeddings": [[float("nan")]]}
        with self.assertRaises(OllamaError):
            client.embed(["a"])

    def test_rejects_nonloopback_and_credentials_by_default(self):
        for url in ("http://example.com:11434", "http://192.0.2.1:11434",
                    "http://user:pass@127.0.0.1:11434", "http://localhost:11434/x"):
            with self.subTest(url=url), self.assertRaises(ValueError):
                OllamaClient(Config(repo=self.config.repo, state_dir=self.config.state_dir,
                                    llm_url=url))
        self.config.llm_url = "http://example.com:11434"
        self.config.allow_remote_model = True
        self.assertEqual(OllamaClient(self.config).base_url, self.config.llm_url)

    def test_connection_and_protocol_errors_are_explicit(self):
        client = OllamaClient(self.config)
        client._opener = FakeOpener(URLError("offline"))
        with self.assertRaisesRegex(OllamaError, "Could not reach Ollama"):
            client.generate("hello")
        client._opener = FakeOpener({"error": "model unavailable"})
        with self.assertRaisesRegex(OllamaError, "model unavailable"):
            client.generate("hello")
        client._opener = FakeOpener({"embeddings": [[1], [1, 2]]})
        with self.assertRaisesRegex(OllamaError, "dimensions"):
            client.embed(["a", "b"])

    def test_real_loopback_transport_with_fake_model_endpoint(self):
        received = []

        class Handler(BaseHTTPRequestHandler):
            def do_POST(self):
                length = int(self.headers["Content-Length"])
                received.append((self.path, json.loads(self.rfile.read(length))))
                response = ({"response": "fake answer"} if self.path == "/api/generate"
                            else {"embeddings": [[0.25, 0.5]]})
                body = json.dumps(response).encode()
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)

            def log_message(self, *args):
                pass

        server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        self.addCleanup(thread.join, 2)
        self.addCleanup(server.server_close)
        self.addCleanup(server.shutdown)
        self.config.llm_url = f"http://127.0.0.1:{server.server_port}"
        client = OllamaClient(self.config)
        self.assertEqual(client.generate("prompt"), "fake answer")
        self.assertEqual(client.embed(["text"]), [[0.25, 0.5]])
        self.assertEqual([path for path, _ in received], ["/api/generate", "/api/embed"])


if __name__ == "__main__":
    unittest.main()
