import asyncio
import importlib.util
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

from repo_rag.config import Config
from repo_rag.mcp_server import build_server


@unittest.skipUnless(importlib.util.find_spec("mcp"), "optional MCP SDK is unavailable")
class MCPTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.repo = self.root / "repo"
        self.repo.mkdir()
        subprocess.run(["git", "init", "-q"], cwd=self.repo, check=True)
        (self.repo / "main.py").write_text("def greet():\n    return 'hello'\n")
        self.config = Config(repo=self.repo, state_dir=self.root / "state")

    def test_tool_gates(self):
        async def names(server):
            return {tool.name for tool in await server.list_tools()}

        default = asyncio.run(names(build_server(self.config)))
        self.assertEqual(default, {"search", "source", "symbols", "related",
                                   "git_status", "git_diff", "git_history"})
        execution = asyncio.run(names(build_server(self.config, enable_execution=True)))
        self.assertEqual(execution - default, {"run_command"})
        writes = asyncio.run(names(build_server(self.config, enable_writes=True)))
        self.assertEqual(writes - default, {"create_worktree", "apply_patch"})

    def test_real_sdk_stdio_roundtrip(self):
        from mcp import ClientSession, StdioServerParameters
        from mcp.client.stdio import stdio_client

        config_file = self.root / "repo-rag.toml"
        config_file.write_text('repo = "repo"\nstate_dir = "state"\n')
        project = Path(__file__).resolve().parents[1]
        env = dict(os.environ, PYTHONPATH=str(project / "src"))
        params = StdioServerParameters(command=sys.executable,
                                       args=["-m", "repo_rag", "--config", str(config_file), "mcp"],
                                       env=env)

        async def roundtrip():
            async with stdio_client(params) as (reader, writer):
                async with ClientSession(reader, writer) as session:
                    await session.initialize()
                    tool_names = {tool.name for tool in (await session.list_tools()).tools}
                    self.assertIn("source", tool_names)
                    self.assertNotIn("apply_patch", tool_names)
                    result = await session.call_tool("source", {"path": "main.py", "start_line": 1, "end_line": 1})
                    self.assertFalse(result.isError, result)
                    self.assertIn("def greet():", str(result.content))
                    search = await session.call_tool("search", {"query": "greet"})
                    self.assertFalse(search.isError, search)
                    self.assertIn("main.py", str(search.content))

        asyncio.run(roundtrip())


if __name__ == "__main__":
    unittest.main()
