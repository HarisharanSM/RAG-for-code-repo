from pathlib import Path
import os
import sys
import time
import subprocess
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import Mock, patch

from repo_rag.config import Config
from repo_rag.execution import GitTools, Runner, _bounded_process, read_source


def git(cwd, *args):
    return subprocess.run(["git", *args], cwd=cwd, check=True, capture_output=True, text=True).stdout


class ExecutionTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.repo = self.root / "repo with spaces"
        self.repo.mkdir()
        git(self.repo, "init", "-q")
        git(self.repo, "config", "user.email", "test@example.test")
        git(self.repo, "config", "user.name", "Test")
        git(self.repo, "config", "core.autocrlf", "false")
        (self.repo / "a.txt").write_bytes(b"one\ntwo\n")
        git(self.repo, "add", "a.txt")
        git(self.repo, "commit", "-qm", "initial")
        self.config = Config(repo=self.repo, state_dir=self.root / "state", timeout=2)

    def test_source_rejects_escape_symlink_and_large_files(self):
        self.assertEqual(read_source(self.config, "a.txt", 2, 2)["text"], "two\n")
        self.assertEqual(read_source(self.config, "a.txt", 1, 99)["end_line"], 2)
        for start in (3, 99):
            with self.assertRaisesRegex(ValueError, "line count"):
                read_source(self.config, "a.txt", start)
        (self.repo / "empty.py").write_text("")
        with self.assertRaisesRegex(ValueError, "line count"):
            read_source(self.config, "empty.py")
        for value in ("../outside", "/etc/passwd", "a/../a.txt", ".git/config", ".GIT/config",
                      "sub/.GiT/config", ".git./config", ".git /config", "NUL.py", "CON/file.py", "C:/outside",
                      "C:outside", "a.txt:stream", "a\\b"):
            with self.subTest(value=value), self.assertRaises(ValueError):
                read_source(self.config, value)
        self.config.max_file_bytes = 2
        with self.assertRaises(ValueError):
            read_source(self.config, "a.txt")

    def test_source_follows_index_admission_and_rejects_aliases(self):
        (self.repo / ".env").write_text("SECRET=1\n")
        (self.repo / "credentials.json").write_text('{"token":"secret"}')
        (self.repo / "secret.py").write_text("secret = 1\n")
        (self.repo / "ignored.py").write_text("ignored = 1\n")
        (self.repo / "tracked_ignored.py").write_text("def kept():\n    pass\n")
        (self.repo / ".gitignore").write_text("ignored.py\ntracked_ignored.py\n")
        git(self.repo, "add", "-f", "tracked_ignored.py")
        (self.repo / "generated").mkdir()
        (self.repo / "generated" / "module.py").write_text("pass\n")
        self.config.excludes = ["secret.py"]
        for name in (".env", "credentials.json", "secret.py", "ignored.py", "generated/module.py"):
            with self.subTest(name=name), self.assertRaises(ValueError):
                read_source(self.config, name)
        self.assertIn("def kept():", read_source(self.config, "tracked_ignored.py")["text"])
        from repo_rag.index import Index
        index = Index(self.config)
        index.index()
        self.assertTrue(any(hit["path"] == "tracked_ignored.py" for hit in index.search("kept")))

        state = self.repo / "custom-state"
        state.mkdir()
        (state / "record.py").write_text("secret = 2\n")
        self.config.state_dir = state
        with self.assertRaises(ValueError):
            read_source(self.config, "custom-state/record.py")

    def test_source_rejects_symlinks(self):
        state = self.repo / "custom-state"
        state.mkdir()
        (state / "record.py").write_text("secret = 2\n")
        try:
            (self.repo / "alias.py").symlink_to(self.repo / "a.txt")
        except OSError as exc:
            self.skipTest(f"Symlink creation unavailable: {exc}")
        with self.assertRaises(ValueError):
            read_source(self.config, "alias.py")
        (self.repo / "link-dir").symlink_to(state, target_is_directory=True)
        with self.assertRaises(ValueError):
            read_source(self.config, "link-dir/record.py")

    def test_git_tools_refuse_configured_subdirectory(self):
        child = self.repo / "child"
        child.mkdir()
        inner = Config(repo=child, state_dir=self.root / "inner-state", timeout=2)
        with self.assertRaisesRegex(ValueError, "Git checkout root"):
            GitTools(inner).status()
        with self.assertRaisesRegex(ValueError, "Git checkout root"):
            GitTools(inner).create_worktree()

    def test_git_and_managed_patch(self):
        tools = GitTools(self.config)
        self.assertEqual(tools.status()["returncode"], 0)
        self.assertIn("initial", tools.history()["stdout"])
        worktree = tools.create_worktree()
        patch = "diff --git a/a.txt b/a.txt\n--- a/a.txt\n+++ b/a.txt\n@@ -1,2 +1,2 @@\n-one\n+changed\n two\n"
        result = tools.apply_patch(patch, worktree)
        self.assertTrue(result["applied"], result)
        self.assertEqual((Path(worktree) / "a.txt").read_text(), "changed\ntwo\n")
        self.assertEqual((self.repo / "a.txt").read_text(), "one\ntwo\n")
        with self.assertRaises(ValueError):
            tools.apply_patch(patch, str(self.repo))

    def test_git_diff_excludes_tracked_secrets_and_state(self):
        (self.repo / ".env").write_text("SECRET=old\n")
        (self.repo / "main.py").write_text("value = 1\n")
        state = self.repo / "custom-state"
        state.mkdir()
        (state / "internal.py").write_text("token = 'old'\n")
        self.config.state_dir = state
        git(self.repo, "add", ".env", "main.py", "custom-state/internal.py")
        git(self.repo, "commit", "-qm", "tracked sources")
        (self.repo / ".env").write_text("SECRET=do-not-leak\n")
        (self.repo / "main.py").write_text("value = 2\n")
        (state / "internal.py").write_text("token = 'do-not-leak'\n")
        diff = GitTools(self.config).diff()
        self.assertIn("value = 2", diff["stdout"])
        self.assertNotIn("SECRET", diff["stdout"])
        self.assertNotIn("do-not-leak", diff["stdout"])
        self.assertNotIn("internal.py", diff["stdout"])

    def test_patch_rejects_traversal_symlinks_special_and_binary(self):
        tools = GitTools(self.config)
        worktree = tools.create_worktree()
        snippets = [
            "diff --git a/../x b/../x\n--- a/../x\n+++ b/../x\n",
            "diff --git a/C:/x b/C:/x\n--- a/C:/x\n+++ b/C:/x\n",
            "diff --git a/.GIT/config b/.GIT/config\n--- a/.GIT/config\n+++ b/.GIT/config\n",
            "--- a/.git./config\n+++ b/.git./config\n",
            "--- a/NUL.py\n+++ b/NUL.py\n",
            "--- a/x:stream\n+++ b/x:stream\n",
            "diff --git a/x b/x\nnew file mode 120000\n",
            "diff --git a/x b/x\nGIT binary patch\n",
            "diff --git a/x b/x\nrename to x\n",
        ]
        for patch in snippets:
            with self.subTest(patch=patch), self.assertRaises(ValueError):
                tools.apply_patch(patch, worktree)

    def test_patch_rejects_symlink(self):
        tools = GitTools(self.config)
        worktree = tools.create_worktree()
        try:
            (Path(worktree) / "link").symlink_to(self.root / "outside")
        except OSError as exc:
            self.skipTest(f"Symlink creation unavailable: {exc}")
        with self.assertRaises(ValueError):
            tools.apply_patch("--- a/link\n+++ b/link\n", worktree)

    def test_plain_unified_diff_and_dirty_baseline(self):
        tools = GitTools(self.config)
        worktree = tools.create_worktree()
        patch = "--- a/a.txt\n+++ b/a.txt\n@@ -1,2 +1,2 @@\n-one\n+plain\n two\n"
        self.assertTrue(tools.apply_patch(patch, worktree)["applied"])
        (self.repo / "a.txt").write_text("dirty\n")
        with self.assertRaises(ValueError):
            tools.create_worktree()

    def test_patch_hunk_source_lines_resembling_file_headers(self):
        (self.repo / "counter.cpp").write_bytes(b"-- value;\n")
        git(self.repo, "add", "counter.cpp")
        git(self.repo, "commit", "-qm", "counter")
        tools = GitTools(self.config)
        worktree = tools.create_worktree()
        patch = "--- a/counter.cpp\n+++ b/counter.cpp\n@@ -1 +1 @@\n--- value;\n+++ value;\n"
        result = tools.apply_patch(patch, worktree)
        self.assertTrue(result["applied"], result)
        self.assertEqual((Path(worktree) / "counter.cpp").read_text(), "++ value;\n")

    def test_binary_and_invalid_utf8_are_not_source(self):
        (self.repo / "nul.py").write_bytes(b"x = 1\x00\n")
        (self.repo / "invalid.py").write_bytes(b"x = \xff\n")
        for name in ("nul.py", "invalid.py"):
            with self.subTest(name=name), self.assertRaises(ValueError):
                read_source(self.config, name)

    def test_runner_configured_argv_timeout_and_output(self):
        self.config.commands = {
            "ok": [sys.executable, "-c", "print('hello')"],
            "large": [sys.executable, "-c", "print('x'*100000)"],
            "slow": [sys.executable, "-c", "import time; time.sleep(30)"],
        }
        runner = Runner(self.config)
        self.assertEqual(runner.run("ok")["stdout"].replace("\r\n", "\n"), "hello\n")
        with self.assertRaises(ValueError):
            runner.run("unconfigured")
        large = runner.run("large")
        self.assertTrue(large["stdout_truncated"])
        self.assertLessEqual(len(large["stdout"].encode()), 65536)
        slow = runner.run("slow")
        self.assertTrue(slow["timed_out"])
        self.assertNotEqual(slow["returncode"], 0)

    def test_unsupported_platform_is_explicit(self):
        with patch("repo_rag.execution.os", new=SimpleNamespace(name="unsupported")):
            with self.assertRaisesRegex(RuntimeError, "Windows Job Objects or POSIX"):
                _bounded_process(["echo", "not-run"], self.repo, 1)

    def test_windows_backend_dispatch_is_mocked_only(self):
        expected = {"mocked": True}
        with patch("repo_rag.execution.os", new=SimpleNamespace(name="nt")), \
                patch("repo_rag.windows_process.bounded_process", return_value=expected) as backend:
            self.assertIs(_bounded_process(["command", "one argument"], self.repo, 1), expected)
            backend.assert_called_once_with(["command", "one argument"], self.repo, 1, None, 65536)

    def test_both_output_pipes_are_bounded_and_argv_preserves_spaces(self):
        result = _bounded_process([sys.executable, "-c",
            "import os,sys; assert sys.argv[1]=='one argument'; "
            "assert 'repo with spaces' in os.getcwd(); "
            "os.write(1,b'x'*200000); os.write(2,b'y'*200000)", "one argument"], self.repo, 5)
        self.assertEqual(result["returncode"], 0, result)
        self.assertFalse(result["timed_out"])
        for name in ("stdout", "stderr"):
            self.assertEqual(len(result[name]), 65536)
            self.assertTrue(result[name + "_truncated"])

    def test_timeout_terminates_descendant_with_inherited_pipes(self):
        marker = self.root / "surviving child.txt"
        child = "import pathlib,time; time.sleep(2); pathlib.Path(%r).write_text('escaped')" % str(marker)
        parent = "import subprocess,sys; subprocess.Popen([sys.executable,'-c',%r]); print('ready',flush=True)" % child
        started = time.monotonic()
        result = _bounded_process([sys.executable, "-c", parent], self.repo, 1)
        self.assertTrue(result["timed_out"], result)
        self.assertIn("ready", result["stdout"])
        self.assertLess(time.monotonic() - started, 4)
        time.sleep(2.2)
        self.assertFalse(marker.exists(), "Timeout left a descendant running")

    def test_process_without_open_output_pipes_still_times_out(self):
        result = _bounded_process([sys.executable, "-c",
            "import os,time; os.close(1); os.close(2); time.sleep(30)"], self.repo, 1)
        self.assertTrue(result["timed_out"], result)
        self.assertNotEqual(result["returncode"], 0)

    def test_source_preserves_crlf_and_utf8(self):
        (self.repo / "utf8.py").write_bytes("value = 'é'\r\n".encode("utf-8"))
        self.assertEqual(read_source(self.config, "utf8.py")["text"], "value = 'é'\r\n")

    @unittest.skipUnless(os.name == "nt", "Native Windows case-insensitive filesystem required")
    def test_source_rejects_case_alias_of_configured_exclusion(self):
        (self.repo / "excluded.py").write_text("secret = 1\n")
        self.config.excludes = ["excluded.py"]
        with self.assertRaisesRegex(ValueError, "excluded"):
            read_source(self.config, "EXCLUDED.py")

    @unittest.skipUnless(os.name == "nt", "Native Windows junction required")
    def test_source_and_patch_reject_junction_aliases(self):
        target = self.repo / "real"
        target.mkdir()
        (target / "code.py").write_text("secret = 1\n")
        alias = self.repo / "alias"
        created = subprocess.run(["cmd.exe", "/d", "/c", "mklink", "/J", str(alias), str(target)],
                                 capture_output=True)
        if created.returncode:
            self.skipTest("Junction creation unavailable")
        self.addCleanup(lambda: alias.rmdir() if alias.exists() else None)
        with self.assertRaises(ValueError):
            read_source(self.config, "alias/code.py")
        from repo_rag.execution import _validate_patch
        with self.assertRaises(ValueError):
            _validate_patch("--- a/alias/code.py\n+++ b/alias/code.py\n", self.repo)

    def test_windows_job_assignment_failure_never_resumes_command_mocked(self):
        from repo_rag.windows_process import _Job
        job = _Job.__new__(_Job)
        job.handle = 10
        job.kernel = Mock()
        job.kernel.OpenProcess.return_value = 20
        job.kernel.AssignProcessToJobObject.return_value = False
        process = Mock()
        with patch("repo_rag.windows_process.subprocess.Popen", return_value=process), \
                patch("repo_rag.windows_process._winerror", return_value=OSError("job denied")), \
                patch.object(job, "_resume") as resume:
            with self.assertRaisesRegex(OSError, "job denied"):
                job.start(["not-run"], self.repo, subprocess.DEVNULL)
            resume.assert_not_called()
            process.kill.assert_called_once()
            process.wait.assert_called_once()
            process.stdout.close.assert_called_once()
            process.stderr.close.assert_called_once()


if __name__ == "__main__":
    unittest.main()
