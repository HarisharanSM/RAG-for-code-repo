"""End-to-end transports and patch execution with a fake local model, not real inference."""
import json
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import subprocess
import sys
import tempfile
import threading
import unittest
from repo_rag.config import Config
from repo_rag.execution import GitTools, Runner
from repo_rag.index import Index
from repo_rag.workflow import Workflow

PATCH = '''diff --git a/main.py b/main.py
--- a/main.py
+++ b/main.py
@@ -1,2 +1,2 @@
 def axis_position():
-    return 1
+    return 2
'''

class IntegrationTests(unittest.TestCase):
    def test_local_http_retrieval_to_reviewed_worktree_and_execution(self):
        class FakeModel(BaseHTTPRequestHandler):
            def log_message(self, *args): pass
            def do_POST(self):
                payload=json.loads(self.rfile.read(int(self.headers['Content-Length'])))
                if self.path=='/api/embed':
                    result={'embeddings':[[1.0, 0.5] for _ in payload['input']]}
                elif self.path=='/api/generate':
                    result={'response':'Change axis_position [main.py:1-2].\n```diff\n'+PATCH+'```'}
                else:
                    self.send_error(404); return
                body=json.dumps(result).encode()
                self.send_response(200); self.send_header('Content-Type','application/json')
                self.send_header('Content-Length',str(len(body))); self.end_headers(); self.wfile.write(body)
        server=ThreadingHTTPServer(('127.0.0.1',0),FakeModel)
        threading.Thread(target=server.serve_forever,daemon=True).start()
        self.addCleanup(server.server_close); self.addCleanup(server.shutdown)
        with tempfile.TemporaryDirectory() as d:
            root=Path(d); repo=root/'repo with spaces'; repo.mkdir()
            (repo/'main.py').write_bytes(b'def axis_position():\n    return 1\n')
            (repo/'axis.hpp').write_text('int axis_position();\n')
            def git(*args):
                return subprocess.run(['git',*args],cwd=repo,check=True,capture_output=True)
            git('init','-q'); git('config','core.autocrlf','false'); git('add','.'); git('-c','user.name=Test','-c','user.email=test@example.invalid','commit','-qm','baseline')
            cfg=Config(repo=repo,state_dir=root/'state',llm_url=f'http://127.0.0.1:{server.server_port}',embedding_model='fake-embedding',
                       commands={'verify':[sys.executable,'-c','from main import axis_position; assert axis_position() == 2']},
                       links=[{'source':'main.py','target':'axis.hpp','label':'native contract'}])
            stats=Index(cfg).index(); self.assertGreater(stats['embedded'],0)
            result=Workflow(cfg).run('Change axis_position to return 2','develop')
            self.assertEqual(result['patch'],PATCH)
            self.assertIn('main.py',{x['path'] for x in result['sources']})
            self.assertIn('axis.hpp',{x['path'] for x in result['sources']})
            self.assertIn('return 1',(repo/'main.py').read_text())
            tools=GitTools(cfg); worktree=tools.create_worktree()
            applied=tools.apply_patch(result['patch'],worktree); self.assertTrue(applied['applied'],applied)
            executed=Runner(cfg).run('verify',worktree); self.assertEqual(executed['returncode'],0,executed)
            self.assertIn('return 1',(repo/'main.py').read_text())
            self.assertIn('return 2',(Path(worktree)/'main.py').read_text())
            changed=tools.diff(); self.assertEqual(changed['stdout'],'')

if __name__=='__main__': unittest.main()
