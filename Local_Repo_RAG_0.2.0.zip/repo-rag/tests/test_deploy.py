"""Exercise deployment configuration with the application's real path contract."""
import importlib.util
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest
from unittest.mock import patch

from repo_rag.config import Config
from repo_rag.execution import GitTools


ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location('deployment_configure', ROOT / 'deploy/configure.py')
SETUP = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(SETUP)


@unittest.skipUnless(shutil.which('git'), 'Git required')
@unittest.skipUnless(os.name == 'posix', 'Deployment setup targets POSIX Linux hosts')
class DeploymentTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.base = Path(self.temp.name)
        self.repo = self.base / "checkout with $ and ' spaces"
        self.repo.mkdir()
        self.state = self.base / 'persistent state'
        self.output = self.base / 'deploy'
        self.git('init', '-q')
        self.git('config', 'user.email', 'fixture@example.invalid')
        self.git('config', 'user.name', 'Fixture')
        (self.repo / 'main.py').write_text('value = 1\n')
        self.git('add', '.')
        self.git('commit', '-qm', 'baseline')

    def git(self, *args):
        return subprocess.check_output(['git', '-C', str(self.repo), *args], text=True)

    def configure(self, state=None, repo=None):
        # CI may run as root; production setup still rejects root explicitly.
        with patch.object(SETUP.os, 'getuid', return_value=1000), patch.object(SETUP.os, 'getgid', return_value=1000):
            SETUP.configure(repo or self.repo, state or self.state, self.output,
                            'ollama/ollama:operator-selected', 'qwen2.5-coder:7b')

    def test_generated_config_supports_registered_worktree_and_patch(self):
        self.configure()
        cfg = Config.load(self.output / 'repo-rag.toml')
        self.assertEqual(cfg.repo, self.repo.resolve())
        self.assertEqual(cfg.state_dir, self.state.resolve())
        self.assertEqual(cfg.llm_url, 'http://ollama:11434')
        self.assertTrue(cfg.allow_remote_model)
        self.assertEqual(cfg.embedding_model, '')
        tools = GitTools(cfg)
        worktree = tools.create_worktree()
        self.assertEqual(Path(worktree).parent, self.state / 'worktrees')
        diff = '--- a/main.py\n+++ b/main.py\n@@ -1 +1 @@\n-value = 1\n+value = 2\n'
        self.assertTrue(tools.apply_patch(diff, worktree)['applied'])
        self.assertEqual((Path(worktree) / 'main.py').read_text(), 'value = 2\n')
        self.assertEqual((self.repo / 'main.py').read_text(), 'value = 1\n')

    def test_rejects_root_and_bad_path_topology(self):
        with patch.object(SETUP.os, 'getuid', return_value=0):
            with self.assertRaisesRegex(ValueError, 'non-root'):
                SETUP.configure(self.repo, self.state, self.output, 'image:tag', 'model')
        with self.assertRaisesRegex(ValueError, 'separate state'):
            self.configure(state=self.repo / 'state')
        child = self.repo / 'child'
        child.mkdir()
        with self.assertRaisesRegex(ValueError, 'checkout root'):
            self.configure(repo=child)

    @unittest.skipUnless(shutil.which('docker'), 'Docker absent; live Compose validation unavailable')
    def test_compose_resolves_generated_config(self):
        self.configure()
        shutil.copy(ROOT / 'deploy/compose.yaml', self.output / 'compose.yaml')
        subprocess.run(['docker', 'compose', '--project-directory', str(self.output),
                        '-f', str(self.output / 'compose.yaml'), 'config', '--quiet'], check=True)


if __name__ == '__main__':
    unittest.main()
