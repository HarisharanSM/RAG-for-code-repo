import subprocess
import sys
import tempfile
import types
import unittest
from pathlib import Path
from unittest.mock import patch

from repo_rag.config import Config
from repo_rag.index import Index, is_allowed_source


class IndexTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.repo = self.root / "repo"
        self.repo.mkdir()
        self.config = Config(repo=self.repo, state_dir=self.root / "state", chunk_lines=10)

    def write(self, name, content):
        path = self.repo / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")
        return path

    def test_shared_source_admission_policy(self):
        self.config.excludes = ["docs/private/*"]
        self.assertTrue(is_allowed_source(self.config, "src/main.py"))
        for path in (".env", "keys/id_ed25519", "src/private.pem", "node_modules/pkg/index.js",
                     "docs/private/notes.md", "src/minified.min.js", "src/data.bin", "../outside.py",
                     "C:/outside.py", "C:outside.py", "src/x.py:stream", ".GIT/config",
                     "src/.GiT/config", ".git./config", ".git /config", "NUL.py", "CON/file.py"):
            with self.subTest(path=path):
                self.assertFalse(is_allowed_source(self.config, path))
        self.assertEqual(Index(self.config)._allowed("src/main.py"),
                         is_allowed_source(self.config, "src/main.py"))

    def test_incremental_freshness_and_source_evidence(self):
        self.write("src/main.py", "import helper\n\ndef answer():\n    return 'quartz token'\n")
        self.write("helper.py", "def utility():\n    return 42\n")
        index = Index(self.config)
        first = index.index()
        self.assertEqual((first["added"], first["chunks"]), (2, 3))
        hits = index.search("quartz")
        self.assertEqual(len(hits), 1)
        self.assertEqual((hits[0]["path"], hits[0]["start_line"], hits[0]["end_line"]),
                         ("src/main.py", 3, 4))
        self.assertEqual(hits[0]["symbol"], "answer")
        self.assertEqual(index.symbols("answer")[0]["text"], hits[0]["text"])
        self.assertEqual(index.index()["unchanged"], 2)
        self.write("src/main.py", "import helper\n\ndef answer():\n    return 'topaz token'\n")
        (self.repo / "helper.py").unlink()
        changed = index.index()
        self.assertEqual((changed["updated"], changed["deleted"]), (1, 1))
        self.assertFalse(index.search("quartz"))
        self.assertEqual(index.search("topaz")[0]["start_line"], 3)
        self.assertEqual(index.status()["files"], 1)

    def test_gitignore_excludes_secrets_symlinks_and_generated(self):
        subprocess.run(["git", "init", "-q", str(self.repo)], check=True)
        self.write(".gitignore", "ignored.py\n")
        self.write("ignored.py", "def ignored(): pass\n")
        self.write(".env", "password=hidden\n")
        self.write("secret.pem", "private material\n")
        self.write("node_modules/pkg/index.js", "export function generated() {}\n")
        self.write("src/code.py", "def visible(): return 'retrievable'\n")
        index = Index(self.config)
        index.index()
        self.assertEqual(index.status()["files"], 1)
        self.assertEqual(index.search("retrievable")[0]["path"], "src/code.py")
        self.assertFalse(index.search("hidden"))

    def test_symlink_is_excluded_when_creation_is_available(self):
        self.write("src/code.py", "def visible(): return 'retrievable'\n")
        try:
            (self.repo / "symlink.py").symlink_to(self.repo / "src/code.py")
        except OSError as exc:
            self.skipTest(f"Symlink creation unavailable: {exc}")
        index = Index(self.config)
        index.index()
        self.assertEqual(index.status()["files"], 1)
        self.assertEqual(index.search("retrievable")[0]["path"], "src/code.py")

    def test_semantic_chunks_and_local_dependency_links(self):
        self.write("src/one.ts", "import { run } from './two';\n\nexport function first() {\n  return run();\n}\n")
        self.write("src/two.ts", "export function run() { return 'needle'; }\n")
        self.write("README.md", "# Overview\nDocumentation\n## Detail\nMore details\n")
        self.config.links = [{"source": "README.md", "target": "src/*.ts", "label": "explains"}]
        index = Index(self.config)
        index.index()
        self.assertEqual([h["symbol"] for h in index.symbols("Detail")], ["Detail"])
        related = index.related("src/one.ts")
        self.assertTrue(any(r.get("resolved_path") == "src/two.ts" and r["line"] == 1 for r in related))
        explicit = index.related("README.md")
        self.assertEqual({r["resolved_path"] for r in explicit}, {"src/one.ts", "src/two.ts"})
        self.assertTrue(all(r["label"] == "explains" for r in explicit))
        self.assertEqual(index.search("needle", language="typescript")[0]["path"], "src/two.ts")
        self.assertFalse(index.search("needle", language="python"))
        self.assertEqual(index.file_chunks("src/two.ts")[0]["start_line"], 1)

    def test_shared_state_replaces_other_repository_and_large_file(self):
        self.write("same.py", "def old(): return 'obsolete'\n")
        index = Index(self.config)
        index.index()
        another = self.root / "another"
        another.mkdir()
        (another / "same.py").write_text("def fresh(): return 'current'\n")
        other_config = Config(repo=another, state_dir=self.config.state_dir, chunk_lines=10,
                              max_file_bytes=100)
        other_index = Index(other_config)
        self.assertEqual(other_index.index()["added"], 1)
        self.assertFalse(other_index.search("obsolete"))
        self.assertEqual(other_index.search("current")[0]["path"], "same.py")
        (another / "same.py").write_text("x" * 101)
        self.assertEqual(other_index.index()["deleted"], 1)
        self.assertFalse(other_index.search("current"))

    def test_embeddings_reuse_and_invalidation(self):
        self.write("a.py", "def alpha():\n    return 'plain text'\n")
        self.config.embedding_model = "embed-a"

        class FakeClient:
            calls = []

            def __init__(self, config):
                self.config = config

            def embed(self, texts):
                self.calls.append((self.config.embedding_model, len(texts)))
                return [[1.0, 0.0] for _ in texts]

        fake_module = types.ModuleType("repo_rag.llm")
        fake_module.OllamaClient = FakeClient
        with patch.dict(sys.modules, {"repo_rag.llm": fake_module}):
            index = Index(self.config)
            self.assertEqual(index.index()["embedded"], 1)
            self.assertEqual(index.index()["embedded"], 0)
            self.assertEqual(len(FakeClient.calls), 1)
            self.assertEqual(index.search("semantic", limit=1)[0]["path"], "a.py")
            self.config.model = "another-generation-model"
            self.assertEqual(index.index()["embedded"], 0)
            self.assertEqual(len(FakeClient.calls), 2)  # initial index and semantic query
            self.config.embedding_model = "embed-b"
            self.assertEqual(index.index()["embedded"], 1)
            self.assertEqual(FakeClient.calls[-1][0], "embed-b")
            self.assertEqual(index.status()["embedded"], 1)


if __name__ == "__main__":
    unittest.main()
