"""Small, bounded Ollama HTTP adapter using only the standard library."""

from __future__ import annotations

import ipaddress
import json
import math
import socket
from urllib import error, parse, request

from .config import Config


_MAX_RESPONSE_BYTES = 16 * 1024 * 1024


class OllamaError(RuntimeError):
    """An Ollama request failed or returned an unexpected response."""


class _NoRedirect(request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise OllamaError("Ollama redirected its response; redirects are disabled")


class OllamaClient:
    def __init__(self, config: Config):
        self.config = config
        self.base_url = self._validate_url(config.llm_url, config.allow_remote_model)
        if config.timeout <= 0:
            raise ValueError("Ollama timeout must be positive")
        # Ignore environment proxies, including for loopback hostnames.
        self._opener = request.build_opener(request.ProxyHandler({}), _NoRedirect())

    @staticmethod
    def _validate_url(url: str, allow_remote: bool) -> str:
        try:
            parts = parse.urlsplit(url)
            host = parts.hostname
            port = parts.port
        except (TypeError, ValueError) as exc:
            raise ValueError("Invalid Ollama URL") from exc
        if (parts.scheme not in ("http", "https") or not host or
                parts.username is not None or parts.password is not None or
                parts.query or parts.fragment or port == 0):
            raise ValueError("Ollama URL must be an HTTP(S) base URL without credentials or query")
        if parts.path not in ("", "/"):
            raise ValueError("Ollama URL must not include a path")
        if not allow_remote:
            try:
                loopback = host.lower() == "localhost" or ipaddress.ip_address(host).is_loopback
            except ValueError:
                loopback = False
            if not loopback:
                raise ValueError("Remote Ollama URL requires allow_remote_model=true")
        return url.rstrip("/")

    def _post(self, endpoint: str, payload: dict) -> dict:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        req = request.Request(
            self.base_url + endpoint,
            data=body,
            headers={"Content-Type": "application/json", "Accept": "application/json"},
            method="POST",
        )
        try:
            with self._opener.open(req, timeout=self.config.timeout) as response:
                raw = response.read(_MAX_RESPONSE_BYTES + 1)
        except error.HTTPError as exc:
            raise OllamaError(f"Ollama returned HTTP {exc.code} for {endpoint}") from exc
        except (error.URLError, TimeoutError, socket.timeout, OSError) as exc:
            raise OllamaError(f"Could not reach Ollama at {self.base_url}: {exc}") from exc
        if len(raw) > _MAX_RESPONSE_BYTES:
            raise OllamaError("Ollama response exceeds 16 MiB")
        try:
            result = json.loads(raw)
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise OllamaError("Ollama returned invalid JSON") from exc
        if not isinstance(result, dict):
            raise OllamaError("Ollama returned an unexpected JSON value")
        if result.get("error"):
            raise OllamaError(f"Ollama error: {result['error']}")
        return result

    def generate(self, prompt: str) -> str:
        if not isinstance(prompt, str):
            raise TypeError("prompt must be a string")
        result = self._post("/api/generate", {
            "model": self.config.model, "prompt": prompt, "stream": False,
        })
        answer = result.get("response")
        if not isinstance(answer, str):
            raise OllamaError("Ollama generate response is missing text")
        return answer

    def embed(self, texts: list[str]) -> list[list[float]]:
        if not isinstance(texts, list) or any(not isinstance(t, str) for t in texts):
            raise TypeError("texts must be a list of strings")
        if not texts:
            return []
        model = self.config.embedding_model or self.config.model
        result = self._post("/api/embed", {"model": model, "input": texts})
        vectors = result.get("embeddings")
        if not isinstance(vectors, list) or len(vectors) != len(texts):
            raise OllamaError("Ollama returned the wrong number of embeddings")
        dimensions = None
        normalized = []
        for vector in vectors:
            if (not isinstance(vector, list) or not vector or
                    any(isinstance(v, bool) or not isinstance(v, (int, float)) or
                        not math.isfinite(v) for v in vector)):
                raise OllamaError("Ollama returned an invalid embedding")
            if dimensions is not None and len(vector) != dimensions:
                raise OllamaError("Ollama returned inconsistent embedding dimensions")
            dimensions = len(vector)
            normalized.append([float(v) for v in vector])
        return normalized
