"""Bounded repository reads, Git operations, and explicitly configured commands.

These controls reduce accidental writes and path escapes; they are not an OS sandbox.
"""

from __future__ import annotations

import os
from pathlib import Path, PurePosixPath, PureWindowsPath
import re
import selectors
import signal
import subprocess
import time
import uuid

from .config import Config
from .index import is_allowed_source, is_link_or_reparse


OUTPUT_LIMIT = 64 * 1024


def _relative_path(value: str) -> PurePosixPath:
    if not isinstance(value, str) or not value or "\\" in value or "\x00" in value:
        raise ValueError("Expected a repository-relative POSIX path")
    path = PurePosixPath(value)
    windows = PureWindowsPath(value)
    if path.is_absolute() or windows.drive or ":" in value or any(
            part in ("", ".", "..") or part.endswith((".", " ")) or PureWindowsPath(part).is_reserved()
            for part in value.split("/")):
        raise ValueError("Path must be relative and contain no traversal")
    if any(part.casefold() == ".git" for part in path.parts):
        raise ValueError("Git internals cannot be accessed")
    return path


def _inside(root: Path, value: str) -> Path:
    relative = _relative_path(value)
    candidate = root.joinpath(*relative.parts)
    if not candidate.resolve().is_relative_to(root.resolve()):
        raise ValueError("Path resolves outside the repository")
    return candidate


def read_source(config: Config, path: str, start_line: int = 1, end_line: int | None = None) -> dict:
    """Read a bounded file admitted by the same source policy as the index."""
    if isinstance(start_line, bool) or not isinstance(start_line, int) or start_line < 1:
        raise ValueError("start_line must be positive")
    if end_line is not None and (isinstance(end_line, bool) or not isinstance(end_line, int) or end_line < start_line):
        raise ValueError("end_line must be at least start_line")
    relative = _relative_path(path)
    if not is_allowed_source(config, relative.as_posix()):
        raise ValueError("Source is excluded by indexing policy")
    candidate = _inside(config.repo, path)
    root = config.repo.resolve()
    for part in (candidate, *candidate.parents):
        if part == config.repo or part == root:
            break
        if is_link_or_reparse(part):
            raise ValueError("Source cannot traverse a symlink")
    if candidate.resolve().is_relative_to(config.state_dir.resolve()):
        raise ValueError("State files cannot be read as source")
    # Git's default check-ignore behavior exempts tracked files, matching the
    # indexer's ls-files --cached admission. Path is one argv element.
    ignored = subprocess.run(
        ["git", "-C", str(root), "check-ignore", "-q", "--", relative.as_posix()],
        stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        timeout=config.timeout,
    )
    if ignored.returncode == 0:
        raise ValueError("Git-ignored source cannot be read")
    if ignored.returncode not in (1, 128):
        raise RuntimeError("Could not check Git ignore status")
    if ignored.returncode == 128 and (root / ".git").exists():
        raise RuntimeError("Could not check Git ignore status")
    if not candidate.is_file():
        raise ValueError("Source path is not a regular file")
    if candidate.stat().st_size > config.max_file_bytes:
        raise ValueError("Source exceeds max_file_bytes")
    # A second bounded read also handles a file growing between stat and open.
    with candidate.open("rb") as stream:
        data = stream.read(config.max_file_bytes + 1)
    if len(data) > config.max_file_bytes:
        raise ValueError("Source exceeds max_file_bytes")
    if b"\x00" in data:
        raise ValueError("Binary source containing NUL is excluded")
    try:
        content = data.decode("utf-8-sig")
    except UnicodeError as exc:
        raise ValueError("Source is not valid UTF-8") from exc
    lines = content.splitlines(keepends=True)
    if start_line > len(lines):
        raise ValueError("start_line exceeds source line count")
    last = min(end_line if end_line is not None else len(lines), len(lines))
    return {"path": _relative_path(path).as_posix(), "start_line": start_line,
            "end_line": last, "text": "".join(lines[start_line - 1:last])}


def _bounded_process(argv: list[str], cwd: Path, timeout: int, stdin=None) -> dict:
    """Drain both pipes without retaining more than OUTPUT_LIMIT bytes each."""
    if os.name == "nt":
        from .windows_process import bounded_process
        return bounded_process(argv, cwd, timeout, stdin, OUTPUT_LIMIT)
    if os.name != "posix" or not hasattr(os, "killpg"):
        raise RuntimeError("Command execution requires Windows Job Objects or POSIX process groups")
    process = subprocess.Popen(argv, cwd=cwd, stdin=stdin if stdin is not None else subprocess.DEVNULL, stdout=subprocess.PIPE,
                               stderr=subprocess.PIPE, start_new_session=True)
    outputs = {"stdout": bytearray(), "stderr": bytearray()}
    truncated = {"stdout": False, "stderr": False}
    selector = selectors.DefaultSelector()
    for name in outputs:
        stream = getattr(process, name)
        os.set_blocking(stream.fileno(), False)
        selector.register(stream, selectors.EVENT_READ, name)
    deadline = time.monotonic() + timeout
    timed_out = False
    try:
        while selector.get_map():
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                timed_out = True
                break
            for key, _ in selector.select(min(remaining, 0.25)):
                block = os.read(key.fileobj.fileno(), 65536)
                if not block:
                    selector.unregister(key.fileobj)
                    key.fileobj.close()
                    continue
                name = key.data
                available = OUTPUT_LIMIT - len(outputs[name])
                outputs[name].extend(block[:available])
                truncated[name] |= len(block) > available
        if not timed_out:
            remaining = deadline - time.monotonic()
            try:
                process.wait(timeout=max(remaining, 0))
            except subprocess.TimeoutExpired:
                timed_out = True
        if timed_out:
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            process.wait()
    finally:
        selector.close()
        for name in outputs:
            stream = getattr(process, name)
            if not stream.closed:
                stream.close()
    return {"returncode": process.returncode, "timed_out": timed_out,
            "stdout": outputs["stdout"].decode("utf-8", "replace"),
            "stderr": outputs["stderr"].decode("utf-8", "replace"),
            "stdout_truncated": truncated["stdout"], "stderr_truncated": truncated["stderr"]}


class GitTools:
    def __init__(self, config: Config):
        self.config = config

    def _git(self, *args: str, cwd: Path | None = None) -> dict:
        top = _bounded_process(["git", "rev-parse", "--show-toplevel"], self.config.repo, self.config.timeout)
        if top["returncode"] != 0 or Path(top["stdout"].strip()).resolve() != self.config.repo.resolve():
            raise ValueError("Configured repo must be the Git checkout root")
        return _bounded_process(["git", *args], cwd or self.config.repo, self.config.timeout)

    def _checked(self, *args: str, cwd: Path | None = None) -> dict:
        result = self._git(*args, cwd=cwd)
        if result["returncode"] != 0:
            raise RuntimeError(result["stderr"] or f"git {args[0]} failed")
        return result

    def status(self) -> dict:
        return self._checked("status", "--short", "--untracked-files=normal")

    def diff(self) -> dict:
        discovered = self._checked("diff", "--name-only", "-z", "--no-renames",
                                   "--no-ext-diff", "--no-textconv", "--")
        if discovered["stdout_truncated"] or "\ufffd" in discovered["stdout"]:
            raise RuntimeError("Git changed-path list is too large or contains invalid UTF-8")
        paths = []
        for rel in filter(None, discovered["stdout"].split("\x00")):
            if not is_allowed_source(self.config, rel):
                continue
            try:
                candidate = _inside(self.config.repo, rel)
            except ValueError:
                continue
            if candidate.resolve().is_relative_to(self.config.state_dir.resolve()):
                continue
            if any(is_link_or_reparse(part) for part in (candidate, *candidate.parents)
                   if part != self.config.repo and part != self.config.repo.resolve()):
                continue
            # Deleted paths lack a filesystem entry; inspect the Git entry to
            # exclude tracked symlinks and submodules in that case as well.
            entry = self._checked("ls-files", "--stage", "--", rel)["stdout"]
            if any(line.startswith(("120000 ", "160000 ")) for line in entry.splitlines()):
                continue
            paths.append(rel)
        if not paths:
            return {"returncode": 0, "timed_out": False, "stdout": "", "stderr": "",
                    "stdout_truncated": False, "stderr_truncated": False}
        return self._checked("diff", "--no-renames", "--no-ext-diff", "--no-textconv", "--", *paths)

    def history(self, limit: int = 10) -> dict:
        if isinstance(limit, bool) or not isinstance(limit, int) or not 1 <= limit <= 100:
            raise ValueError("limit must be between 1 and 100")
        return self._checked("log", f"-{limit}", "--format=%h %s")

    def create_worktree(self) -> str:
        # A detached HEAD worktree omits uncommitted tracked edits. Refuse a
        # misleading baseline; untracked files also are not copied.
        for args in (("diff", "--quiet", "--"), ("diff", "--cached", "--quiet", "--")):
            result = self._git(*args)
            if result["returncode"] == 1:
                raise ValueError("Commit or stash tracked changes before creating a worktree")
            if result["returncode"] != 0:
                raise RuntimeError(result["stderr"] or "Could not inspect working tree")
        base = self.config.state_dir.resolve() / "worktrees"
        base.mkdir(parents=True, exist_ok=True)
        target = base / uuid.uuid4().hex
        try:
            self._checked("worktree", "add", "--detach", "--", str(target))
        except Exception:
            if target.exists():
                # A failed Git operation may leave a directory. Leave it for inspection.
                pass
            raise
        return str(target)

    def _managed_worktree(self, worktree: str) -> Path:
        if not isinstance(worktree, str) or not worktree:
            raise ValueError("A managed worktree path is required")
        target = Path(worktree).resolve()
        base = self.config.state_dir.resolve() / "worktrees"
        if target.parent != base or not target.is_dir():
            raise ValueError("Worktree must be a managed worktree")
        top = self._checked("rev-parse", "--show-toplevel", cwd=target)["stdout"].strip()
        if Path(top).resolve() != target:
            raise ValueError("Worktree path is not its Git root")
        listing = self._checked("worktree", "list", "--porcelain", "-z")
        if listing["stdout_truncated"] or "\ufffd" in listing["stdout"]:
            raise ValueError("Could not verify registered worktree paths")
        # -z preserves paths with spaces, quotes, and newlines. Git on Windows
        # emits forward slashes; Path also accepts those on Windows.
        registered = [Path(record[len("worktree "):]).resolve()
                      for record in listing["stdout"].split("\x00") if record.startswith("worktree ")]
        if target not in registered:
            raise ValueError("Worktree is not registered with this repository")
        return target

    def apply_patch(self, patch: str, worktree: str) -> dict:
        target = self._managed_worktree(worktree)
        _validate_patch(patch, target)
        # Pass patch through stdin, not argv or a shell. Apply only after Git validation.
        check = _bounded_git_input(["git", "apply", "--check", "--"], target, patch, self.config.timeout)
        if check["returncode"] != 0:
            return {"applied": False, **check}
        result = _bounded_git_input(["git", "apply", "--"], target, patch, self.config.timeout)
        return {"applied": result["returncode"] == 0, **result}


def _validate_patch(patch: str, root: Path) -> None:
    if not isinstance(patch, str) or not patch or "\x00" in patch or len(patch.encode("utf-8")) > 1024 * 1024:
        raise ValueError("Patch must be nonempty text of at most 1 MiB")
    headers = 0
    before = None
    pairs = 0
    old_remaining = new_remaining = 0
    in_hunk = False
    for line in patch.splitlines():
        if line.startswith("@@ "):
            if in_hunk and (old_remaining or new_remaining):
                raise ValueError("Incomplete patch hunk")
            hunk = re.match(r"^@@ -\d+(?:,(\d+))? \+\d+(?:,(\d+))? @@", line)
            if not hunk:
                raise ValueError("Malformed patch hunk")
            old_remaining = int(hunk.group(1) or 1)
            new_remaining = int(hunk.group(2) or 1)
            in_hunk = True
            continue
        if in_hunk:
            if line.startswith("\\"):
                continue  # Diff's no-newline marker.
            if old_remaining or new_remaining:
                if line.startswith(" "):
                    old_remaining -= 1
                    new_remaining -= 1
                elif line.startswith("-"):
                    old_remaining -= 1
                elif line.startswith("+"):
                    new_remaining -= 1
                else:
                    raise ValueError("Malformed patch hunk line")
                if old_remaining < 0 or new_remaining < 0:
                    raise ValueError("Patch hunk exceeds declared line count")
                continue
            in_hunk = False
        if line.startswith("diff --git "):
            match = re.fullmatch(r"diff --git a/([^\s]+) b/([^\s]+)", line)
            if not match or match.group(1) != match.group(2):
                raise ValueError("Only simple repository-relative file patches are supported")
            _patch_path(root, match.group(1))
            headers += 1
        elif line.startswith(("--- ", "+++ ")):
            value = line[4:]
            if value != "/dev/null":
                prefix = "a/" if line.startswith("--- ") else "b/"
                if not value.startswith(prefix):
                    raise ValueError("Malformed patch path")
                _patch_path(root, value[2:])
            if line.startswith("--- "):
                before = value
            else:
                if before is None or (before == "/dev/null" and value == "/dev/null"):
                    raise ValueError("Patch needs paired --- and +++ file headers")
                pairs += 1
                before = None
        elif line.startswith(("rename from ", "rename to ", "copy from ", "copy to ",
                              "GIT binary patch", "Binary files ", "literal ", "delta ")):
            raise ValueError("Renames, copies, and binary patches are unsupported")
        elif line.startswith(("new file mode ", "deleted file mode ", "old mode ", "new mode ")):
            if line.split()[-1] not in ("100644", "100755"):
                raise ValueError("Special files and symlinks cannot be patched")
    if old_remaining or new_remaining:
        raise ValueError("Incomplete patch hunk")
    if before is not None or (not headers and not pairs):
        raise ValueError("Patch needs a diff header or paired --- and +++ file headers")


def _patch_path(root: Path, value: str) -> None:
    candidate = _inside(root, value)
    for parent in (candidate, *candidate.parents):
        if parent == root:
            break
        if is_link_or_reparse(parent):
            raise ValueError("Patch cannot edit or traverse symlinks")
    if candidate.exists() and not candidate.is_file():
        raise ValueError("Patch target is not a regular file")


def _bounded_git_input(argv: list[str], cwd: Path, patch: str, timeout: int) -> dict:
    # A patch is capped at 1 MiB. A temporary file avoids pipe deadlock with
    # subprocess.run while retaining a bounded stdout/stderr via _bounded_process.
    import tempfile
    with tempfile.TemporaryFile() as source:
        source.write(patch.encode("utf-8"))
        source.seek(0)
        return _bounded_process_input(argv, cwd, timeout, source)


def _bounded_process_input(argv: list[str], cwd: Path, timeout: int, source) -> dict:
    # Give _bounded_process an optional input descriptor without duplicating its loop.
    return _bounded_process(argv, cwd, timeout, stdin=source)


class Runner:
    def __init__(self, config: Config):
        self.config = config

    def run(self, name: str, worktree: str | None = None) -> dict:
        if name not in self.config.commands:
            raise ValueError("Command is not configured")
        argv = self.config.commands[name]
        if not isinstance(argv, list) or not argv or any(not isinstance(arg, str) or not arg or "\x00" in arg for arg in argv):
            raise ValueError("Configured command must be a nonempty argv list")
        cwd = GitTools(self.config)._managed_worktree(worktree) if worktree is not None else self.config.repo
        return {"name": name, **_bounded_process(argv, cwd, self.config.timeout)}
