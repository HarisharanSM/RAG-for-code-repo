"""Optional MCP stdio interface. Write and command tools require explicit flags."""

from __future__ import annotations

from .config import Config
from .execution import GitTools, Runner, read_source


def build_server(config: Config, *, enable_execution: bool = False, enable_writes: bool = False):
    try:
        from mcp.server.fastmcp import FastMCP
    except ImportError as exc:
        raise RuntimeError("MCP support requires the optional 'mcp' dependency") from exc

    from .index import Index

    server = FastMCP("repo-rag")
    index = Index(config)
    git = GitTools(config)

    @server.tool()
    def search(query: str, limit: int = 8, language: str | None = None) -> list[dict]:
        """Search indexed repository source for relevant passages."""
        index.index()
        return index.search(query, limit=limit, language=language)

    @server.tool()
    def source(path: str, start_line: int = 1, end_line: int | None = None) -> dict:
        """Read lines from a repository-relative source file."""
        return read_source(config, path, start_line, end_line)

    @server.tool()
    def symbols(name: str) -> list[dict]:
        """Find indexed definitions by name."""
        index.index()
        return index.symbols(name)

    @server.tool()
    def related(path: str) -> list[dict]:
        """Find indexed source linked to a repository-relative path."""
        index.index()
        return index.related(path)

    @server.tool()
    def git_status() -> dict:
        """Read the repository's short Git status."""
        return git.status()

    @server.tool()
    def git_diff() -> dict:
        """Read the repository's unstaged Git diff."""
        return git.diff()

    @server.tool()
    def git_history(limit: int = 10) -> dict:
        """Read recent Git commit subjects."""
        return git.history(limit)

    if enable_execution:
        runner = Runner(config)

        @server.tool()
        def run_command(name: str, worktree: str | None = None) -> dict:
            """Run one named, configured argv command with bounded time and output."""
            return runner.run(name, worktree)

    if enable_writes:
        @server.tool()
        def create_worktree() -> str:
            """Create an isolated detached Git worktree under state_dir."""
            return git.create_worktree()

        @server.tool()
        def apply_patch(patch: str, worktree: str) -> dict:
            """Validate and apply a text patch in a managed worktree."""
            return git.apply_patch(patch, worktree)

    return server


def serve(config: Config, *, enable_execution: bool = False, enable_writes: bool = False) -> None:
    """Run the official MCP SDK over stdio. This blocks until the client exits."""
    build_server(config, enable_execution=enable_execution, enable_writes=enable_writes).run(transport="stdio")
