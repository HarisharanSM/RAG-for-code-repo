import argparse
import json
import sys
from pathlib import Path
from .config import Config


def main(argv=None):
    parser = argparse.ArgumentParser(description='Local repository RAG and MCP server')
    parser.add_argument('--config', default='repo-rag.toml')
    sub = parser.add_subparsers(dest='command', required=True)
    sub.add_parser('index')
    sub.add_parser('status')
    search = sub.add_parser('search')
    search.add_argument('query')
    search.add_argument('--limit', type=int, default=8)
    search.add_argument('--language')
    sym = sub.add_parser('symbols')
    sym.add_argument('name')
    rel = sub.add_parser('related')
    rel.add_argument('path')
    for mode in ('analyze', 'review', 'develop'):
        p = sub.add_parser(mode)
        p.add_argument('task')
        p.add_argument('--limit', type=int, default=8)
        p.add_argument('--output', help='Save result JSON to this file')
    read = sub.add_parser('read')
    read.add_argument('path')
    read.add_argument('--start', type=int, default=1)
    read.add_argument('--end', type=int)
    sub.add_parser('worktree')
    patch = sub.add_parser('apply')
    patch.add_argument('patch_file')
    patch.add_argument('--worktree', required=True)
    run = sub.add_parser('run')
    run.add_argument('name', help='Configured command name')
    run.add_argument('--worktree')
    git = sub.add_parser('git')
    git.add_argument('operation', choices=('status','diff','history'))
    mcp = sub.add_parser('mcp')
    mcp.add_argument('--enable-execution', action='store_true')
    mcp.add_argument('--enable-writes', action='store_true')
    args = parser.parse_args(argv)
    try:
        cfg = Config.load(args.config)
        if args.command in ('index','status','search','symbols','related'):
            from .index import Index
            idx = Index(cfg)
            if args.command == 'search':
                idx.index()
                result = idx.search(args.query, args.limit, args.language)
            elif args.command == 'symbols':
                idx.index()
                result = idx.symbols(args.name)
            elif args.command == 'related':
                idx.index()
                result = idx.related(args.path)
            else:
                result = getattr(idx,args.command)()
        elif args.command in ('analyze','review','develop'):
            from .workflow import Workflow
            result = Workflow(cfg).run(args.task, args.command, args.limit)
            if args.output:
                Path(args.output).write_text(json.dumps(result, indent=2), encoding='utf-8')
        elif args.command == 'mcp':
            from .mcp_server import serve
            serve(cfg, enable_execution=args.enable_execution, enable_writes=args.enable_writes)
            return 0
        else:
            from .execution import GitTools, Runner, read_source
            if args.command == 'read':
                result = read_source(cfg,args.path,args.start,args.end)
            elif args.command == 'git':
                result = getattr(GitTools(cfg),args.operation)()
            elif args.command == 'worktree':
                result = {'worktree':GitTools(cfg).create_worktree()}
            elif args.command == 'apply':
                result = GitTools(cfg).apply_patch(Path(args.patch_file).read_text(encoding='utf-8'), args.worktree)
            else:
                result = Runner(cfg).run(args.name,args.worktree)
        print(json.dumps(result, indent=2, ensure_ascii=False))
        if args.command == 'apply' and not result.get('applied', False):
            return 1
        if args.command == 'run' and (result.get('timed_out') or result.get('returncode') != 0):
            return 1
        return 0
    except (ValueError, OSError, RuntimeError, ImportError) as exc:
        print(f'Error: {exc}', file=sys.stderr)
        return 1

if __name__ == '__main__':
    sys.exit(main())
