"""Windows subprocess containment using documented Win32 APIs via ctypes.

Imported only on Windows. A suspended process joins a kill-on-close Job Object
before its primary thread runs, so descendants cannot race job assignment.
"""
from __future__ import annotations

import ctypes
from ctypes import wintypes
import os
from pathlib import Path
import subprocess
import time


class _BasicLimits(ctypes.Structure):
    _fields_ = [("PerProcessUserTimeLimit", ctypes.c_longlong),
                ("PerJobUserTimeLimit", ctypes.c_longlong),
                ("LimitFlags", wintypes.DWORD),
                ("MinimumWorkingSetSize", ctypes.c_size_t),
                ("MaximumWorkingSetSize", ctypes.c_size_t),
                ("ActiveProcessLimit", wintypes.DWORD),
                ("Affinity", ctypes.c_size_t),
                ("PriorityClass", wintypes.DWORD),
                ("SchedulingClass", wintypes.DWORD)]


class _IoCounters(ctypes.Structure):
    _fields_ = [(name, ctypes.c_ulonglong) for name in (
        "ReadOperationCount", "WriteOperationCount", "OtherOperationCount",
        "ReadTransferCount", "WriteTransferCount", "OtherTransferCount")]


class _ExtendedLimits(ctypes.Structure):
    _fields_ = [("BasicLimitInformation", _BasicLimits), ("IoInfo", _IoCounters),
                ("ProcessMemoryLimit", ctypes.c_size_t), ("JobMemoryLimit", ctypes.c_size_t),
                ("PeakProcessMemoryUsed", ctypes.c_size_t), ("PeakJobMemoryUsed", ctypes.c_size_t)]


class _ThreadEntry(ctypes.Structure):
    _fields_ = [("dwSize", wintypes.DWORD), ("cntUsage", wintypes.DWORD),
                ("th32ThreadID", wintypes.DWORD), ("th32OwnerProcessID", wintypes.DWORD),
                ("tpBasePri", wintypes.LONG), ("tpDeltaPri", wintypes.LONG),
                ("dwFlags", wintypes.DWORD)]


def _kernel32():
    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    signatures = {
        "CreateJobObjectW": ([ctypes.c_void_p, wintypes.LPCWSTR], wintypes.HANDLE),
        "SetInformationJobObject": ([wintypes.HANDLE, ctypes.c_int, ctypes.c_void_p, wintypes.DWORD], wintypes.BOOL),
        "AssignProcessToJobObject": ([wintypes.HANDLE, wintypes.HANDLE], wintypes.BOOL),
        "TerminateJobObject": ([wintypes.HANDLE, wintypes.UINT], wintypes.BOOL),
        "CloseHandle": ([wintypes.HANDLE], wintypes.BOOL),
        "OpenProcess": ([wintypes.DWORD, wintypes.BOOL, wintypes.DWORD], wintypes.HANDLE),
        "OpenThread": ([wintypes.DWORD, wintypes.BOOL, wintypes.DWORD], wintypes.HANDLE),
        "ResumeThread": ([wintypes.HANDLE], wintypes.DWORD),
        "CreateToolhelp32Snapshot": ([wintypes.DWORD, wintypes.DWORD], wintypes.HANDLE),
        "Thread32First": ([wintypes.HANDLE, ctypes.POINTER(_ThreadEntry)], wintypes.BOOL),
        "Thread32Next": ([wintypes.HANDLE, ctypes.POINTER(_ThreadEntry)], wintypes.BOOL),
        "PeekNamedPipe": ([wintypes.HANDLE, ctypes.c_void_p, wintypes.DWORD,
                           ctypes.c_void_p, ctypes.POINTER(wintypes.DWORD), ctypes.c_void_p], wintypes.BOOL),
    }
    for name, (arguments, result) in signatures.items():
        function = getattr(kernel, name)
        function.argtypes = arguments
        function.restype = result
    return kernel


def _winerror(operation: str) -> OSError:
    return OSError(f"{operation}: {ctypes.WinError(ctypes.get_last_error())}")


class _Job:
    def __init__(self):
        self.kernel = _kernel32()
        self.handle = self.kernel.CreateJobObjectW(None, None)
        if not self.handle:
            raise _winerror("Cannot create Windows Job Object")
        limits = _ExtendedLimits()
        limits.BasicLimitInformation.LimitFlags = 0x2000  # KILL_ON_JOB_CLOSE; no breakaway.
        if not self.kernel.SetInformationJobObject(self.handle, 9, ctypes.byref(limits), ctypes.sizeof(limits)):
            error = _winerror("Cannot configure Windows Job Object")
            self.close()
            raise error

    def start(self, argv: list[str], cwd: Path, stdin):
        process = subprocess.Popen(argv, cwd=cwd, stdin=stdin, stdout=subprocess.PIPE,
                                   stderr=subprocess.PIPE, creationflags=0x4, bufsize=0)  # CREATE_SUSPENDED
        try:
            handle = self.kernel.OpenProcess(0x0100 | 0x0001, False, process.pid)  # SET_QUOTA | TERMINATE
            if not handle:
                raise _winerror("Cannot open suspended process")
            try:
                if not self.kernel.AssignProcessToJobObject(self.handle, handle):
                    raise _winerror("Cannot assign process to Windows Job Object")
            finally:
                self.kernel.CloseHandle(handle)
            self._resume(process.pid)
        except BaseException:
            # Fail closed: a command never runs without process-tree containment.
            process.kill()
            process.wait()
            process.stdout.close()
            process.stderr.close()
            raise
        return process

    def _resume(self, pid: int):
        # Popen closes the primary thread handle. Enumerate the suspended
        # process's sole thread, using documented Tool Help and ResumeThread.
        snapshot = self.kernel.CreateToolhelp32Snapshot(0x4, 0)  # SNAPTHREAD
        if snapshot == ctypes.c_void_p(-1).value:
            raise _winerror("Cannot inspect suspended process thread")
        try:
            entry = _ThreadEntry()
            entry.dwSize = ctypes.sizeof(entry)
            exists = self.kernel.Thread32First(snapshot, ctypes.byref(entry))
            while exists:
                if entry.th32OwnerProcessID == pid:
                    thread = self.kernel.OpenThread(0x0002, False, entry.th32ThreadID)  # SUSPEND_RESUME
                    if not thread:
                        raise _winerror("Cannot open suspended process thread")
                    try:
                        if self.kernel.ResumeThread(thread) == 0xFFFFFFFF:
                            raise _winerror("Cannot resume process thread")
                    finally:
                        self.kernel.CloseHandle(thread)
                    return
                exists = self.kernel.Thread32Next(snapshot, ctypes.byref(entry))
            raise RuntimeError("Cannot locate suspended process thread")
        finally:
            self.kernel.CloseHandle(snapshot)

    def terminate(self):
        if not self.kernel.TerminateJobObject(self.handle, 1):
            raise _winerror("Cannot terminate Windows process tree")

    def close(self):
        if self.handle:
            if not self.kernel.CloseHandle(self.handle):
                raise _winerror("Cannot close Windows Job Object")
            self.handle = None


def bounded_process(argv: list[str], cwd: Path, timeout: int, stdin, output_limit: int) -> dict:
    import msvcrt

    job = _Job()
    process = None
    outputs = {"stdout": bytearray(), "stderr": bytearray()}
    truncated = {"stdout": False, "stderr": False}
    timed_out = False
    try:
        process = job.start(argv, cwd, stdin if stdin is not None else subprocess.DEVNULL)
        streams = {name: getattr(process, name) for name in outputs}
        deadline = time.monotonic() + timeout
        # Windows selectors cannot wait on anonymous pipes. PeekNamedPipe tells
        # us exactly how many bytes os.read can consume without blocking.
        while streams:
            if time.monotonic() >= deadline:
                timed_out = True
                break
            progressed = False
            for name, stream in list(streams.items()):
                available = wintypes.DWORD()
                handle = msvcrt.get_osfhandle(stream.fileno())
                if not job.kernel.PeekNamedPipe(handle, None, 0, None, ctypes.byref(available), None):
                    if ctypes.get_last_error() == 109:  # ERROR_BROKEN_PIPE: all writers closed.
                        del streams[name]
                        continue
                    raise _winerror("Cannot inspect command output pipe")
                if available.value:
                    block = os.read(stream.fileno(), min(available.value, 65536))
                    room = output_limit - len(outputs[name])
                    outputs[name].extend(block[:room])
                    truncated[name] |= len(block) > room
                    progressed = True
            if not progressed and streams:
                time.sleep(min(0.01, max(0, deadline - time.monotonic())))
        if not timed_out:
            try:
                process.wait(timeout=max(0, deadline - time.monotonic()))
            except subprocess.TimeoutExpired:
                timed_out = True
        if timed_out:
            job.terminate()
            process.wait()
    finally:
        # Also end descendants that closed their output handles before parent
        # completion; the configured command does not leave background jobs.
        try:
            job.close()
        finally:
            if process is not None:
                if process.poll() is None:
                    process.kill()
                    process.wait()
                process.stdout.close()
                process.stderr.close()
    return {"returncode": process.returncode, "timed_out": timed_out,
            "stdout": outputs["stdout"].decode("utf-8", "replace"),
            "stderr": outputs["stderr"].decode("utf-8", "replace"),
            "stdout_truncated": truncated["stdout"], "stderr_truncated": truncated["stderr"]}
