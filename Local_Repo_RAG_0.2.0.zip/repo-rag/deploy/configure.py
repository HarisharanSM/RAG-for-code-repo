#!/usr/bin/env python3
"""Create deployment configuration; never start services or download weights."""
import argparse
import json
import os
from pathlib import Path
import subprocess


def configure(repo: Path, state: Path, output: Path, image: str, model: str) -> None:
    if os.name != 'posix':
        raise ValueError('Deployment setup requires a POSIX Linux host')
    repo, state, output = repo.resolve(), state.resolve(), output.resolve()
    if os.getuid() == 0:
        raise ValueError('Run configuration as the non-root checkout owner')
    if not repo.is_dir() or state.is_relative_to(repo) or repo.is_relative_to(state):
        raise ValueError('Use an existing repository and a separate state directory')
    top = subprocess.check_output(['git', '-C', str(repo), 'rev-parse', '--show-toplevel'], text=True).strip()
    if Path(top).resolve() != repo:
        raise ValueError('repo must be the Git checkout root')
    values = [str(repo), str(state), image, model]
    if any('\n' in value or '\r' in value or '\x00' in value for value in values):
        raise ValueError('Deployment values must be single-line strings')
    if not image.strip() or not model.strip():
        raise ValueError('Image and model are required')
    state.mkdir(parents=True, exist_ok=True)
    if not os.access(repo, os.W_OK) or not os.access(state, os.W_OK):
        raise ValueError('Checkout and state directory must be writable by this user')
    output.mkdir(parents=True, exist_ok=True)
    # JSON string encoding is also valid for these TOML basic strings.
    config = '\n'.join([
        f'repo = {json.dumps(str(repo), ensure_ascii=False)}', f'state_dir = {json.dumps(str(state), ensure_ascii=False)}',
        'llm_url = "http://ollama:11434"', 'allow_remote_model = true',
        f'model = {json.dumps(model, ensure_ascii=False)}', 'embedding_model = ""', 'timeout = 300', '',
        '# Add only trusted explicit argv arrays; install their tools in the image.',
        '[commands]', '',
    ])
    (output / 'repo-rag.toml').write_text(config, encoding='utf-8')
    env = {'APP_UID': str(os.getuid()), 'APP_GID': str(os.getgid()),
           'REPO_PATH': str(repo), 'STATE_PATH': str(state), 'OLLAMA_IMAGE': image}
    # Single-quoted dotenv values suppress interpolation of dollars in paths.
    (output / '.env').write_text(''.join(
        f"{key}='" + value.replace("'", "\\'") + "'\n"
        for key, value in env.items()), encoding='utf-8')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', required=True, type=Path)
    parser.add_argument('--state', required=True, type=Path)
    parser.add_argument('--ollama-image', required=True)
    parser.add_argument('--model', default='qwen2.5-coder:7b')
    parser.add_argument('--output', type=Path, default=Path(__file__).resolve().parent)
    args = parser.parse_args()
    try:
        configure(args.repo, args.state, args.output, args.ollama_image, args.model)
    except (OSError, ValueError, subprocess.CalledProcessError) as exc:
        parser.exit(1, f'Configuration failed: {exc}\n')
