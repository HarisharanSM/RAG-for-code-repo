import json
import tempfile
import unittest
from pathlib import Path
from contextlib import redirect_stdout, redirect_stderr
from io import StringIO
from repo_rag.config import Config
from repo_rag.cli import main

class ConfigTests(unittest.TestCase):
    def test_relative_paths_and_invalid_command(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d); (root/'repo').mkdir()
            p=root/'config.toml'; p.write_text('repo="repo"\n[commands]\nbuild=["python", "-V"]\n')
            cfg=Config.load(p)
            self.assertEqual(cfg.repo,root/'repo')
            p.write_text('repo="repo"\n[commands]\nbuild="python -V"\n')
            with self.assertRaises(ValueError): Config.load(p)
    def test_provider_config_backward_compatibility_and_validation(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d); (root/'repo').mkdir(); p = root/'config.toml'
            p.write_text('repo="repo"\n')
            cfg = Config.load(p)
            self.assertEqual(cfg.provider, 'ollama')
            self.assertTrue(cfg.logging_enabled)
            p.write_text('repo="repo"\nprovider="openai"\nllm_url="http://localhost:8000/v1"\nembedding_provider="ollama"\nembedding_url="http://localhost:11434"\napi_key_env="LOCAL_MODEL_KEY"\nlogging_enabled=false\n')
            cfg = Config.load(p)
            self.assertEqual(cfg.embedding_provider, 'ollama')
            self.assertFalse(cfg.logging_enabled)
            for extra in ('provider="unknown"', 'logging_enabled=1', 'api_key_env=5'):
                p.write_text('repo="repo"\n'+extra+'\n')
                with self.assertRaises(ValueError): Config.load(p)

    def test_cli_missing_config_friendly_error(self):
        err=StringIO()
        with redirect_stderr(err): rc=main(['--config','/nonexistent/repo-rag.toml','status'])
        self.assertEqual(rc,1); self.assertIn('Error:',err.getvalue())


class CLIExecutionTests(unittest.TestCase):
    def test_runner_nonzero_exit_is_reported(self):
        import sys
        with tempfile.TemporaryDirectory() as d:
            root=Path(d); (root/'repo').mkdir(); p=root/'config.toml'
            p.write_text('repo="repo"\n[commands]\nfail=[' + json.dumps(sys.executable) + ', "-c", "raise SystemExit(7)"]\n')
            out=StringIO()
            with redirect_stdout(out): rc=main(['--config',str(p),'run','fail'])
            self.assertEqual(rc,1); self.assertIn('"returncode": 7',out.getvalue())
    def test_invalid_state_boundary_and_unknown_keys(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d); (root/'repo').mkdir(); p=root/'config.toml'
            for text in ('repo="repo"\nstate_dir="."\n', 'repo="repo"\nunexpected=1\n', 'repo="repo"\ntimeout="bad"\n'):
                p.write_text(text)
                with self.assertRaises(ValueError): Config.load(p)

if __name__=='__main__': unittest.main()
