import json
import tempfile
import unittest
from contextlib import redirect_stdout
from io import StringIO
from pathlib import Path
from repo_rag.config import Config
from repo_rag.telemetry import LoggedClient, record_event
from repo_rag.cli import main

class TelemetryTests(unittest.TestCase):
    def test_model_metadata_success_error_and_no_prompt_logged(self):
        class Client:
            last_call = {'provider':'openai', 'model':'local-test', 'token_usage':{'total_tokens':9}}
            def generate(self, prompt):
                if prompt == 'fail': raise RuntimeError('secret-key')
                return 'private-answer'
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            cfg = Config(root, root/'state')
            client = LoggedClient(cfg, Client())
            self.assertEqual(client.generate('private-prompt'), 'private-answer')
            with self.assertRaises(RuntimeError): client.generate('fail')
            raw = (cfg.state_dir/'logs'/'requests.jsonl').read_text()
            self.assertNotIn('private', raw)
            self.assertNotIn('secret-key', raw)
            events = [json.loads(x) for x in raw.splitlines()]
            self.assertEqual([e['status'] for e in events], ['success', 'error'])
            self.assertEqual(events[0]['token_usage'], {'total_tokens':9})
            self.assertEqual(events[0]['model'], 'local-test')
            self.assertGreaterEqual(events[0]['elapsed_ms'], 0)
            record_event(cfg, {'operation':'search', 'prompt':'private-prompt'})
            self.assertNotIn('private', (cfg.state_dir/'logs'/'requests.jsonl').read_text())
            cfg.logging_enabled = False
            before = (cfg.state_dir/'logs'/'requests.jsonl').read_bytes()
            client.generate('hidden')
            self.assertEqual(before, (cfg.state_dir/'logs'/'requests.jsonl').read_bytes())

    def test_cli_definition_search_json_and_logs_without_llm(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d); repo = root/'repo'; repo.mkdir()
            (repo/'can.cpp').write_text('int GetCANMessage() {\n    return 1;\n}\n')
            cfg = root/'config.toml'
            cfg.write_text('repo="repo"\nstate_dir="state"\n')
            out = StringIO()
            with redirect_stdout(out):
                code = main(['--config',str(cfg),'search','where get can message function is defined?'])
            self.assertEqual(code, 0)
            result = json.loads(out.getvalue())
            self.assertEqual(result['intent'], 'find_definition')
            self.assertEqual(result['matches'][0]['symbol'], 'GetCANMessage')
            self.assertEqual(result['matches'][0]['path'], 'can.cpp')
            self.assertIsNone(result['model'])
            self.assertIn('index_ms', result['timing'])
            event = json.loads((root/'state/logs/requests.jsonl').read_text().splitlines()[-1])
            self.assertEqual(event['operation'], 'search')
            self.assertEqual(event['request_id'], result['request_id'])
            self.assertEqual(event['match_count'], len(result['matches']))
            self.assertNotIn('GetCANMessage', json.dumps(event))

    def test_openai_workflow_json_timings_and_usage_logs(self):
        from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
        import threading
        from repo_rag.workflow import Workflow
        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *args): pass
            def do_POST(self):
                body = json.loads(self.rfile.read(int(self.headers['Content-Length'])))
                if self.path != '/v1/chat/completions':
                    self.send_error(404); return
                response = json.dumps({'choices':[{'message':{'content':'Defined [can.py:1-2].'}}],
                                       'usage':{'prompt_tokens':10,'completion_tokens':3,'total_tokens':13}}).encode()
                self.send_response(200); self.send_header('Content-Length',str(len(response)))
                self.end_headers(); self.wfile.write(response)
        server = ThreadingHTTPServer(('127.0.0.1',0),Handler)
        threading.Thread(target=server.serve_forever,daemon=True).start()
        self.addCleanup(server.server_close); self.addCleanup(server.shutdown)
        with tempfile.TemporaryDirectory() as d:
            root=Path(d); repo=root/'repo'; repo.mkdir()
            (repo/'can.py').write_text('def get_can_message():\n    return 1\n')
            cfg=Config(repo,root/'state',provider='openai',llm_url=f'http://127.0.0.1:{server.server_port}/v1',model='test-open-weight')
            result=Workflow(cfg).run('where get can message function is defined?')
            self.assertEqual(result['model']['provider'],'openai')
            self.assertEqual(result['model']['model'],'test-open-weight')
            self.assertEqual(result['model']['token_usage']['total_tokens'],13)
            self.assertGreaterEqual(result['timing']['total_ms'],result['timing']['model_ms'])
            self.assertGreaterEqual(result['timing']['retrieval_ms'],0)
            events=[json.loads(x) for x in (cfg.state_dir/'logs/requests.jsonl').read_text().splitlines()]
            self.assertEqual([e['operation'] for e in events],['generate','analyze'])
            self.assertEqual(events[-1]['request_id'],result['request_id'])
            self.assertNotIn('Defined',json.dumps(events))


class ToolLoggingTests(unittest.TestCase):
    def test_preserves_signature_result_and_logs_all_result_failures(self):
        import inspect
        from repo_rag.telemetry import instrument_tool
        with tempfile.TemporaryDirectory() as d:
            root=Path(d); cfg=Config(root,root/'state')
            @instrument_tool(cfg, 'run_command')
            def command(name: str, worktree: str | None = None) -> dict:
                if name == 'timeout': return {'timed_out':True,'stdout':'private-source'}
                if name == 'exit': return {'returncode':7,'stderr':'secret-key'}
                if name == 'patch': return {'applied':False,'error':'private-patch'}
                if name == 'index': return {'embedding_error':'secret-endpoint'}
                if name == 'error': raise ValueError('private-argument')
                return {'returncode':0,'stdout':'private-source'}
            self.assertEqual(list(inspect.signature(command).parameters),['name','worktree'])
            self.assertEqual(command('ok'),{'returncode':0,'stdout':'private-source'})
            for name in ('timeout','exit','patch','index'):command(name)
            with self.assertRaises(ValueError):command('error')
            path=cfg.state_dir/'logs/requests.jsonl'
            raw=path.read_text(); events=[json.loads(x) for x in raw.splitlines()]
            self.assertEqual([x['status'] for x in events],['success']+['error']*5)
            self.assertEqual([x.get('error_type') for x in events],
                             [None,'timeout','nonzero_exit','patch_rejected','embedding_error','ValueError'])
            self.assertTrue(all(x['transport']=='mcp' and x['event']=='tool' for x in events))
            self.assertTrue(all(x['model'] is None for x in events))
            self.assertTrue(all(x['elapsed_ms']>=0 for x in events))
            for text in ('private','secret','stdout','stderr'):self.assertNotIn(text,raw)
            cfg.logging_enabled=False; before=path.read_bytes();command('ok')
            self.assertEqual(path.read_bytes(),before)

    def test_workflow_metadata_and_request_id_reused_without_content(self):
        from repo_rag.telemetry import instrument_tool
        with tempfile.TemporaryDirectory() as d:
            root=Path(d); cfg=Config(root,root/'state')
            result={'answer':'private-answer','sources':['private-source'],'patch':'private-patch',
                    'request_id':'workflow-id','model':{'provider':'ollama','model':'local-model',
                    'status':'success','elapsed_ms':2,'token_usage':None,'prompt':'private-prompt'}}
            @instrument_tool(cfg,'develop')
            def develop(task: str) -> dict:return result
            self.assertIs(develop('private-task'),result)
            event=json.loads((cfg.state_dir/'logs/requests.jsonl').read_text())
            self.assertEqual(event['request_id'],'workflow-id')
            self.assertEqual(event['model']['model'],'local-model')
            self.assertNotIn('prompt',event['model'])
            self.assertNotIn('private',json.dumps(event))

    def test_log_write_failure_never_masks_tool_result_or_error(self):
        import warnings
        from unittest.mock import patch
        from repo_rag.telemetry import instrument_tool
        with tempfile.TemporaryDirectory() as d:
            root=Path(d); cfg=Config(root,root/'state')
            @instrument_tool(cfg,'source')
            def source(path: str) -> dict:
                if path == 'fail':raise ValueError('original-error')
                return {'text':'source-result'}
            with patch('repo_rag.telemetry.os.open',side_effect=PermissionError('private-path')):
                with warnings.catch_warnings():
                    warnings.simplefilter('error')
                    self.assertEqual(source('main.py'),{'text':'source-result'})
                    with self.assertRaisesRegex(ValueError,'original-error'):source('fail')
