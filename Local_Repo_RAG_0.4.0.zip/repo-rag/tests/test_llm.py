import io
import json
import os
import tempfile
import threading
import unittest
from http.client import HTTPException
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from unittest.mock import patch
from urllib.error import HTTPError, URLError

from repo_rag.config import Config
from repo_rag.llm import (OllamaClient, OllamaError, OpenAICompatibleClient,
                          OpenAIError, ModelError, create_client)


class FakeOpener:
    def __init__(self, response):
        self.response = response
        self.calls = []

    def open(self, req, timeout):
        self.calls.append((req, timeout))
        if isinstance(self.response, Exception):
            raise self.response
        return io.BytesIO(json.dumps(self.response).encode("utf-8"))


class OllamaClientTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        root = Path(self.temp.name)
        self.config = Config(repo=root, state_dir=root / "state", timeout=7,
                             embedding_model="embed-model")

    def test_generate_posts_nonstreaming_with_timeout(self):
        client = OllamaClient(self.config)
        client._opener = fake = FakeOpener({"response": "Answer"})
        self.assertEqual(client.generate("question"), "Answer")
        req, timeout = fake.calls[0]
        self.assertEqual(req.full_url, "http://127.0.0.1:11434/api/generate")
        self.assertEqual(timeout, 7)
        self.assertEqual(json.loads(req.data), {
            "model": self.config.model, "prompt": "question", "stream": False,
        })

    def test_embed_uses_embedding_model_and_validates_shape(self):
        client = OllamaClient(self.config)
        client._opener = fake = FakeOpener({"embeddings": [[1, 2], [3, 4.5]]})
        self.assertEqual(client.embed(["a", "b"]), [[1.0, 2.0], [3.0, 4.5]])
        self.assertEqual(json.loads(fake.calls[0][0].data), {
            "model": "embed-model", "input": ["a", "b"],
        })
        self.assertEqual(client.embed([]), [])
        self.assertEqual(len(fake.calls), 1)
        fake.response = {"embeddings": [[float("nan")]]}
        with self.assertRaises(OllamaError):
            client.embed(["a"])

    def test_rejects_nonloopback_and_credentials_by_default(self):
        for url in ("http://example.com:11434", "http://192.0.2.1:11434",
                    "http://user:pass@127.0.0.1:11434", "http://localhost:11434/x"):
            with self.subTest(url=url), self.assertRaises(ValueError):
                OllamaClient(Config(repo=self.config.repo, state_dir=self.config.state_dir,
                                    llm_url=url))
        self.config.llm_url = "http://example.com:11434"
        self.config.allow_remote_model = True
        self.assertEqual(OllamaClient(self.config).base_url, self.config.llm_url)

    def test_connection_and_protocol_errors_are_explicit(self):
        client = OllamaClient(self.config)
        client._opener = FakeOpener(URLError("offline"))
        with self.assertRaisesRegex(OllamaError, "Could not reach Ollama"):
            client.generate("hello")
        client._opener = FakeOpener({"error": "model unavailable"})
        with self.assertRaisesRegex(OllamaError, "model unavailable"):
            client.generate("hello")
        client._opener = FakeOpener({"embeddings": [[1], [1, 2]]})
        with self.assertRaisesRegex(OllamaError, "dimensions"):
            client.embed(["a", "b"])

    def test_real_loopback_transport_with_fake_model_endpoint(self):
        received = []

        class Handler(BaseHTTPRequestHandler):
            def do_POST(self):
                length = int(self.headers["Content-Length"])
                received.append((self.path, json.loads(self.rfile.read(length))))
                response = ({"response": "fake answer"} if self.path == "/api/generate"
                            else {"embeddings": [[0.25, 0.5]]})
                body = json.dumps(response).encode()
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)

            def log_message(self, *args):
                pass

        server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        self.addCleanup(thread.join, 2)
        self.addCleanup(server.server_close)
        self.addCleanup(server.shutdown)
        self.config.llm_url = f"http://127.0.0.1:{server.server_port}"
        client = OllamaClient(self.config)
        self.assertEqual(client.generate("prompt"), "fake answer")
        self.assertEqual(client.embed(["text"]), [[0.25, 0.5]])
        self.assertEqual([path for path, _ in received], ["/api/generate", "/api/embed"])


class OpenAIClientTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        root = Path(self.temp.name)
        self.config = Config(repo=root, state_dir=root / "state", timeout=7,
                             llm_url="http://127.0.0.1:8000/v1/",
                             model="chat-model", embedding_model="embed-model")
        self.config.provider = "openai"
        self.config.api_key_env = ""

    def test_chat_request_and_reported_usage(self):
        client = create_client(self.config)
        client._opener = fake = FakeOpener({
            "choices": [{"message": {"content": "answer"}}],
            "usage": {"prompt_tokens": 4, "completion_tokens": 2, "total_tokens": 6,
                      "unexpected": "secret", "prompt_tokens_details": {"cached_tokens": 1}},
        })
        self.assertEqual(client.generate("question"), "answer")
        req, timeout = fake.calls[0]
        self.assertEqual(req.full_url, "http://127.0.0.1:8000/v1/chat/completions")
        self.assertEqual(timeout, 7)
        self.assertEqual(json.loads(req.data), {
            "model": "chat-model", "messages": [{"role": "user", "content": "question"}],
            "stream": False,
        })
        self.assertEqual(client.last_call["provider"], "openai")
        self.assertEqual(client.last_call["model"], "chat-model")
        self.assertEqual(client.last_call["operation"], "generate")
        self.assertEqual(client.last_call["status"], "success")
        self.assertEqual(client.last_call["token_usage"], {
            "prompt_tokens": 4, "completion_tokens": 2, "total_tokens": 6,
        })
        self.assertGreaterEqual(client.last_call["elapsed_ms"], 0)
        self.assertNotIn("error_type", client.last_call)
        fake.response = {"choices": [{"message": {"content": "another"}}]}
        client.generate("again")
        self.assertIsNone(client.last_call["token_usage"])

    def test_embeddings_are_ordered_by_input_index(self):
        client = create_client(self.config, purpose="embedding")
        client._opener = fake = FakeOpener({"data": [
            {"index": 1, "embedding": [3, 4.5]}, {"index": 0, "embedding": [1, 2]},
        ], "usage": {"prompt_tokens": 3, "total_tokens": 3}})
        self.assertEqual(client.embed(["a", "b"]), [[1.0, 2.0], [3.0, 4.5]])
        self.assertEqual(fake.calls[0][0].full_url, "http://127.0.0.1:8000/v1/embeddings")
        self.assertEqual(json.loads(fake.calls[0][0].data), {
            "model": "embed-model", "input": ["a", "b"], "encoding_format": "float",
        })
        self.assertEqual(client.last_call["model"], "embed-model")
        self.assertEqual(client.last_call["operation"], "embed")
        self.assertEqual(client.embed([]), [])
        self.assertEqual(len(fake.calls), 1)
        self.assertIsNone(client.last_call["token_usage"])

    def test_invalid_embedding_shapes_and_indices(self):
        client = create_client(self.config)
        malformed = [
            {"data": []},
            {"data": [{"index": 0, "embedding": [1]}, {"index": 0, "embedding": [2]}]},
            {"data": [{"index": -1, "embedding": [1]}, {"index": 1, "embedding": [2]}]},
            {"data": [{"index": True, "embedding": [1]}, {"index": 0, "embedding": [2]}]},
            {"data": [{"index": 0, "embedding": [1]}, {"index": 1, "embedding": [2, 3]}]},
            {"data": [{"index": 0, "embedding": [1]}, {"index": 1, "embedding": [False]}]},
            {"data": [{"index": 0, "embedding": [1]}, {"index": 1, "embedding": [float("inf")]}]},
            {"data": [{"index": 0, "embedding": []}, {"index": 1, "embedding": [2]}]},
            {"data": [{"embedding": [1]}, {"index": 1, "embedding": [2]}]},
        ]
        for response in malformed:
            with self.subTest(response=response):
                client._opener = FakeOpener(response)
                with self.assertRaises(OpenAIError):
                    client.embed(["a", "b"])
                self.assertEqual(client.last_call["status"], "error")
                self.assertEqual(client.last_call["error_type"], "protocol_error")

    def test_factory_routes_embedding_overrides_without_mutating_config(self):
        self.config.embedding_provider = "ollama"
        self.config.embedding_url = "http://127.0.0.1:11434"
        self.config.embedding_api_key_env = "REPO_RAG_EMBED_TEST_KEY"
        client = create_client(self.config, purpose="embedding")
        self.assertIsInstance(client, OllamaClient)
        self.assertEqual(client.base_url, "http://127.0.0.1:11434")
        self.assertEqual(client.config.api_key_env, "REPO_RAG_EMBED_TEST_KEY")
        self.assertEqual(self.config.llm_url, "http://127.0.0.1:8000/v1/")
        self.assertEqual(self.config.api_key_env, "")
        self.config.embedding_provider = ""
        self.config.embedding_url = ""
        self.config.embedding_api_key_env = ""
        self.config.api_key_env = "REPO_RAG_GENERATE_TEST_KEY"
        self.config.embedding_model = ""
        client = create_client(self.config, purpose="embedding")
        self.assertIsInstance(client, OpenAICompatibleClient)
        self.assertEqual(client.config.api_key_env, "REPO_RAG_GENERATE_TEST_KEY")
        client._opener = fake = FakeOpener({"data": [{"index": 0, "embedding": [1]}]})
        with patch.dict(os.environ, {"REPO_RAG_GENERATE_TEST_KEY": "test-key"}):
            client.embed(["a"])
        self.assertEqual(json.loads(fake.calls[0][0].data)["model"], "chat-model")
        self.assertEqual(client.last_call["model"], "chat-model")
        for purpose in ("embed", "", None):
            with self.assertRaises(ValueError):
                create_client(self.config, purpose=purpose)
        self.config.provider = "unsupported"
        with self.assertRaises(ValueError):
            create_client(self.config)

    def test_optional_auth_and_unset_key_are_safe(self):
        client = create_client(self.config)
        client._opener = fake = FakeOpener({"choices": [{"message": {"content": "answer"}}]})
        client.generate("question")
        self.assertIsNone(fake.calls[0][0].get_header("Authorization"))
        self.config.api_key_env = "REPO_RAG_TEST_KEY"
        with patch.dict(os.environ, {"REPO_RAG_TEST_KEY": "private-test-secret"}):
            client.generate("question")
        self.assertEqual(fake.calls[-1][0].get_header("Authorization"), "Bearer private-test-secret")
        with patch.dict(os.environ, {}, clear=True):
            with self.assertRaisesRegex(OpenAIError, "unset or invalid"):
                client.generate("question")
        self.assertEqual(len(fake.calls), 2)
        self.assertEqual(client.last_call["error_type"], "authentication")
        for value in ("key\nmalicious-header", "private-\u00e9"):
            with patch.dict(os.environ, {"REPO_RAG_TEST_KEY": value}):
                with self.assertRaises(OpenAIError) as raised:
                    client.generate("question")
                self.assertNotIn(value, str(raised.exception))

    def test_errors_and_metadata_do_not_echo_remote_secrets(self):
        client = create_client(self.config)
        secret = "private-test-secret"
        cases = [
            (URLError(secret), "connection_error"),
            (HTTPException(secret), "protocol_error"),
            (TimeoutError(secret), "timeout"),
            (URLError(TimeoutError(secret)), "timeout"),
            (HTTPError(client.base_url, 401, secret, {}, io.BytesIO(secret.encode())), "http_error"),
            ({"error": {"message": secret}}, "server_error"),
            ({"choices": [{"message": {"content": None}}]}, "protocol_error"),
        ]
        for response, category in cases:
            with self.subTest(category=category):
                client._opener = FakeOpener(response)
                with self.assertRaises(ModelError) as raised:
                    client.generate("question")
                self.assertNotIn(secret, str(raised.exception))
                self.assertNotIn(secret, json.dumps(client.last_call))
                self.assertEqual(client.last_call["error_type"], category)
                self.assertEqual(client.last_call["status"], "error")
        with self.assertRaises(TypeError):
            client.generate(None)
        self.assertEqual(client.last_call["error_type"], "invalid_input")

    def test_loopback_guard_allows_openai_base_paths(self):
        for url in ("http://example.com/v1", "http://user:pass@localhost/v1",
                    "http://localhost/v1?key=secret", "http://localhost/v1#fragment",
                    "http://localhost:0/v1", "http://localhost/\nsecret", "ftp://localhost/v1"):
            with self.subTest(url=url), self.assertRaises(ValueError):
                cfg = Config(repo=self.config.repo, state_dir=self.config.state_dir, llm_url=url)
                OpenAICompatibleClient(cfg)
        self.config.llm_url = "https://example.com/v1"
        self.config.allow_remote_model = True
        self.assertEqual(create_client(self.config).base_url, self.config.llm_url)

    def test_response_size_and_invalid_json_are_bounded(self):
        class RawOpener:
            def __init__(self, raw):
                self.raw = raw
                self.read_sizes = []

            def open(inner, req, timeout):
                raw = inner.raw
                sizes = inner.read_sizes

                class Response(io.BytesIO):
                    def read(self, size=-1):
                        sizes.append(size)
                        return super().read(size)

                return Response(raw)

        client = create_client(self.config)
        for raw in (b"not-json", b"[]", b"\xff", b'{"x":' + b'1' * 5000 + b'}'):
            client._opener = fake = RawOpener(raw)
            with self.assertRaises(OpenAIError):
                client.generate("question")
            self.assertEqual(fake.read_sizes, [16 * 1024 * 1024 + 1])
        client._opener = RawOpener(b"x" * (16 * 1024 * 1024 + 1))
        with self.assertRaisesRegex(OpenAIError, "exceeds"):
            client.generate("question")
        self.assertEqual(client.last_call["error_type"], "response_too_large")

    def test_real_transport_auth_base_path_and_redirect_block(self):
        received = []

        class Handler(BaseHTTPRequestHandler):
            def do_POST(self):
                payload = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
                received.append((self.path, payload, self.headers.get("Authorization")))
                if payload.get("model") == "redirect":
                    self.send_response(307)
                    self.send_header("Location", "/must-not-be-called")
                    self.end_headers()
                    return
                response = ({"choices": [{"message": {"content": "fixture answer"}}]}
                            if self.path.endswith("/chat/completions") else
                            {"data": [{"index": 0, "embedding": [0.25, 0.5]}]})
                body = json.dumps(response).encode()
                self.send_response(200)
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)

            def log_message(self, *args):
                pass

        server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        self.addCleanup(thread.join, 2)
        self.addCleanup(server.server_close)
        self.addCleanup(server.shutdown)
        self.config.llm_url = f"http://127.0.0.1:{server.server_port}/v1"
        self.config.api_key_env = "REPO_RAG_TEST_KEY"
        with patch.dict(os.environ, {"REPO_RAG_TEST_KEY": "fixture-key",
                                     "http_proxy": "http://127.0.0.1:1",
                                     "https_proxy": "http://127.0.0.1:1", "no_proxy": ""}):
            client = create_client(self.config)
            self.assertEqual(client.generate("question"), "fixture answer")
            self.assertEqual(client.embed(["text"]), [[0.25, 0.5]])
            self.config.model = "redirect"
            with self.assertRaises(ModelError):
                client.generate("question")
        self.assertEqual([path for path, _, _ in received], [
            "/v1/chat/completions", "/v1/embeddings", "/v1/chat/completions",
        ])
        self.assertTrue(all(auth == "Bearer fixture-key" for _, _, auth in received))
        self.assertEqual(client.last_call["error_type"], "redirect")


class OllamaMetadataTests(unittest.TestCase):
    def test_usage_is_reported_without_estimating_tokens(self):
        config = Config(repo=Path("."), state_dir=Path("state"))
        client = OllamaClient(config)
        client._opener = fake = FakeOpener({"response": "answer", "prompt_eval_count": 4, "eval_count": 2})
        client.generate("question")
        self.assertEqual(client.last_call["token_usage"], {"prompt_tokens": 4, "completion_tokens": 2})
        fake.response = {"embeddings": [[1]], "prompt_eval_count": 3}
        client.embed(["text"])
        self.assertEqual(client.last_call["token_usage"], {"prompt_tokens": 3})
        fake.response = {"response": "answer", "prompt_eval_count": True, "eval_count": -1}
        client.generate("question")
        self.assertIsNone(client.last_call["token_usage"])


if __name__ == "__main__":
    unittest.main()
