import subprocess
import hashlib
import sqlite3
import sys
import tempfile
import types
import unittest
from pathlib import Path
from unittest.mock import patch

from repo_rag.config import Config
from repo_rag.index import Index, is_allowed_source


class IndexTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.repo = self.root / "repo"
        self.repo.mkdir()
        self.config = Config(repo=self.repo, state_dir=self.root / "state", chunk_lines=10)

    def write(self, name, content):
        path = self.repo / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")
        return path

    def test_shared_source_admission_policy(self):
        self.config.excludes = ["docs/private/*"]
        self.assertTrue(is_allowed_source(self.config, "src/main.py"))
        for path in (".env", "keys/id_ed25519", "src/private.pem", "node_modules/pkg/index.js",
                     "docs/private/notes.md", "src/minified.min.js", "src/data.bin", "../outside.py",
                     "C:/outside.py", "C:outside.py", "src/x.py:stream", ".GIT/config",
                     "src/.GiT/config", ".git./config", ".git /config", "NUL.py", "CON/file.py"):
            with self.subTest(path=path):
                self.assertFalse(is_allowed_source(self.config, path))
        self.assertEqual(Index(self.config)._allowed("src/main.py"),
                         is_allowed_source(self.config, "src/main.py"))

    def test_incremental_freshness_and_source_evidence(self):
        self.write("src/main.py", "import helper\n\ndef answer():\n    return 'quartz token'\n")
        self.write("helper.py", "def utility():\n    return 42\n")
        index = Index(self.config)
        first = index.index()
        self.assertEqual((first["added"], first["chunks"]), (2, 3))
        hits = index.search("quartz")
        self.assertEqual(len(hits), 1)
        self.assertEqual((hits[0]["path"], hits[0]["start_line"], hits[0]["end_line"]),
                         ("src/main.py", 3, 4))
        self.assertEqual(hits[0]["symbol"], "answer")
        self.assertEqual(index.symbols("answer")[0]["text"], hits[0]["text"])
        self.assertEqual(index.index()["unchanged"], 2)
        self.write("src/main.py", "import helper\n\ndef answer():\n    return 'topaz token'\n")
        (self.repo / "helper.py").unlink()
        changed = index.index()
        self.assertEqual((changed["updated"], changed["deleted"]), (1, 1))
        self.assertFalse(index.search("quartz"))
        self.assertEqual(index.search("topaz")[0]["start_line"], 3)
        self.assertEqual(index.status()["files"], 1)

    def test_gitignore_excludes_secrets_symlinks_and_generated(self):
        subprocess.run(["git", "init", "-q", str(self.repo)], check=True)
        self.write(".gitignore", "ignored.py\n")
        self.write("ignored.py", "def ignored(): pass\n")
        self.write(".env", "password=hidden\n")
        self.write("secret.pem", "private material\n")
        self.write("node_modules/pkg/index.js", "export function generated() {}\n")
        self.write("src/code.py", "def visible(): return 'retrievable'\n")
        index = Index(self.config)
        index.index()
        self.assertEqual(index.status()["files"], 1)
        self.assertEqual(index.search("retrievable")[0]["path"], "src/code.py")
        self.assertFalse(index.search("hidden"))

    def test_symlink_is_excluded_when_creation_is_available(self):
        self.write("src/code.py", "def visible(): return 'retrievable'\n")
        try:
            (self.repo / "symlink.py").symlink_to(self.repo / "src/code.py")
        except OSError as exc:
            self.skipTest(f"Symlink creation unavailable: {exc}")
        index = Index(self.config)
        index.index()
        self.assertEqual(index.status()["files"], 1)
        self.assertEqual(index.search("retrievable")[0]["path"], "src/code.py")

    def test_semantic_chunks_and_local_dependency_links(self):
        self.write("src/one.ts", "import { run } from './two';\n\nexport function first() {\n  return run();\n}\n")
        self.write("src/two.ts", "export function run() { return 'needle'; }\n")
        self.write("README.md", "# Overview\nDocumentation\n## Detail\nMore details\n")
        self.config.links = [{"source": "README.md", "target": "src/*.ts", "label": "explains"}]
        index = Index(self.config)
        index.index()
        self.assertEqual([h["symbol"] for h in index.symbols("Detail")], ["Detail"])
        related = index.related("src/one.ts")
        self.assertTrue(any(r.get("resolved_path") == "src/two.ts" and r["line"] == 1 for r in related))
        explicit = index.related("README.md")
        self.assertEqual({r["resolved_path"] for r in explicit}, {"src/one.ts", "src/two.ts"})
        self.assertTrue(all(r["label"] == "explains" for r in explicit))
        self.assertEqual(index.search("needle", language="typescript")[0]["path"], "src/two.ts")
        self.assertFalse(index.search("needle", language="python"))
        self.assertEqual(index.file_chunks("src/two.ts")[0]["start_line"], 1)

    def test_shared_state_replaces_other_repository_and_large_file(self):
        self.write("same.py", "def old(): return 'obsolete'\n")
        index = Index(self.config)
        index.index()
        another = self.root / "another"
        another.mkdir()
        (another / "same.py").write_text("def fresh(): return 'current'\n")
        other_config = Config(repo=another, state_dir=self.config.state_dir, chunk_lines=10,
                              max_file_bytes=100)
        other_index = Index(other_config)
        self.assertEqual(other_index.index()["added"], 1)
        self.assertFalse(other_index.search("obsolete"))
        self.assertEqual(other_index.search("current")[0]["path"], "same.py")
        (another / "same.py").write_text("x" * 101)
        self.assertEqual(other_index.index()["deleted"], 1)
        self.assertFalse(other_index.search("current"))

    def test_embeddings_reuse_and_invalidation(self):
        self.write("a.py", "def alpha():\n    return 'plain text'\n")
        self.config.embedding_model = "embed-a"

        class FakeClient:
            calls = []

            def __init__(self, config):
                self.config = config

            def embed(self, texts):
                self.calls.append((self.config.embedding_model, len(texts)))
                return [[1.0, 0.0] for _ in texts]

        fake_module = types.ModuleType("repo_rag.llm")
        fake_module.create_client = lambda config, purpose="generation": FakeClient(config)
        with patch.dict(sys.modules, {"repo_rag.llm": fake_module}):
            index = Index(self.config)
            self.assertEqual(index.index()["embedded"], 1)
            self.assertEqual(index.index()["embedded"], 0)
            self.assertEqual(len(FakeClient.calls), 1)
            self.assertEqual(index.search("semantic", limit=1)[0]["path"], "a.py")
            self.config.model = "another-generation-model"
            self.assertEqual(index.index()["embedded"], 0)
            self.assertEqual(len(FakeClient.calls), 2)  # initial index and semantic query
            self.config.embedding_model = "embed-b"
            self.assertEqual(index.index()["embedded"], 1)
            self.assertEqual(FakeClient.calls[-1][0], "embed-b")
            self.assertEqual(index.status()["embedded"], 1)
            self.config.embedding_provider = "openai_compatible"
            self.assertEqual(index.index()["embedded"], 1)
            self.config.embedding_url = "http://127.0.0.1:4321/v1"
            self.assertEqual(index.index()["embedded"], 1)
            self.config.llm_url = "http://127.0.0.1:9999"
            self.assertEqual(index.index()["embedded"], 0)  # dedicated embedding URL wins
            self.assertIsNotNone(index.search_result("semantic")["model"])

    def test_natural_language_definition_queries_rank_names_and_ignore_boilerplate(self):
        self.write("calls.py", "def invoke():\n    get_can_message(1)\n")
        self.write("can.py", "def get_can_message(\n    channel: int,\n):\n    return None\n")
        self.write("near.py", "def get_message(): return 1\ndef get_can_payload(): return 2\n")
        self.write("noise.md", "# Function\nWhere a function is defined, the source is code.\n")
        index = Index(self.config)
        index.index()
        for query in ("where get can message function is defined?", "Where is get_can_message defined???",
                      "please find the definition of GetCANMessage()", "GET_CAN_MESSAGE definition",
                      "find getcanmessage function",
                      "Can you please find where get can message function is defined?"):
            with self.subTest(query=query):
                result = index.search_result(query)
                self.assertEqual(result["query"], query)
                self.assertEqual(result["intent"], "find_definition")
                self.assertIsNone(result["model"])
                hit = result["matches"][0]
                self.assertEqual((hit["path"], hit["symbol"], hit["kind"], hit["start_line"]),
                                 ("can.py", "get_can_message", "definition", 1))
                self.assertEqual(hit["text"], hit["excerpt"])
                self.assertIn("identifier", hit["match_reason"])
                self.assertTrue(all(h["path"] not in {"near.py", "noise.md"} for h in result["matches"]))
                self.assertGreaterEqual(result["timing"]["total_ms"], 0)
                references = [h for h in result["matches"] if h["path"] == "calls.py"]
                self.assertEqual(references[0]["kind"], "reference")
        self.assertIsInstance(index.search("GetCANMessage"), list)

    def test_definition_queries_support_multiline_cpp_csharp_and_typescript(self):
        fixtures = {
            "bus.cpp": ("CANMessage GetCANMessage(\n    int channel,\n    bool cached\n) const\n"
                        "{\n    return {};\n}\n"
                        "CANMessage GetCANMessage(int channel);\n"
                        "void invoke() {\n    GetCANMessage(1);\n    return GetCANMessage(2);\n}\n"),
            "Bus.cs": ("public class Bus {\n public System.Object GetCANMessage(\n int channel\n )\n"
                       " { return null; }\n public object GetCANMessage(string channel) => null;\n"
                       " public abstract object GetCANMessage(bool cached);\n"
                       " private void Invoke() {\n GetCANMessage(1);\n }\n}\n"),
            "bus.ts": ("export function getCANMessage(\n channel: number\n): Message {\n return {channel};\n}\n"
                       "export function getCANMessage(channel: string): Message;\n"
                       "function invoke() {\n getCANMessage(1);\n}\n"),
        }
        for name, content in fixtures.items():
            self.write(name, content)
        index = Index(self.config)
        index.index()
        for language, path, expected_line in (("cpp", "bus.cpp", 1), ("csharp", "Bus.cs", 2),
                                              ("typescript", "bus.ts", 1)):
            with self.subTest(language=language):
                hits = index.search_result("where get can message function is defined?", language=language)["matches"]
                self.assertEqual((hits[0]["path"], hits[0]["start_line"], hits[0]["kind"]),
                                 (path, expected_line, "definition"))
                self.assertTrue(any(h["kind"] == "declaration" for h in hits))
                self.assertTrue(any(h["kind"] == "reference" for h in hits))
                self.assertTrue(all(h["kind"] != "definition" for h in hits if h["symbol"].lower() == "invoke"))
        cs_definitions = index.search_result("definition GetCANMessage", language="csharp")["matches"]
        self.assertEqual([h["start_line"] for h in cs_definitions if h["kind"] == "definition"], [2, 6])

    def test_calls_and_comments_do_not_create_definitions(self):
        self.write("calls.ts", "getCANMessage(1)\nfunction unrelated() { return 1; }\n"
                   "// function getCANMessage() {}\nconst text = 'function getCANMessage() {}';\n")
        self.write("calls.cpp", "void invoke() {\n if (GetCANMessage(1)) { }\n"
                   " return GetCANMessage(2);\n}\n// CANMessage GetCANMessage() {}\n")
        index = Index(self.config)
        index.index()
        hits = index.search_result("definition get can message")["matches"]
        self.assertTrue(hits)
        self.assertFalse(any(h["kind"] in {"definition", "declaration"} for h in hits))

    def test_empty_ambiguous_and_no_match_results(self):
        self.write("one.py", "def get_can_message(): return 1\n")
        self.write("two.py", "def get_can_message(): return 2\n")
        index = Index(self.config)
        index.index()
        result = index.search_result("definition get can message")
        self.assertEqual([(h["path"], h["kind"]) for h in result["matches"]],
                         [("one.py", "definition"), ("two.py", "definition")])
        self.assertEqual(index.search_result("definition nonexistent name")["matches"], [])
        self.assertEqual(index.search(""), [])
        self.assertEqual(index.search("get_can_message", limit=0), [])
        for args, error in ((("",), ValueError), ((None,), TypeError),
                            (("get_can_message", 0), ValueError), (("get_can_message", True), TypeError),
                            (("get_can_message", 8, ""), ValueError)):
            with self.subTest(args=args), self.assertRaises(error):
                index.search_result(*args)

    def test_long_symbol_continuation_is_not_labeled_definition(self):
        self.write("one.py", "def get_can_message():\n" + "    value = 1\n" * 15 + "    return value\n")
        index = Index(self.config)
        index.index()
        hits = index.search_result("definition get_can_message")["matches"]
        self.assertEqual([h["start_line"] for h in hits if h["kind"] == "definition"], [1])
        self.assertTrue(any(h["kind"] == "reference" for h in hits))

    def test_old_database_migrates_and_reindexes_unchanged_source(self):
        content = "def get_can_message(): return 1\n"
        self.write("one.py", content)
        self.config.state_dir.mkdir()
        with sqlite3.connect(self.config.state_dir / "index.sqlite3") as db:
            db.executescript("""
                CREATE TABLE meta(key TEXT PRIMARY KEY,value TEXT NOT NULL);
                CREATE TABLE files(path TEXT PRIMARY KEY,sha256 TEXT NOT NULL,language TEXT NOT NULL);
                CREATE TABLE chunks(id INTEGER PRIMARY KEY,path TEXT NOT NULL REFERENCES files(path) ON DELETE CASCADE,
                    start_line INTEGER NOT NULL,end_line INTEGER NOT NULL,text TEXT NOT NULL,language TEXT NOT NULL,
                    symbol TEXT,embedding TEXT);
                CREATE VIRTUAL TABLE chunks_fts USING fts5(text,symbol,content='chunks',content_rowid='id');
            """)
            db.execute("INSERT INTO meta VALUES('layout',?)", ('{"chunk_lines": 10}',))
            db.execute("INSERT INTO files VALUES(?,?,?)", ("one.py", hashlib.sha256(content.encode()).hexdigest(), "python"))
            db.execute("INSERT INTO chunks VALUES(1,'one.py',1,1,?,'python','get_can_message',NULL)", (content,))
            db.execute("INSERT INTO chunks_fts(chunks_fts) VALUES('rebuild')")
        index = Index(self.config)
        self.assertEqual(index.index()["updated"], 1)
        self.assertEqual(index.index()["unchanged"], 1)
        self.assertEqual(index.search_result("definition get can message")["matches"][0]["kind"], "definition")
        # A reopened index reuses persisted segmented FTS state.
        self.assertEqual(Index(self.config).search("GetCANMessage")[0]["path"], "one.py")


if __name__ == "__main__":
    unittest.main()
