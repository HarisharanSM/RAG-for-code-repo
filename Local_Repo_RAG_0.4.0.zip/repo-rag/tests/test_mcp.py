import json
import asyncio
import importlib.util
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from unittest.mock import patch
import unittest

from repo_rag.config import Config
from repo_rag.mcp_server import build_server


@unittest.skipUnless(importlib.util.find_spec("mcp"), "optional MCP SDK is unavailable")
class MCPTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.repo = self.root / "repo"
        self.repo.mkdir()
        subprocess.run(["git", "init", "-q"], cwd=self.repo, check=True)
        subprocess.run(["git", "config", "core.autocrlf", "false"], cwd=self.repo, check=True)
        (self.repo / "main.py").write_bytes(b"def greet():\n    return 'hello'\n")
        subprocess.run(["git", "add", "main.py"], cwd=self.repo, check=True)
        subprocess.run(["git", "-c", "user.name=Test", "-c", "user.email=test@example.invalid",
                        "commit", "-qm", "Initial"], cwd=self.repo, check=True)
        self.config = Config(repo=self.repo, state_dir=self.root / "state")

    def test_tool_gates(self):
        async def names(server):
            return {tool.name for tool in await server.list_tools()}

        default = asyncio.run(names(build_server(self.config)))
        self.assertEqual(default, {"search", "source", "symbols", "related",
                                   "git_status", "git_diff", "git_history", "refresh_index",
                                   "index_status", "analyze", "review", "develop"})
        execution = asyncio.run(names(build_server(self.config, enable_execution=True)))
        self.assertEqual(execution - default, {"run_command"})
        both = asyncio.run(names(build_server(self.config, enable_execution=True, enable_writes=True)))
        self.assertEqual(both - default, {"run_command", "create_worktree", "apply_patch"})
        writes = asyncio.run(names(build_server(self.config, enable_writes=True)))
        self.assertEqual(writes - default, {"create_worktree", "apply_patch"})

    def tool_events(self):
        return [json.loads(line) for line in
                (self.config.state_dir / "logs/requests.jsonl").read_text().splitlines()
                if json.loads(line).get("event") == "tool"]

    def test_read_tools_do_not_construct_model_clients(self):
        self.config.llm_url = "invalid model endpoint"
        self.config.embedding_model = "embedding-enabled"
        with patch("repo_rag.llm.create_client", side_effect=AssertionError("eager client")):
            server = build_server(self.config)
            async def reads():
                await server.list_tools()
                await server.call_tool("source", {"path": "main.py"})
                await server.call_tool("index_status", {})
                await server.call_tool("git_status", {})
                self.config.embedding_model = ""
                await server.call_tool("refresh_index", {})
                await server.call_tool("search", {"query": "greet"})
                await server.call_tool("symbols", {"name": "greet"})
                await server.call_tool("related", {"path": "main.py"})
            asyncio.run(reads())

    def test_invalid_model_is_rejected_only_on_workflow_invocation(self):
        from mcp.server.fastmcp.exceptions import ToolError
        self.config.llm_url = "invalid model endpoint"
        server = build_server(self.config)
        async def invoke():
            with self.assertRaises(ToolError):
                await server.call_tool("analyze", {"task": "greet"})
        asyncio.run(invoke())
        event, = self.tool_events()
        self.assertEqual(event["operation"], "analyze")
        self.assertEqual(event["status"], "error")
        self.assertEqual(event["error_type"], "ValueError")
        self.assertIsNone(event["model"])

    def test_gated_tools_are_instrumented(self):
        self.config.commands = {"check": [sys.executable, "-c", "print('ok')"]}
        server = build_server(self.config, enable_execution=True, enable_writes=True)
        async def invoke():
            await server.call_tool("run_command", {"name": "check"})
            created = await server.call_tool("create_worktree", {})
            worktree = created[0].text if isinstance(created, list) else created[0][0].text
            proposed = "--- a/main.py\n+++ b/main.py\n@@ -1,2 +1,2 @@\n def greet():\n-    return 'hello'\n+    return 'hi'\n"
            await server.call_tool("apply_patch", {"patch": proposed, "worktree": worktree})
        asyncio.run(invoke())
        events = self.tool_events()
        self.assertEqual({e["operation"] for e in events}, {"run_command", "create_worktree", "apply_patch"})
        self.assertTrue(all(e["status"] == "success" and e["elapsed_ms"] >= 0 for e in events))
        self.assertEqual((self.repo / "main.py").read_text(), "def greet():\n    return 'hello'\n")

    def test_real_sdk_stdio_roundtrip(self):
        from mcp import ClientSession, StdioServerParameters
        from mcp.client.stdio import stdio_client

        config_file = self.root / "repo-rag.toml"
        prompts = []
        proposed_patch = "--- a/main.py\n+++ b/main.py\n@@ -1,2 +1,2 @@\n def greet():\n-    return 'hello'\n+    return 'hi'\n"

        class Handler(BaseHTTPRequestHandler):
            def do_POST(self):
                payload = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
                prompts.append(payload["prompt"])
                answer = "Found [main.py:1-2]."
                if "single fenced" in payload["prompt"]:
                    answer += "\n```diff\n" + proposed_patch + "```"
                body = json.dumps({"response": answer, "eval_count": 5}).encode()
                self.send_response(200)
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)

            def log_message(self, *args):
                pass

        model = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        thread = threading.Thread(target=model.serve_forever, daemon=True)
        thread.start()
        self.addCleanup(thread.join, 2)
        self.addCleanup(model.server_close)
        self.addCleanup(model.shutdown)
        config_file.write_text(f'repo = "repo"\nstate_dir = "state"\nllm_url = "http://127.0.0.1:{model.server_port}"\n')
        original_source = (self.repo / "main.py").read_bytes()
        original_head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=self.repo)
        project = Path(__file__).resolve().parents[1]
        env = dict(os.environ, PYTHONPATH=str(project / "src"))
        params = StdioServerParameters(command=sys.executable,
                                       args=["-m", "repo_rag", "--config", str(config_file), "mcp"],
                                       env=env)

        def envelope(response):
            return response.structuredContent or json.loads(response.content[0].text)

        async def roundtrip():
            async with stdio_client(params) as (reader, writer):
                async with ClientSession(reader, writer) as session:
                    await session.initialize()
                    tools = (await session.list_tools()).tools
                    tool_names = {tool.name for tool in tools}
                    for tool in tools:
                        if tool.name not in {"symbols", "related"}:
                            self.assertIsNotNone(tool.outputSchema)
                    self.assertIn("source", tool_names)
                    self.assertNotIn("apply_patch", tool_names)
                    result = await session.call_tool("source", {"path": "main.py", "start_line": 1, "end_line": 1})
                    self.assertFalse(result.isError, result)
                    self.assertIn("def greet():", str(result.content))
                    search = await session.call_tool("search", {"query": "greet"})
                    self.assertFalse(search.isError, search)
                    self.assertIn("main.py", str(search.content))
                    self.assertIsNotNone(search.structuredContent)
                    search_result = envelope(search)
                    self.assertEqual(search_result["query"], "greet")
                    self.assertEqual(search_result["matches"][0]["symbol"], "greet")
                    self.assertIsNone(search_result["model"])
                    self.assertIn("total_ms", search_result["timing"])
                    self.assertTrue((self.root / "state/logs/requests.jsonl").exists())
                    for name, arguments in (("refresh_index", {}), ("index_status", {}),
                                            ("symbols", {"name": "greet"}),
                                            ("related", {"path": "main.py"}),
                                            ("git_status", {}), ("git_diff", {}),
                                            ("git_history", {"limit": 1})):
                        response = await session.call_tool(name, arguments)
                        self.assertFalse(response.isError, response)
                        if name not in {"symbols", "related"}:
                            self.assertIsNotNone(response.structuredContent)
                        if name == "refresh_index":
                            self.assertEqual(envelope(response)["unchanged"], 1)
                        if name == "index_status":
                            self.assertEqual(envelope(response)["files"], 1)
                            self.assertGreater(envelope(response)["chunks"], 0)
                    for mode in ("analyze", "review", "develop"):
                        response = await session.call_tool(mode, {"task": "greet", "limit": 2})
                        self.assertFalse(response.isError, response)
                        self.assertIsNotNone(response.structuredContent)
                        result = envelope(response)
                        self.assertEqual(result["mode"], mode)
                        self.assertEqual(result["sources"][0]["citation"], "[main.py:1-2]")
                        self.assertIn("[main.py:1-2]", result["answer"])
                        self.assertEqual(result["model"]["provider"], "ollama")
                        self.assertIn("retrieval_ms", result["timing"])
                        self.assertIn("model_ms", result["timing"])
                        self.assertGreaterEqual(result["timing"]["total_ms"], 0)
                        if mode == "develop":
                            self.assertEqual(result["patch"], proposed_patch)
                    for mode in ("analyze", "review", "develop"):
                        invalid = await session.call_tool(mode, {"task": "greet", "limit": 0})
                        self.assertTrue(invalid.isError)
                    invalid = await session.call_tool("analyze", {"task": ""})
                    self.assertTrue(invalid.isError)
                    invalid = await session.call_tool("review", {})
                    self.assertTrue(invalid.isError)
                    invalid = await session.call_tool("source", {"path": "../private.txt"})
                    self.assertTrue(invalid.isError)

        asyncio.run(roundtrip())
        self.assertEqual(len(prompts), 3)
        self.assertEqual((self.repo / "main.py").read_bytes(), original_source)
        self.assertEqual(subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=self.repo), original_head)
        self.assertEqual(subprocess.check_output(["git", "status", "--porcelain"], cwd=self.repo), b"")
        self.assertFalse((self.config.state_dir / "worktrees").exists())
        events = self.tool_events()
        expected = {"source", "search", "symbols", "related", "git_status", "git_diff", "git_history",
                    "refresh_index", "index_status", "analyze", "review", "develop"}
        self.assertEqual({event["operation"] for event in events}, expected)
        for event in events:
            self.assertTrue(event["request_id"])
            self.assertGreaterEqual(event["elapsed_ms"], 0)
            self.assertEqual(event["transport"], "mcp")
            if event["status"] == "error":
                self.assertEqual(event["error_type"], "ValueError")
            elif event["operation"] in {"analyze", "review", "develop"}:
                self.assertEqual(event["model"]["provider"], "ollama")
            else:
                self.assertIsNone(event["model"])
        self.assertEqual(sum(event["status"] == "error" for event in events), 5)
        log = (self.config.state_dir / "logs/requests.jsonl").read_text()
        self.assertNotIn("return 'hello'", log)
        self.assertNotIn("private.txt", log)


if __name__ == "__main__":
    unittest.main()
