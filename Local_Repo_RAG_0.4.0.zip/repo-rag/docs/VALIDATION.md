# Release validation: 0.4.0

Authoring checks completed on 2026-10-05 using Python 3.12/Linux and MCP SDK 1.30.0.
Version 0.4 adds MCP parity tools and logging on every executed MCP tool.
Model adapters/query search from 0.3 and Windows/AWS support from 0.2 are retained.

## Completed evidence

- Linux suite: 76 tests ran; 73 passed and 3 skipped. The skips require Docker or native Windows filesystem behavior.
- Model adapter checks cover non-streaming Ollama/OpenAI-compatible generation, embeddings, index ordering, shape/finite-value validation, authentication from environment variables, loopback defaults, disabled redirects/proxies, response size limits and safe error metadata.
- Real loopback HTTP fixture endpoints were used for transport integration; these are simulated API responses, not actual model inference.
- Search checks cover the exact CAN-message question, camel/snake/compact identifier variants, mixed C++/C#/Python/TypeScript source, multiline signatures, overloads, definitions versus declarations/calls, comments/literals, long-chunk continuations, ambiguous names, no matches and incremental index migration.
- Logging checks cover success/error events, model identity, elapsed timings, reported usage, missing usage, disabled logging and omission of prompt/source/answer/key text.
- A real MCP SDK stdio roundtrip executes all 12 default tools, verifies output schemas/structuredContent for dictionary tools, and runs analyze/review/develop against a fake loopback model. Answers include citations/model/timing and develop returns a patch proposal without changing source/HEAD/Git status.
- Separate checks execute all three gated tools, apply a patch only to a managed worktree and verify the main checkout stays unchanged. Default and independently enabled tool gates are checked.
- MCP discovery/read/index retrieval does not construct the generation client; an invalid model URL fails only when a workflow is invoked. Tool argument/path failures are checked.
- Metadata logging covers all 15 executed tool types, exception failures, returned timeout/nonzero/patch/index failures, model metadata, disabled logging and log write failure even with warning-as-error settings.
- Workflow integration with an OpenAI-compatible loopback fixture verifies source retrieval, generation, model metadata and retrieval/model/total timings. Existing Ollama-to-worktree patch and configured execution integration remains passing.
- All Python source, deployment helpers and tests compile. The 0.4 wheel builds and installs without dependencies in an isolated environment; installed keyword definition search returns the expected source.

## Runtime limits

Native Windows and macOS runs remain pending. Docker, EC2, SSH MCP and GPU inference
were not exercised here. Platform CI configuration does not establish a passing run.
No actual local model weights were loaded. API compatibility does not establish
compatibility with every open-weight model server or model quality/latency.

Symbol classification remains heuristic, not compiler-resolved. Macros and unusual
signatures may be missed; overloads and duplicate names can return multiple candidates.
Large-repository performance and semantic retrieval quality have not been benchmarked.
Index refresh scans admitted source bytes, and vector search scans stored embeddings.
Commands retain the caller's filesystem/network permissions.

Logs are append-only without rotation. Reported token counts are API metadata,
not measured billing or subscription quota. Logs intentionally omit request content. SDK schema rejections before a tool
function begins are outside executed-tool instrumentation; unknown tool calls
are also outside it. Nested tool/workflow/model events must not be double-counted.

## Agent execution

MCP parity implementation: Sol gpt-6.1-sol/medium. The primary agent implemented
shared tool logging, reviewed/integrated MCP changes, verified results, updated
documentation and packaged the release. No escalation was used.
Live token telemetry was unavailable; no measured token/cost savings are claimed.
