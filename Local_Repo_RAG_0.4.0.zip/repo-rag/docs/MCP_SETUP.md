# MCP stdio setup

The optional MCP server exposes repository search, source reads, symbol and relationship lookup, Git status/diff/history, explicit indexing/status, and configured-model analyze/review/develop workflows. It uses stdio, so configure it in a compatible MCP host that can launch a local process.

Install the package with the MCP extra in the same Python environment the host will use:

```sh
python3 -m venv .venv
. .venv/bin/activate
python -m pip install '.[mcp]'
```

Create `repo-rag.toml` from the sample and set its `repo` to the target repository. For a reliable host launch, use absolute paths to both the virtual-environment Python executable and the TOML file. Example MCP server entry (adjust `/absolute/path/to/repo-rag`):

```json
{
  "mcpServers": {
    "repo-rag": {
      "command": "/absolute/path/to/repo-rag/.venv/bin/python",
      "args": [
        "-m",
        "repo_rag",
        "--config",
        "/absolute/path/to/repo-rag/repo-rag.toml",
        "mcp"
      ]
    }
  }
}
```

The package must also be installed into that interpreter's environment (editable install from the project root is fine). Do not use a shell wrapper; the host launches the executable with the listed arguments. MCP uses stdin/stdout for its protocol, so keep diagnostics on stderr.

Retrieval, Git read, index/status and model workflow tools are available by default; searches and workflows refresh the local index database. They do not expose repository patching or configured command execution. To expose configured command execution, add `--enable-execution` after `mcp`; it only runs names listed in `[commands]`. To expose worktree creation and patch application, add `--enable-writes`. These are independent opt-ins: `--enable-writes` does not enable command execution, and command execution does not enable writes. Example args with both enabled:

```json
"args": ["-m", "repo_rag", "--config", "/absolute/path/to/repo-rag/repo-rag.toml", "mcp", "--enable-execution", "--enable-writes"]
```

Treat execution as access to the configured command's ambient filesystem/network permissions. The runner bounds time and captured output but is not an OS sandbox. Use a restricted container or VM for untrusted code. Patch writes are limited to validated paths in a managed Git worktree.

The `source` and Git diff tools honor the source filename exclusions and omit the state directory. Git diff covers unstaged admitted files only; it does not expose excluded credential files. Files admitted by name may still contain sensitive data, so set project-specific exclusions and use a host you trust. Git tools require the configured repository to be the Git checkout root.

For Windows interpreter paths and AWS SSH stdio transport, use the platform-specific examples in [WINDOWS.md](WINDOWS.md) and [AWS.md](AWS.md).

## Model adapters and request logs

Version 0.3 supports native Ollama and OpenAI-compatible serving APIs, separate embedding configuration, natural-language definition search and JSON metadata logs. See [MODELS_AND_LOGGING.md](MODELS_AND_LOGGING.md). MCP search returns a structured object with a `matches` array; logs never use protocol stdout.

## Version 0.4 tool reference

| CLI capability | MCP tool | Arguments | Availability |
| --- | --- | --- | --- |
| index | refresh_index | none | Default |
| status | index_status | none | Default |
| search | search | query, limit=8, language=null | Default |
| read | source | path, start_line=1, end_line=null | Default |
| symbols | symbols | name | Default |
| related | related | path | Default |
| git status | git_status | none | Default |
| git diff | git_diff | none | Default |
| git history | git_history | limit=10 | Default |
| analyze | analyze | task, limit=8 | Default |
| review | review | task, limit=8 | Default |
| develop | develop | task, limit=8 | Default |
| run | run_command | name, worktree=null | --enable-execution |
| worktree | create_worktree | none | --enable-writes |
| apply | apply_patch | patch, worktree | --enable-writes |

There are 12 default tools and 15 when both flags are enabled. Index refresh
updates state, including embeddings if configured; index status returns current
counts without refreshing. Workflow tools use the RAG configuration's generation
model. The MCP host's own model can instead use retrieval tools directly.

Example MCP tool arguments:

```json
{"task": "Review CAN message handling for concurrency defects", "limit": 8}
```

`analyze`, `review`, and `develop` return the existing workflow JSON: answer,
sources with citations, mode, request_id, timing and model metadata. A valid
extractable diff from `develop` additionally appears in `patch`. An incomplete
model response can omit patch; development never applies it or runs tests.
No-evidence responses contain empty sources and model=null. Model clients are
created only when a workflow is invoked, so discovery and retrieval tools can
start without a usable generation server. Analysis needs a reachable configured
model when matching evidence exists. Argument validation/model failures return
MCP tool errors; a rejected patch or nonzero command retains its structured
result for inspection.

All executed tools append metadata to state_dir/logs/requests.jsonl when enabled.
Filter `event="tool"` and `transport="mcp"` for one outer event per tool execution.
These include operation, request ID, elapsed milliseconds, success/error and
model metadata when available. Nested search/workflow/model events remain
separate; do not sum their times or token counts as independent requests.
Workflow/search events reuse the outer tool request ID; raw prompts, arguments,
source, answers, diffs and command output are omitted from tool logs. Missing
model usage is null. SDK schema errors rejected before the tool function starts
and calls to unknown/unregistered tools are outside these execution logs.
Underlying model-call failures retain their separate model metadata events.

Existing response shapes for source, symbols, Git and execution tools remain
unchanged. The existing search envelope remains unchanged. Dictionary tools also declare
MCP output schemas and supply structuredContent for JSON-capable clients; list
and string tools retain their existing content representation. Tool logging adds no
protocol stdout output, and a log write failure does not discard tool results.
Set logging_enabled=false to disable persistent logs.
