# Linux / Amazon EC2 deployment

This deployment runs the Python CLI and MCP server in one image and Ollama on the same Linux server in a separate container. It creates no AWS resources. The default is CPU inference; choose machine memory and storage for the actual model and repository. There is no response-time guarantee. Existing EC2 infrastructure, credentials and provisioning stay under your control.

## Host prerequisites

Use a Linux host with Docker Engine, the Docker Compose plugin, Git, Python 3.11+, and a non-root account that owns the target checkout and state directory. This deployment setup targets Linux; run it on the remote host rather than native Windows. On an existing Amazon Linux 2023 instance, AWS documents these Docker installation steps:

```sh
sudo yum update -y
sudo yum install -y docker git python3.11
sudo systemctl enable --now docker
sudo usermod -a -G docker ec2-user
```

Reconnect SSH after changing group membership, then run `docker ps`. Docker group membership grants powerful host access; restrict that account to trusted operators. Install the Compose plugin separately using Docker's distribution-appropriate or manual instructions, then verify `docker compose version`. Do not assume the AWS Docker package includes Compose. Python is needed for setup only; the application uses Python 3.12 inside its image. Amazon Linux 2023 keeps its system `python3` at 3.9; use the separately installed `python3.11` for these examples and do not change the system symlink.

Sources checked 2026-10-01: [AWS Docker installation for Amazon Linux](https://docs.aws.amazon.com/serverless-application-model/latest/developerguide/install-docker.html), [Python in Amazon Linux 2023](https://docs.aws.amazon.com/linux/al2023/ug/python.html), [Docker Compose plugin installation](https://docs.docker.com/compose/install/linux/).

Restrict SSH ingress to your administrative source or existing private access path. No application or Ollama inbound port is required. See [EC2 security groups](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/ec2-security-groups.html). Use a trusted repository and explicit trusted build commands; neither the runner nor a container with writable checkout mounts is a complete sandbox for hostile code.

## Configure paths and images

Place this project at `/home/ec2-user/repo-rag` (adjust examples for your host) and your target Git checkout at `/home/ec2-user/project`. The latter must be the Git checkout root, owned by the account running setup. Commit or stash tracked edits before creating managed worktrees; untracked files do not become part of their baseline.

Choose an Ollama image tag verified by your operator. The example uses the published `ollama/ollama:latest` discovery tag; for repeatable rollouts substitute the chosen immutable image digest. Setup does not contact Ollama or download weights.

```sh
cd /home/ec2-user/repo-rag
python3.11 deploy/configure.py --repo /home/ec2-user/project \
  --state /home/ec2-user/repo-rag-state \
  --ollama-image ollama/ollama:latest --model qwen2.5-coder:7b
cd deploy
docker compose config
docker compose build app
docker compose up -d --wait ollama
docker compose exec -T ollama ollama list
```

The setup script writes `.env` and `repo-rag.toml` in `deploy/`. Keep these host-specific files out of source control. Re-running setup overwrites them: preserve any custom command definitions first. Set `PYTHON_IMAGE` to an immutable Python image digest in `.env` for reproducible base-image selection; `MCP_VERSION` defaults to the tested SDK version 1.30.0. Build-time apt and transitive Python dependencies are not fully locked, so archive a tested built application image by digest for exact redeployment. Set `APP_IMAGE` to that image and use `docker compose run --no-build ...` to prevent rebuilding it.

`repo` and `state_dir` are absolute TOML paths. `Config.load` resolves relative paths against `/config`, not against the repository or Compose directory. Both bind mounts use the *same absolute paths inside and outside the container*. Git stores absolute links between a worktree and the main checkout, so changing those paths breaks managed worktree metadata. Retain the paths after restarts, or deliberately recreate worktrees when moving deployment. Mount a full checkout rather than a linked worktree whose Git metadata lives outside it.

The app runs with the setup account's numeric UID/GID. The checkout and state mounts are writable for Git worktree registration and explicit patch tools; the config mount is read-only. Setup refuses root. Fix host ownership deliberately if necessary; do not suppress Git ownership checks with a global `safe.directory=*`. Never mount the Docker socket into the app.

Ollama has no published host port. `http://ollama:11434` is service DNS, not localhost, so the generated config deliberately sets `allow_remote_model = true` for this private Compose service endpoint. The bridge allows outgoing access for explicit model pulls and configured build tools; it is not an air-gap. Other containers attached to that network can access Ollama. Do not replace this URL with a public endpoint without reviewing that boundary. The config defaults to keyword retrieval (`embedding_model = ""`).

## Explicit model setup and CLI

The startup health check (`ollama list`) checks API readiness, not whether your model is installed. Pull exactly the model configured in TOML as a separate operator action:

```sh
docker compose exec -T ollama ollama pull qwen2.5-coder:7b
docker compose exec -T ollama ollama list
docker compose run --rm -T app index
docker compose run --rm -T app analyze 'Explain the repository entry points'
```

No model weights are downloaded by build, configuration, startup, or health checking. For semantic retrieval, explicitly pull an embedding model and set `embedding_model` to its exact name in the TOML file. Weights persist in the `ollama-models` named volume. SQLite and managed worktrees persist in the host state directory. `docker compose down` retains this data; `down -v` removes the model volume. Back up the checkout and state together to preserve worktree registration, and back up the model volume separately if required.

Keyword-only operations can bypass Ollama startup:

```sh
docker compose run --rm --no-deps -T app index
docker compose run --rm --no-deps -T app search 'entry point'
docker compose run --rm --no-deps -T app worktree
```

Use the absolute worktree path printed by the CLI unchanged for `apply` and `run --worktree`. Patch files or result output must be placed in a mounted path, for example the state directory. A host `/tmp` file is not visible in the container. Review patch content and configure only trusted command argv arrays in `[commands]`. The shipped image contains Python and Git, not C++ compilers, Node.js, .NET, or project dependencies. Build a custom image that installs your repository's tools, preserving the entrypoint and numeric non-root user. Set `APP_IMAGE` to it and run with `--no-build`; repository command configuration does not install executables.

## MCP over SSH stdio

Start Ollama and build the app before connecting a host. Configure the MCP host to launch `ssh` directly with these arguments (substitute your account, hostname and absolute deployment path):

```json
{
  "mcpServers": {
    "repo-rag-ec2": {
      "command": "ssh",
      "args": ["-T", "-o", "BatchMode=yes", "ec2-user@your-host",
        "docker compose --project-directory /home/ec2-user/repo-rag/deploy -f /home/ec2-user/repo-rag/deploy/compose.yaml run --rm --no-deps --no-build -T app mcp"]
    }
  }
}
```

Verify the SSH host key and configure authentication in advance. `-T` on SSH and Compose disables pseudo-terminals; stdin/stdout carry the MCP protocol. Keep remote shell startup scripts silent on stdout. The generated app entrypoint already supplies the configuration argument. Add `--enable-execution` and/or `--enable-writes` after `mcp` only when those independent permissions are intentional. See [MCP setup](MCP_SETUP.md). A normal CLI invocation can use the same SSH command with `status` instead of `mcp`.

## Optional NVIDIA GPU

On an existing compatible NVIDIA GPU host, install its supported driver and NVIDIA Container Toolkit and configure Docker's runtime following [Ollama Docker instructions](https://docs.ollama.com/docker) and [NVIDIA installation guidance](https://docs.nvidia.com/datacenter/cloud-native/container-toolkit/latest/install-guide.html). Verify host GPU availability first. Then use the explicit override for every relevant Compose operation:

```sh
docker compose -f compose.yaml -f compose.gpu.yaml config
docker compose -f compose.yaml -f compose.gpu.yaml up -d --wait ollama
```

The default file requests no GPU. GPU compatibility and driver installation were not exercised here. No EC2 instance creation or paid-resource operation is part of this guide.

## Checks and troubleshooting

`docker compose ps`, `docker compose logs ollama`, and `docker compose exec -T ollama ollama list` distinguish API startup from model availability. Missing-model responses require an explicit pull of the configured model. Increase the TOML timeout deliberately for slow CPU inference. Git permission errors require matching host ownership and UID/GID; executable-not-found errors require a custom toolchain image.

Local validation covers generated TOML loading and real Git worktree creation/patching using the deployment paths, plus static Compose inspection. Docker and EC2 are unavailable in the authoring environment; no live image build, service start, SSH MCP connection, or GPU inference was validated there. Run `docker compose config`, build, startup, model setup, and a real workflow on your deployment host before relying on it.

## Model adapters and request logs

Version 0.3 supports native Ollama and OpenAI-compatible serving APIs, separate embedding configuration, natural-language definition search and JSON metadata logs. See [MODELS_AND_LOGGING.md](MODELS_AND_LOGGING.md). MCP search returns a structured object with a `matches` array; logs never use protocol stdout.
