# Local Repo RAG architecture

A deterministic Python workflow orchestrates repository indexing, retrieval and a local model. The same repository operations are exposed over MCP stdio to a compatible host. The local model is an HTTP inference service; MCP is the tool boundary, not the embedding database or model protocol.

```mermaid
flowchart TD
  A[CLI or MCP host] --> B[Workflow and tools]
  B --> C[Incremental repository index]
  C --> D[SQLite keywords and vectors]
  B --> E[Local Ollama model]
  B --> F[Git worktree and command runner]
```

## Boundaries

- Configuration is a TOML file. Repository and state paths resolve relative to it.
- Source indexing uses content hashes and language-aware heuristics. SQLite FTS5 is the keyword index; optional stored embeddings support semantic retrieval.
- Retrieval returns repository-relative paths and exact line spans, with bounded context assembly. Dependency and symbol lookup complement textual search.
- Cross-language runtime relationships cannot reliably be inferred from source text alone. Configure known source/target links, especially native DLL/PInvoke, RPC, message topics and generated bindings.
- The model produces grounded explanations or a proposed unified diff. No response directly modifies the original repository.
- Git tools create detached worktrees. Patch application is an explicit operation. Configured commands receive argv arrays, no implicit shell.
- Direct source reads and Git diff share the indexing file admission policy; Git diff covers unstaged admitted paths only.
- MCP read tools are enabled by default. Mutating and execution tools require explicit server startup flags.

## What the initial release does not claim

Language heuristics are not a compiler, AST/LSP engine or complete call graph. Retrieval relevance does not prove a dependency or semantic correctness. Source references are evidence locations; model claims still require review. Build and test outcomes are deterministic evidence, but passing tests do not prove safety-critical correctness.

This release has a CLI and MCP server, rather than a browser UI. It does not train a model or download weights automatically. Semantic ranking uses local stored vectors; very large indexes will require an ANN backend, dedicated reranker and benchmark-driven tuning. The command runner is not an operating-system sandbox: configured build scripts can access the user's filesystem and network. Use a restricted container/VM for untrusted projects. Execution supports POSIX process groups and a Windows Job Object backend. The AWS deployment targets Linux EC2 with Docker. Platform CI is configured; check VALIDATION.md for completed native results.

## Extension points

Replace heuristic symbol extraction with Tree-sitter/LSP adapters; use compile_commands.json for C++ semantic relationships; import project references for C#; add a vector backend behind Index.search; add a richer local inference provider behind OllamaClient; add workflow steps while retaining explicit patch and execution boundaries.

## Scaling and freshness

Index refresh hashes every admitted source file to detect changes; unchanged chunks keep their stored embeddings. This avoids repeated embedding work but still reads source bytes on each CLI workflow or MCP search. Vector similarity currently scans stored embeddings, rather than using an approximate nearest-neighbor index. Benchmark with your repository before assuming latency gains on a huge checkout. There is no filesystem watcher or compile-time semantic index in this release. Embedding cache identity follows the configured embedding model name and endpoint; if you replace model weights under the same name, clear the index or change the model identifier. Use a separate state_dir for each repository.

## Version 0.3 adapters and query retrieval

Generation and embeddings now use a common adapter factory, selected independently through Config. Native Ollama and OpenAI-compatible HTTP APIs implement the same generate/embed interface. Natural-language query normalization combines segmented identifier terms with definition/declaration/reference hints; these remain conservative source heuristics. CLI/MCP expose a JSON search envelope. Metadata-only JSONL telemetry records calls and top-level elapsed timings under the excluded state directory. See MODELS_AND_LOGGING.md for protocol boundaries and migration details.

## Version 0.4 MCP parity

The stdio server now exposes index refresh/status and all three configured-model
workflows. Model clients are lazy per workflow invocation; retrieval tools can
operate independently of generation. Typed dictionary return annotations expose
MCP output schemas and structuredContent. Signature-preserving telemetry wraps
each executed tool, with metadata-only outer events separate from nested model
and workflow events. Command and managed-worktree writes remain independent
startup gates.
