# Models, search and request logs (0.3.0)

## Serving API compatibility

The application connects to a model server, not directly to model weight files.
Use `provider = "ollama"` for the native Ollama API or `provider = "openai"`
for a server implementing non-streaming `/chat/completions` and, optionally,
`/embeddings`. Compatibility is defined by those endpoints and response shapes;
this is not a claim that every model/server combination has been exercised.
Models need not support tool calling: the workflow sends retrieved evidence as
text. The MCP host independently chooses its own model for using repository tools.

Existing 0.2 configurations still default to Ollama. OpenAI-compatible example:

```toml
repo = "C:/Projects/RTMC-System"
state_dir = "C:/RepoRagState/RTMC"
provider = "openai"
llm_url = "http://127.0.0.1:8000/v1"
model = "your-server-model-id"
api_key_env = "LOCAL_MODEL_KEY"
embedding_model = ""
allow_remote_model = false
logging_enabled = true
```

`model` must match the identifier accepted by your server. `api_key_env` names an
optional environment variable; never put the key itself in TOML. If a variable
is configured it must contain a nonempty value. Windows PowerShell example:

```powershell
$env:LOCAL_MODEL_KEY = "your-server-key"
```

Set the variable in the environment of the actual CLI/MCP process. A desktop
host may not inherit changes made in a separate terminal. Without authentication,
leave `api_key_env = ""`.

Generation and embeddings may use separate servers:

```toml
provider = "openai"
llm_url = "http://127.0.0.1:8000/v1"
model = "your-generation-model"
embedding_provider = "ollama"
embedding_url = "http://127.0.0.1:11434"
embedding_model = "your-installed-embedding-model"
embedding_api_key_env = ""
```

Empty embedding provider/URL/key settings inherit generation settings. If the
embedding server uses a different key, name its variable explicitly. Leave
`embedding_model = ""` to use keyword/symbol search without model requests.
Changing the embedding identity requires rebuilding compatible vectors; indexing
performs that refresh. Provider, endpoint and model affect that identity.

Only loopback endpoints are allowed by default. For intentional network access,
set `allow_remote_model = true`. URLs must not contain credentials or query
parameters. OpenAI-compatible URLs may include a base path such as `/v1`.
On AWS, existing Compose still supplies Ollama; selecting another server requires
providing that server yourself and configuring its reachable URL. Nothing here
creates AWS resources or starts an alternative inference service.

## Natural-language search

```powershell
& .\.venv\Scripts\python.exe -m repo_rag --config repo-rag.toml search "where get can message function is defined?"
```

Search normalizes identifier words and recognizes definition-oriented questions.
The JSON response contains `query`, `intent`, `matches`, `timing`, `model` and a
`request_id`. Each match includes source path/line ranges, symbol where detected,
kind, excerpt and match reason. Definitions, declarations and references are
heuristic candidates, not compiler-resolved facts. Overloads and ambiguous names
can return several matches. Complex macros, generated code and unusual syntax
may be missed. Empty matches mean no indexed evidence was found.

The CLI and MCP search now return an object rather than the old bare match list.
Consumers should read `result["matches"]`. The Python `Index.search()` API keeps
its list return value; `Index.search_result()` returns the envelope. Source text
in search results is intentional; logs omit that text.

CLI/MCP search measures indexing and retrieval plus total elapsed time. A
keyword-only query records `model: null`. Optional embeddings call the configured
embedding server; generation is unnecessary for a definition lookup. Analysis,
review and development return retrieval, generation and total timings plus model
metadata. Timings are elapsed wall time measured locally, not server benchmark
claims. Retrieval timing includes embedding requests; total time also includes
index refresh, so it can exceed the generation duration substantially.

## Logging

Metadata events are appended to `state_dir/logs/requests.jsonl`. Each line is a
JSON object with a UTC timestamp and operation. Model events include provider,
model, elapsed milliseconds, status, reported token usage, and safe error type.
Top-level search/workflow events include a request ID and overall timings.
If the server supplies no usage, `token_usage` is `null`; individual unreported
counts are omitted rather than estimated. These values are server reports, not
measured subscription usage. Multiple events may occur for a single prompt when
indexing or retrieval needs embeddings.

Logs exclude query/prompt text, excerpts, model responses, URLs and API keys by
default. This release does not offer content logging. `logging_enabled = false`
disables persistent logging while result timing remains available. Logs are
append-only without automatic rotation; archive/delete them when needed. They
stay under the excluded state directory. Log write errors warn on stderr and do
not break MCP stdout protocol or discard successful results.

## MCP tool coverage in 0.4

All 15 supported MCP tools (12 enabled by default) now have outer execution
metadata events, including read/Git/index and optional write/run tools. Filter
`event="tool"`, `transport="mcp"` to distinguish them from nested model/workflow
records. See MCP_SETUP.md for the tool list, result schemas and SDK-validation
logging boundary. No raw tool arguments/results are stored in these events.
