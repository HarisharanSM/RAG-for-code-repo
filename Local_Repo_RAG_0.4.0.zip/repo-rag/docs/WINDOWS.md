# Windows 10 and 11

Use native Python 3.11 or newer and Git for Windows with `git.exe` on `PATH`.
Ollama must be reachable at the configured loopback URL for model generation or
embeddings. Lexical indexing and search work without a model service.

From PowerShell in the project directory:

```powershell
py -3.11 -m venv .venv
& .\.venv\Scripts\python.exe -m pip install -e '.[mcp]'
Copy-Item repo-rag.example.toml repo-rag.toml
& .\.venv\Scripts\python.exe -m repo_rag --config .\repo-rag.toml index
& .\.venv\Scripts\python.exe -m repo_rag --config .\repo-rag.toml search 'axis_position'
```

Use the launcher version matching your installed Python. Directly invoking the
virtual environment interpreter avoids needing PowerShell script activation.
For the sample `smoke` command, change its executable to the absolute virtual
environment Python path, or activate the virtual environment so `python` resolves
to it. Configured commands are executable/argument arrays; no shell expands them.

TOML paths are relative to the configuration file. Forward slashes avoid TOML
backslash escapes; literal single-quoted strings also accept Windows paths:

```toml
repo = 'C:\Users\Alice\Projects\repo with spaces'
state_dir = 'C:\Users\Alice\AppData\Local\repo-rag\state'

[commands]
verify = ['C:\Users\Alice\Projects\repo-rag\.venv\Scripts\python.exe', '-m', 'unittest', 'discover', '-s', 'tests']
```

Keep the state directory writable and outside the source repository when
possible. Git operations require `repo` to be the checkout root. Source and
patch paths use repository-relative forward slashes, for example `src/main.py`.
Drive prefixes, alternate data stream colons, traversal, symlinks, junctions,
reserved device names, components ending in a dot or space, and any case variant
of a `.git` path component are refused. Worktree registration is
read with NUL-separated Git porcelain output, preserving paths with spaces and
avoiding platform-specific slash or line-ending comparisons.

## MCP host configuration

Install the MCP extra into the exact interpreter launched by your host. JSON
requires escaping backslashes, so forward slashes are simpler:

```json
{
  "mcpServers": {
    "repo-rag": {
      "command": "C:/Users/Alice/Projects/repo-rag/.venv/Scripts/python.exe",
      "args": [
        "-m", "repo_rag", "--config",
        "C:/Users/Alice/Projects/repo-rag/repo-rag.toml", "mcp"
      ]
    }
  }
}
```

Each argument is separate, including paths containing spaces. Use an absolute
interpreter and configuration path because hosts may use a different working
directory. Append `--enable-execution` after `mcp` to expose configured command
names; append `--enable-writes` to expose managed worktrees and patch application.
Both are disabled by default. See [MCP_SETUP.md](MCP_SETUP.md).

## Execution and limits

The Windows runner creates a suspended child, assigns it to a Job Object with
kill-on-close enabled, then resumes its primary thread. Setup errors terminate
the suspended child and fail the request. The job permits no process breakaway.
Timeouts terminate processes in the job, including ordinary descendants, and
closing the job also cleans up remaining job members on completion. A restrictive
parent job or host policy can prevent assignment; the runner fails instead of
executing an uncontained command.

The runner drains stdout and stderr independently using `PeekNamedPipe`, retaining
at most 64 KiB of raw bytes from each. Extra bytes are discarded and the matching
truncation flag is returned. Captured output is decoded as UTF-8 with replacement
for invalid bytes; Windows command output may retain CRLF. A child that inherits
output handles can keep pipes open after its parent exits, so the timeout covers
pipe draining as well as the parent wait.

Job Objects control ordinary local process lifetime; they do not restrict
filesystem or network access. Commands retain the caller's permissions. Processes
launched through another service, such as WMI, are outside this mechanism. A host
crash in the short interval between suspended creation and assignment may leave
a suspended process. Use a restricted VM or container for untrusted code.

The implementation follows Microsoft documentation for [Job Objects](https://learn.microsoft.com/en-us/windows/win32/procthread/job-objects),
[process creation flags](https://learn.microsoft.com/en-us/windows/win32/procthread/process-creation-flags),
[Tool Help thread enumeration](https://learn.microsoft.com/en-us/windows/win32/api/tlhelp32/nf-tlhelp32-thread32first),
[ResumeThread](https://learn.microsoft.com/en-us/windows/win32/api/processthreadsapi/nf-processthreadsapi-resumethread),
and [PeekNamedPipe](https://learn.microsoft.com/en-us/windows/win32/api/namedpipeapi/nf-namedpipeapi-peeknamedpipe).

## Validation

```powershell
& .\.venv\Scripts\python.exe -m unittest discover -s tests -v
```

The suite uses its current Python interpreter rather than assuming `python3`
exists. Git/patch fixtures use explicit LF and disable `core.autocrlf`; a separate
source test checks CRLF preservation. Tests cover paths with spaces, bilateral
output saturation, timeout cleanup of descendants inheriting pipes, and a running
parent that closes its output pipes. Symlink-only tests skip when Windows lacks
the privilege to create symlinks, while other exclusion tests still run.

The Windows backend dispatch test is explicitly mocked and does not establish
native Win32 correctness. Linux results establish the POSIX path and shared
behavior. Native Windows execution requires running the suite on Windows; CI
results must be checked before treating Windows compatibility as verified.

## Model adapters and request logs

Version 0.3 supports native Ollama and OpenAI-compatible serving APIs, separate embedding configuration, natural-language definition search and JSON metadata logs. See [MODELS_AND_LOGGING.md](MODELS_AND_LOGGING.md). MCP search returns a structured object with a `matches` array; logs never use protocol stdout.
