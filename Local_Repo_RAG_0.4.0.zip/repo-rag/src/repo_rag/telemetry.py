"""Metadata-only request logs; never emit diagnostics to MCP stdout."""
from __future__ import annotations
import json
import os
import warnings
from datetime import datetime, timezone
from time import perf_counter
from uuid import uuid4
from .config import Config


def record_event(config: Config, event: dict) -> None:
    if not config.logging_enabled:
        return
    # Whitelist metadata: raw model responses, source, prompts and keys never enter logs.
    allowed = ('request_id', 'operation', 'provider', 'model', 'status', 'elapsed_ms',
               'token_usage', 'error_type', 'timing', 'match_count', 'model_calls', 'transport', 'event')
    item = {k: event[k] for k in allowed if k in event}
    item['timestamp'] = datetime.now(timezone.utc).isoformat()
    try:
        directory = config.state_dir / 'logs'
        directory.mkdir(parents=True, exist_ok=True)
        data = (json.dumps(item, ensure_ascii=False) + '\n').encode('utf-8')
        fd = os.open(directory / 'requests.jsonl', os.O_WRONLY | os.O_CREAT | os.O_APPEND, 0o600)
        try:
            # Single append per event, with no protocol stdout output.
            if os.write(fd, data) != len(data):
                raise OSError('Incomplete log append')
        finally:
            os.close(fd)
    except (OSError, TypeError, ValueError):
        try:
            warnings.warn('Request metadata could not be logged', RuntimeWarning, stacklevel=2)
        except Warning:
            # Warning-as-error settings must not turn optional logging into failure.
            pass


class LoggedClient:
    def __init__(self, config, client):
        self.config, self.client = config, client
        self.last_call = None

    def _call(self, operation, value):
        started = perf_counter()
        status, error_type = 'success', None
        try:
            return getattr(self.client, operation)(value)
        except Exception as exc:
            status, error_type = 'error', type(exc).__name__
            raise
        finally:
            metadata = getattr(self.client, 'last_call', None)
            metadata = dict(metadata) if isinstance(metadata, dict) else {}
            self.last_call = {
                **metadata, 'operation': operation, 'status': status,
                'elapsed_ms': round((perf_counter() - started) * 1000, 3),
                'provider': metadata.get('provider', self.config.provider),
                'model': metadata.get('model', self.config.model),
                'token_usage': metadata.get('token_usage'),
            }
            if error_type:
                self.last_call['error_type'] = metadata.get('error_type', error_type)
            record_event(self.config, self.last_call)

    def generate(self, prompt):
        return self._call('generate', prompt)

    def embed(self, texts):
        return self._call('embed', texts)


def logged_client(config, purpose='generation'):
    from .llm import create_client
    return LoggedClient(config, create_client(config, purpose=purpose))


def search_repository(config, index, query, limit=8, language=None):
    started = perf_counter()
    request_id = str(uuid4())
    try:
        index.index()
        indexed = perf_counter()
        result = index.search_result(query, limit=limit, language=language)
        result['request_id'] = request_id
        result.setdefault('timing', {})['index_ms'] = round((indexed-started)*1000, 3)
        result['timing']['total_ms'] = round((perf_counter()-started)*1000, 3)
        record_event(config, {'request_id': request_id, 'operation': 'search',
                             'status': 'success', 'model': result.get('model'),
                             'timing': result['timing'], 'match_count': len(result['matches'])})
        return result
    except Exception as exc:
        record_event(config, {'request_id': request_id, 'operation': 'search',
                             'status': 'error', 'error_type': type(exc).__name__,
                             'elapsed_ms': round((perf_counter()-started)*1000, 3)})
        raise


def instrument_tool(config: Config, operation: str):
    """Log an executed synchronous MCP tool without changing its signature/result."""
    from functools import wraps

    def decorate(function):
        @wraps(function)
        def wrapped(*args, **kwargs):
            started = perf_counter()
            event = {'request_id': str(uuid4()), 'operation': operation,
                     'transport': 'mcp', 'event': 'tool', 'status': 'success', 'model': None}
            try:
                result = function(*args, **kwargs)
                if isinstance(result, dict):
                    if isinstance(result.get('request_id'), str):
                        event['request_id'] = result['request_id']
                    metadata = result.get('model')
                    if isinstance(metadata, dict):
                        # Only adapter metadata; never log arbitrary tool return content.
                        fields = ('provider', 'model', 'operation', 'elapsed_ms', 'status',
                                  'token_usage', 'error_type')
                        event['model'] = {k: metadata[k] for k in fields if k in metadata}
                    if result.get('timed_out'):
                        event.update(status='error', error_type='timeout')
                    elif isinstance(result.get('returncode'), int) and result['returncode'] != 0:
                        event.update(status='error', error_type='nonzero_exit')
                    elif result.get('applied') is False:
                        event.update(status='error', error_type='patch_rejected')
                    elif result.get('embedding_error'):
                        event.update(status='error', error_type='embedding_error')
                return result
            except Exception as exc:
                event.update(status='error', error_type=type(exc).__name__)
                raise
            finally:
                event['elapsed_ms'] = round((perf_counter()-started)*1000, 3)
                record_event(config, event)
        return wrapped
    return decorate
