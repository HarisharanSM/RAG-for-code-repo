"""Optional MCP stdio interface. Write and command tools require explicit flags."""

from __future__ import annotations

from .config import Config
from .execution import GitTools, Runner, read_source
from .telemetry import instrument_tool


def build_server(config: Config, *, enable_execution: bool = False, enable_writes: bool = False):
    try:
        from mcp.server.fastmcp import FastMCP
    except ImportError as exc:
        raise RuntimeError("MCP support requires the optional 'mcp' dependency") from exc

    from .index import Index

    server = FastMCP("repo-rag")
    index = Index(config)
    git = GitTools(config)

    @server.tool()
    @instrument_tool(config, "search")
    def search(query: str, limit: int = 8, language: str | None = None) -> dict[str, object]:
        """Search indexed repository source for relevant passages."""
        from .telemetry import search_repository
        return search_repository(config, index, query, limit=limit, language=language)

    @server.tool()
    @instrument_tool(config, "source")
    def source(path: str, start_line: int = 1, end_line: int | None = None) -> dict[str, object]:
        """Read lines from a repository-relative source file."""
        return read_source(config, path, start_line, end_line)

    @server.tool()
    @instrument_tool(config, "symbols")
    def symbols(name: str) -> list[dict]:
        """Find indexed definitions by name."""
        index.index()
        return index.symbols(name)

    @server.tool()
    @instrument_tool(config, "related")
    def related(path: str) -> list[dict]:
        """Find indexed source linked to a repository-relative path."""
        index.index()
        return index.related(path)

    @server.tool()
    @instrument_tool(config, "git_status")
    def git_status() -> dict[str, object]:
        """Read the repository's short Git status."""
        return git.status()

    @server.tool()
    @instrument_tool(config, "git_diff")
    def git_diff() -> dict[str, object]:
        """Read the repository's unstaged Git diff."""
        return git.diff()

    @server.tool()
    @instrument_tool(config, "git_history")
    def git_history(limit: int = 10) -> dict[str, object]:
        """Read recent Git commit subjects."""
        return git.history(limit)

    @server.tool()
    @instrument_tool(config, "refresh_index")
    def refresh_index() -> dict[str, object]:
        """Incrementally refresh the source index and return indexing statistics."""
        return index.index()

    @server.tool()
    @instrument_tool(config, "index_status")
    def index_status() -> dict[str, object]:
        """Read indexed file, chunk and embedding counts."""
        return index.status()

    def run_workflow(task: str, mode: str, limit: int) -> dict[str, object]:
        # Model URL validation and clients are deferred until a workflow is invoked.
        from .workflow import Workflow
        return Workflow(config).run(task, mode=mode, limit=limit)

    @server.tool()
    @instrument_tool(config, "analyze")
    def analyze(task: str, limit: int = 8) -> dict[str, object]:
        """Analyze a task using indexed evidence and source citations."""
        return run_workflow(task, "analyze", limit)

    @server.tool()
    @instrument_tool(config, "review")
    def review(task: str, limit: int = 8) -> dict[str, object]:
        """Review a task for evidence-supported defects with source citations."""
        return run_workflow(task, "review", limit)

    @server.tool()
    @instrument_tool(config, "develop")
    def develop(task: str, limit: int = 8) -> dict[str, object]:
        """Propose a cited change and patch; never apply it or modify source files."""
        return run_workflow(task, "develop", limit)

    if enable_execution:
        runner = Runner(config)

        @server.tool()
        @instrument_tool(config, "run_command")
        def run_command(name: str, worktree: str | None = None) -> dict[str, object]:
            """Run one named, configured argv command with bounded time and output."""
            return runner.run(name, worktree)

    if enable_writes:
        @server.tool()
        @instrument_tool(config, "create_worktree")
        def create_worktree() -> str:
            """Create an isolated detached Git worktree under state_dir."""
            return git.create_worktree()

        @server.tool()
        @instrument_tool(config, "apply_patch")
        def apply_patch(patch: str, worktree: str) -> dict[str, object]:
            """Validate and apply a text patch in a managed worktree."""
            return git.apply_patch(patch, worktree)

    return server


def serve(config: Config, *, enable_execution: bool = False, enable_writes: bool = False) -> None:
    """Run the official MCP SDK over stdio. This blocks until the client exits."""
    build_server(config, enable_execution=enable_execution, enable_writes=enable_writes).run(transport="stdio")
