"""Conservative source-signature and identifier heuristics, not a language parser."""
from __future__ import annotations

from dataclasses import dataclass
import re


@dataclass(frozen=True)
class Symbol:
    name: str
    line: int
    kind: str


@dataclass(frozen=True)
class Query:
    intent: str
    terms: tuple[str, ...]


# Split HTTPServer and GetCANMessage without turning CAN into individual letters.
_IDENTIFIER_PARTS = re.compile(r"[A-Z]+(?=[A-Z][a-z]|\d|\b)|[A-Z]?[a-z]+|[A-Z]+|\d+", re.ASCII)
_STOPWORDS = frozenset("a an the this that these those where which what who how is are was were be been "
                      "being do does did i me my we our you your please find locate show tell of in on at "
                      "to for and or with from function functions method methods symbol symbols defined "
                      "definition definitions declared declaration declarations implementation implemented "
                      "code source can you".split()) - {"can"}


def identifier_terms(text: str) -> tuple[str, ...]:
    words = re.findall(r"[^\W_]+", text, flags=re.UNICODE)
    result = []
    for word in words:
        parts = _IDENTIFIER_PARTS.findall(word)
        result.extend(part.casefold() for part in (parts or [word]))
    return tuple(result)


def analyze_query(text: str) -> Query:
    lowered = text.casefold()
    intent = "find_definition" if re.search(
        r"\b(?:defin(?:e|ed|ition|itions)|declar(?:e|ed|ation|ations)|implement(?:ed|ation))\b|"
        r"\b(?:where|locate|find)\b.*\b(?:function|method|symbol)\b", lowered) else "search"
    name_text = re.sub(r"\bcan\s+you\b", " ", text, flags=re.IGNORECASE)
    terms_list = []
    for word in re.findall(r"\w+", name_text):
        identifier = "_" in word or bool(re.search(r"[a-z][A-Z]", word))
        terms_list.extend(term for term in identifier_terms(word) if identifier or term not in _STOPWORDS)
    terms = tuple(dict.fromkeys(terms_list))
    return Query(intent, terms)


def symbol_score(name: str, terms: tuple[str, ...]) -> float:
    """Require the requested name, allowing compact all-lowercase identifier input."""
    if not terms:
        return 0.0
    parts = identifier_terms(name.rsplit("::", 1)[-1].rsplit(".", 1)[-1])
    compact = "".join(parts)
    requested = "".join(terms)
    if compact == requested:
        return 1.0
    if all(term in parts for term in terms):
        return .8 * len(terms) / max(len(parts), 1)
    return 0.0


def normalized_source(text: str) -> str:
    compact = (word.replace("_", "").casefold() for word in re.findall(r"\w+", text))
    return " ".join((*identifier_terms(text), *compact))


def _mask(content: str, language: str) -> str:
    # Comments and ordinary literals must not produce fabricated declarations.
    pattern = (r"\#.*?$|'''[\s\S]*?'''|\"\"\"[\s\S]*?\"\"\"|'(?:\\.|[^'\\])*'|\"(?:\\.|[^\"\\])*\""
               if language == "python" else
               r"//[^\n]*|/\*[\s\S]*?\*/|'(?:\\.|[^'\\])*'|\"(?:\\.|[^\"\\])*\"|`(?:\\.|[^`\\])*`")
    return re.sub(pattern, lambda m: re.sub(r"[^\n]", " ", m.group()), content, flags=re.MULTILINE)


def _after_parameters(source: str, opening: int) -> str | None:
    depth = 0
    # A bounded window handles ordinary multiline signatures, without scanning
    # the rest of a file on malformed or generated syntax.
    for i in range(opening, min(len(source), opening + 12000)):
        if source[i] == "(":
            depth += 1
        elif source[i] == ")":
            depth -= 1
            if depth == 0:
                return source[i + 1:i + 1500]
    return None


def source_symbols(content: str, language: str) -> list[Symbol]:
    if language not in {"python", "javascript", "typescript", "cpp", "c", "csharp"}:
        return []
    source = _mask(content, language)
    result = []
    offset = 0
    class_names = set(re.findall(r"\b(?:class|struct|record)\s+(\w+)", source))
    rejected = {"if", "else", "for", "while", "switch", "catch", "return", "throw", "new", "delete",
                "sizeof", "alignof", "assert", "using", "await", "yield", "case", "do", "try"}
    for line_number, line in enumerate(source.splitlines(keepends=True), 1):
        stripped = line.strip()
        found = None
        if language == "python":
            match = re.match(r"\s*(?:async\s+)?(?:def|class)\s+(\w+)\b", line)
            if match:
                # Python stubs and ellipsis bodies are declarations.
                tail = source[offset + match.end():offset + match.end() + 12000]
                if "def" in line[:match.start(1)]:
                    opening = source.find("(", offset + match.end())
                    tail = _after_parameters(source, opening) or ""
                colon = re.search(r":\s*([^\n]*)", tail)
                kind = "declaration" if colon and colon[1].strip() in {"..."} else "definition"
                found = Symbol(match[1], line_number, kind)
        else:
            structural = re.match(r"\s*(?:(?:export|default|public|private|protected|internal|abstract|sealed|partial|static)\s+)*"
                                  r"(?:class|struct|interface|enum|namespace|record|type)\s+([\w$]+)\b", line)
            if structural:
                tail = source[offset + structural.end():offset + structural.end() + 1500]
                marker = re.search(r"[;{=]", tail)
                kind = "definition" if marker and marker[0] in {"{", "="} else "declaration"
                found = Symbol(structural[1], line_number, kind)
            if found is None and language in {"javascript", "typescript"}:
                arrow = re.match(r"\s*(?:export\s+)?(?:const|let|var)\s+([\w$]+)\s*(?::[^=]+)?=", line)
                if arrow and re.search(r"=>", source[offset + arrow.end():offset + arrow.end() + 1500].split(";", 1)[0]):
                    found = Symbol(arrow[1], line_number, "definition")
            if found is None and "(" in line:
                signature = re.match(r"\s*(.*?)\b([~\w$]+(?:::[~\w]+)*)\s*(?:<[^(){};]*>)?\s*\(", line)
                if signature:
                    prefix, name = signature[1].strip(), signature[2]
                    prefix_words = re.findall(r"\w+", prefix)
                    bad = (name in rejected or any(word in rejected for word in prefix_words)
                           or any(char in prefix for char in "=;{}()!+")
                           or prefix.endswith(".") or "->" in prefix or prefix.lstrip().startswith("#"))
                    typed = bool(prefix_words)
                    untyped_method = language in {"typescript", "javascript"}
                    constructor = name.rsplit("::", 1)[-1].lstrip("~") in class_names or "::" in name
                    if not bad and (typed or untyped_method or constructor):
                        tail = _after_parameters(source, offset + signature.end() - 1)
                        if tail is not None:
                            # Qualifiers/return annotations may follow ')'; an expression
                            # or a call continuation invalidates the signature heuristic.
                            marker = re.search(r"=>|[;{}]", tail)
                            qualifier = tail[:marker.start()] if marker else ""
                            invalid = re.search(r"\b(?:return|if|else)\b|(?<![<>=!])=(?![=>])", qualifier)
                            trailing = qualifier.strip()
                            if language in {"typescript", "javascript"}:
                                invalid = invalid or (trailing and not trailing.startswith(":"))
                            elif language == "csharp":
                                invalid = invalid or (trailing and not trailing.startswith("where "))
                            else:
                                invalid = invalid or (trailing and not re.match(
                                    r"(?:const|volatile|noexcept|override|final|throw|requires)\b|->|&|\[\[", trailing))
                            if marker and marker[0] != "}" and not invalid:
                                kind = "definition" if marker[0] in {"{", "=>"} else "declaration"
                                # Bare JS foo(); is a call. Typed TS function overloads
                                # require an explicit function keyword or return type.
                                if not typed and marker[0] == ";" and untyped_method:
                                    kind = "reference"
                                found = Symbol(name, line_number, kind)
        if found and found.kind != "reference":
            result.append(found)
        offset += len(line)
    return result


def matching_identifiers(text: str, language: str, terms: tuple[str, ...]) -> list[str]:
    source = _mask(text, language) if language in {"python", "javascript", "typescript", "cpp", "c", "csharp"} else text
    return [name for name in re.findall(r"[A-Za-z_$][\w$]*(?:::[~\w]+)*", source)
            if symbol_score(name, terms)]
