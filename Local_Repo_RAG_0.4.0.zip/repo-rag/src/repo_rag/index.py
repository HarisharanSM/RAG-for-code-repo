"""Incremental source index with SQLite FTS5 and optional Ollama embeddings.

Declaration/heading recognition is intentionally heuristic, not a parser: macros,
overloads, nested scopes, and generated syntax can defeat these boundaries. Every
returned excerpt nevertheless retains its exact source line range.
"""

from __future__ import annotations

import fnmatch
from contextlib import contextmanager
import hashlib
import heapq
import json
import math
import os
import posixpath
from pathlib import Path, PurePosixPath, PureWindowsPath
import re
import sqlite3
import stat
import subprocess
import time
from typing import Iterator

from .config import Config
from .retrieval import analyze_query, identifier_terms, matching_identifiers, normalized_source, source_symbols, symbol_score


_GENERATED_DIRS = frozenset({
    ".git", ".hg", ".svn", ".repo-rag", ".venv", "venv", "env", "__pycache__",
    "node_modules", "bower_components", "dist", "build", "out", "target", "bin",
    "obj", "coverage", ".next", ".nuxt", ".cache", "generated", "gen",
    "vendor", "packages", "site-packages",
})
_SECRET_NAMES = frozenset({".env", ".npmrc", ".pypirc", ".netrc", "id_rsa", "id_ed25519",
                           "credentials", "credentials.json", "secrets.json", "secrets.yaml"})
_SECRET_SUFFIXES = (".pem", ".key", ".p12", ".pfx", ".keystore", ".jks")
_EXTENSIONS = frozenset({
    ".py", ".pyi", ".js", ".jsx", ".mjs", ".cjs", ".ts", ".tsx", ".mts",
    ".cs", ".csproj", ".sln", ".cpp", ".cc", ".cxx", ".c", ".h", ".hh",
    ".hpp", ".hxx", ".cmake", ".md", ".mdx", ".rst", ".txt", ".adoc",
    ".json", ".jsonc", ".toml", ".yaml", ".yml", ".xml", ".sh", ".ps1",
    ".gradle", ".properties", ".mk", ".sql",
})
_SPECIAL_NAMES = frozenset({"makefile", "gnumakefile", "dockerfile", "cmakelists.txt",
                            "justfile", "meson.build", "build.gradle", "readme"})
_LANGUAGES = {
    ".py": "python", ".pyi": "python", ".js": "javascript", ".jsx": "javascript",
    ".mjs": "javascript", ".cjs": "javascript", ".ts": "typescript",
    ".tsx": "typescript", ".mts": "typescript", ".cs": "csharp",
    ".cpp": "cpp", ".cc": "cpp", ".cxx": "cpp", ".c": "c",
    ".h": "cpp", ".hh": "cpp", ".hpp": "cpp", ".hxx": "cpp",
    ".md": "markdown", ".mdx": "markdown", ".rst": "text", ".txt": "text",
    ".cmake": "cmake", ".csproj": "xml", ".sln": "text",
}
_FIELDS = "c.path, c.start_line, c.end_line, c.text, c.language, c.symbol, c.kind"


def _language(path: str) -> str:
    name = PurePosixPath(path).name.lower()
    if name in {"makefile", "gnumakefile"} or name.endswith(".mk"):
        return "make"
    if name == "cmakelists.txt":
        return "cmake"
    if name == "dockerfile":
        return "dockerfile"
    return _LANGUAGES.get(PurePosixPath(path).suffix.lower(), "text")


def is_link_or_reparse(path: Path) -> bool:
    """Reject symlinks and Windows junction/reparse aliases without following them."""
    try:
        metadata = path.lstat()
    except FileNotFoundError:
        return False
    return stat.S_ISLNK(metadata.st_mode) or (os.name == "nt" and bool(
        getattr(metadata, "st_file_attributes", 0) & getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400)))


def is_allowed_source(config: Config, rel: str) -> bool:
    """Apply the index's path policy to a repo-relative POSIX source path.

    The caller must separately check file existence, symlinks, size, and Git
    ignore status; those checks require a repository filesystem lookup.
    """
    if not isinstance(rel, str) or not rel or "\x00" in rel or "\\" in rel or ":" in rel or PureWindowsPath(rel).drive:
        return False
    parts = PurePosixPath(rel).parts
    if not parts or rel.startswith("/") or any(part in ("", ".", "..") for part in rel.split("/")):
        return False
    if any(part.endswith((".", " ")) or PureWindowsPath(part).is_reserved() for part in parts):
        return False
    name = parts[-1]
    lower = name.lower()
    if any(part.lower() in _GENERATED_DIRS for part in parts[:-1]):
        return False
    if lower in _SECRET_NAMES or lower.startswith((".env.", "id_rsa.", "id_ed25519.")):
        return False
    if lower.endswith(_SECRET_SUFFIXES) or lower.endswith((".min.js", ".min.css", ".map", ".lock")):
        return False
    match_rel, match_name = (rel.casefold(), name.casefold()) if os.name == "nt" else (rel, name)
    patterns = [p.casefold() for p in config.excludes] if os.name == "nt" else config.excludes
    if any(fnmatch.fnmatchcase(match_rel, pattern) or fnmatch.fnmatchcase(match_name, pattern)
           for pattern in patterns):
        return False
    suffix = PurePosixPath(name).suffix.lower()
    return suffix in _EXTENSIONS or lower in _SPECIAL_NAMES


def _declaration(line: str, language: str) -> str | None:
    """Return a plausible symbol; syntax-awareness stops at one source line."""
    patterns: tuple[str, ...]
    if language == "python":
        patterns = (r"^\s*(?:async\s+)?def\s+([\w]+)\s*\(", r"^\s*class\s+([\w]+)\b")
    elif language in {"javascript", "typescript"}:
        patterns = (r"^\s*(?:export\s+)?(?:default\s+)?(?:async\s+)?(?:function|class|interface|type|enum)\s+([\w$]+)\b",
                    r"^\s*(?:export\s+)?(?:const|let|var)\s+([\w$]+)\s*=\s*(?:async\s*)?(?:\([^)]*\)|[\w$]+)\s*=>",
                    r"^\s*(?:public|private|protected|static|async|readonly|\s)*\s*([\w$]+)\s*\([^;]*\)\s*(?::[^{}]+)?\s*\{")
    elif language == "csharp":
        patterns = (r"^\s*(?:(?:public|private|protected|internal|static|abstract|sealed|partial|record)\s+)*(?:class|interface|struct|enum|record)\s+([\w]+)\b",
                    r"^\s*(?:(?:public|private|protected|internal|static|async|virtual|override|partial)\s+)+[\w<>,?\[\].]+\s+([\w]+)\s*\(")
    elif language in {"cpp", "c"}:
        patterns = (r"^\s*(?:class|struct|enum|namespace)\s+([\w]+)\b",
                    r"^\s*(?:(?:inline|static|virtual|constexpr|explicit|extern)\s+)*[\w:*&<>~,\s]+\s+([~\w:]+)\s*\([^;]*\)\s*(?:const\s*)?(?:\{|$)")
    elif language == "markdown":
        patterns = (r"^\s*#{1,6}\s+(.+?)\s*#*\s*$",)
    elif language == "cmake":
        patterns = (r"^\s*(?:function|macro|add_executable|add_library)\s*\(\s*([\w.-]+)",)
    elif language == "make":
        patterns = (r"^([\w./-]+)\s*:(?!=)",)
    else:
        return None
    for pattern in patterns:
        match = re.match(pattern, line)
        if match:
            return match.group(1)
    return None


def _chunks(content: str, language: str, maximum: int) -> Iterator[tuple[int, int, str, str | None, str]]:
    lines = content.splitlines(keepends=True)
    if not lines:
        return
    symbols = {item.line - 1: (item.name, item.kind) for item in source_symbols(content, language)}
    if language not in {"python", "javascript", "typescript", "cpp", "c", "csharp"}:
        symbols = {i: (symbol, "uncertain") for i, line in enumerate(lines)
                   if (symbol := _declaration(line, language))}
    starts = sorted({0, *symbols})
    for start, stop in zip(starts, starts[1:] + [len(lines)]):
        for offset in range(start, stop, maximum):
            end = min(offset + maximum, stop)
            symbol, kind = symbols.get(start, (None, "uncertain"))
            # A continuation excerpt does not itself contain the definition.
            yield offset + 1, end, "".join(lines[offset:end]), symbol, kind if offset == start else "reference"


def _dependencies(content: str, language: str) -> Iterator[tuple[int, str, str]]:
    patterns = {
        "python": (r"^\s*(?:from\s+([\w.]+)\s+import|import\s+([\w.]+))", "import"),
        "javascript": (r"(?:\bfrom\s*|\bimport\s*\(|\brequire\s*\()\s*['\"]([^'\"]+)['\"]", "import"),
        "typescript": (r"(?:\bfrom\s*|\bimport\s*\(|\brequire\s*\()\s*['\"]([^'\"]+)['\"]", "import"),
        "cpp": (r"^\s*#\s*include\s*[<\"]([^>\"]+)[>\"]", "include"),
        "c": (r"^\s*#\s*include\s*[<\"]([^>\"]+)[>\"]", "include"),
        "csharp": (r"^\s*using\s+([\w.]+)\s*;", "using"),
    }
    if language not in patterns:
        return
    pattern, kind = patterns[language]
    for line_number, line in enumerate(content.splitlines(), 1):
        match = re.search(pattern, line)
        if match:
            yield line_number, next((part for part in match.groups() if part), ""), kind


def _cosine(a: list[float], b: list[float]) -> float:
    if len(a) != len(b) or not a:
        return 0.0
    aa = sum(x * x for x in a)
    bb = sum(x * x for x in b)
    if aa <= 0 or bb <= 0:
        return 0.0
    return sum(x * y for x, y in zip(a, b)) / math.sqrt(aa * bb)


class Index:
    def __init__(self, config: Config):
        self.config = config
        self.repo = config.repo.resolve()
        self.config.state_dir.mkdir(parents=True, exist_ok=True)
        self.db_path = config.state_dir / "index.sqlite3"
        self._initialize()

    @contextmanager
    def _connect(self) -> Iterator[sqlite3.Connection]:
        db = sqlite3.connect(self.db_path, timeout=30)
        db.row_factory = sqlite3.Row
        db.execute("PRAGMA foreign_keys=ON")
        db.execute("PRAGMA busy_timeout=30000")
        try:
            with db:
                yield db
        finally:
            db.close()

    def _initialize(self) -> None:
        with self._connect() as db:
            db.executescript("""
                CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS files (
                    path TEXT PRIMARY KEY, sha256 TEXT NOT NULL, language TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS chunks (
                    id INTEGER PRIMARY KEY, path TEXT NOT NULL REFERENCES files(path) ON DELETE CASCADE,
                    start_line INTEGER NOT NULL, end_line INTEGER NOT NULL,
                    text TEXT NOT NULL, language TEXT NOT NULL, symbol TEXT,
                    embedding TEXT
                );
                CREATE INDEX IF NOT EXISTS chunks_path ON chunks(path);
                CREATE INDEX IF NOT EXISTS chunks_symbol ON chunks(symbol COLLATE NOCASE);
                CREATE TABLE IF NOT EXISTS dependencies (
                    path TEXT NOT NULL REFERENCES files(path) ON DELETE CASCADE,
                    line INTEGER NOT NULL, target TEXT NOT NULL, kind TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS deps_path ON dependencies(path);
                CREATE VIRTUAL TABLE IF NOT EXISTS chunks_fts USING fts5(text, symbol, content='chunks', content_rowid='id');
                CREATE TRIGGER IF NOT EXISTS chunks_ai AFTER INSERT ON chunks BEGIN
                    INSERT INTO chunks_fts(rowid, text, symbol) VALUES (new.id, new.text, new.symbol);
                END;
                CREATE TRIGGER IF NOT EXISTS chunks_ad AFTER DELETE ON chunks BEGIN
                    INSERT INTO chunks_fts(chunks_fts, rowid, text, symbol)
                    VALUES ('delete', old.id, old.text, old.symbol);
                END;
            """)

            needs_search_rebuild = db.execute("SELECT 1 FROM meta WHERE key='search_fts_initialized'").fetchone() is None
            columns = {row["name"] for row in db.execute("PRAGMA table_info(chunks)")}
            for column, declaration in (("kind", "TEXT NOT NULL DEFAULT 'uncertain'"),
                                        ("search_text", "TEXT NOT NULL DEFAULT ''"),
                                        ("search_symbol", "TEXT NOT NULL DEFAULT ''")):
                if column not in columns:
                    db.execute(f"ALTER TABLE chunks ADD COLUMN {column} {declaration}")
            db.executescript("""
                CREATE VIRTUAL TABLE IF NOT EXISTS search_fts USING fts5(
                    search_text, search_symbol, content='chunks', content_rowid='id');
                CREATE TRIGGER IF NOT EXISTS search_ai AFTER INSERT ON chunks BEGIN
                    INSERT INTO search_fts(rowid,search_text,search_symbol)
                    VALUES(new.id,new.search_text,new.search_symbol);
                END;
                CREATE TRIGGER IF NOT EXISTS search_ad AFTER DELETE ON chunks BEGIN
                    INSERT INTO search_fts(search_fts,rowid,search_text,search_symbol)
                    VALUES('delete',old.id,old.search_text,old.search_symbol);
                END;
            """)
            # Build FTS state before an old chunk is deleted during migration.
            if needs_search_rebuild:
                db.execute("INSERT INTO search_fts(search_fts) VALUES ('rebuild')")
                db.execute("INSERT OR REPLACE INTO meta(key,value) VALUES ('search_fts_initialized','1')")

    def _allowed(self, rel: str) -> bool:
        return is_allowed_source(self.config, rel)

    def _paths(self) -> Iterator[tuple[str, Path]]:
        # Git's own exclude engine is authoritative, including nested .gitignore
        # patterns and .git/info/exclude. A plain directory also works without Git.
        try:
            output = subprocess.run(
                ["git", "-C", str(self.repo), "ls-files", "--cached", "--others", "--exclude-standard", "-z"],
                check=True, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
            ).stdout
            names = (os.fsdecode(item) for item in output.split(b"\0") if item)
        except (FileNotFoundError, subprocess.CalledProcessError):
            def walk() -> Iterator[str]:
                for directory, dirs, files in os.walk(self.repo, followlinks=False):
                    dirs[:] = [name for name in dirs if not is_link_or_reparse(Path(directory) / name)
                               and not (Path(directory) / name).resolve().is_relative_to(self.config.state_dir.resolve())
                               and name.lower() not in _GENERATED_DIRS
                               and not any(fnmatch.fnmatchcase((Path(directory) / name).relative_to(self.repo).as_posix(), pattern)
                                           for pattern in self.config.excludes)]
                    for name in files:
                        yield (Path(directory) / name).relative_to(self.repo).as_posix()
            names = walk()
        state = self.config.state_dir.resolve()
        for rel in sorted(set(names)):
            if not self._allowed(rel):
                continue
            path = self.repo / rel
            if not path.is_file() or any(is_link_or_reparse(parent) for parent in (path, *path.parents)
                                         if parent.is_relative_to(self.repo) and parent != self.repo):
                continue
            # Covers a symlinked ancestor as well as a nested state directory.
            resolved = path.resolve()
            if not resolved.is_relative_to(self.repo) or resolved.is_relative_to(state):
                continue
            yield rel, path

    def _fingerprints(self) -> tuple[str, str]:
        layout = json.dumps({"chunk_lines": self.config.chunk_lines, "retrieval_version": 3}, sort_keys=True)
        embedding = json.dumps({"embedding_model": self.config.embedding_model,
                                "provider": getattr(self.config, "embedding_provider", "") or getattr(self.config, "provider", "ollama"),
                                "url": getattr(self.config, "embedding_url", "") or self.config.llm_url}, sort_keys=True)
        return layout, embedding

    def _embed_pending(self, db: sqlite3.Connection) -> tuple[int, str | None]:
        if not self.config.embedding_model:
            return 0, None
        from .telemetry import logged_client

        pending = db.execute("SELECT id, text FROM chunks WHERE embedding IS NULL ORDER BY id")
        client = logged_client(self.config, purpose="embedding")
        count = 0
        while True:
            batch = pending.fetchmany(32)
            if not batch:
                break
            try:
                vectors = client.embed([row["text"] for row in batch])
                if len(vectors) != len(batch) or any(not v or not all(math.isfinite(float(x)) for x in v)
                                                        for v in vectors):
                    raise ValueError("Model returned invalid embeddings")
            except (OSError, ValueError, RuntimeError, TimeoutError) as exc:
                return count, str(exc)
            db.executemany("UPDATE chunks SET embedding=? WHERE id=?",
                           [(json.dumps(v), row["id"]) for row, v in zip(batch, vectors)])
            count += len(batch)
        return count, None

    def index(self) -> dict:
        layout, embedding = self._fingerprints()
        seen: set[str] = set()
        stats: dict = {"added": 0, "updated": 0, "deleted": 0, "unchanged": 0,
                       "chunks": 0, "embedded": 0, "skipped": 0}
        with self._connect() as db:
            prior_repo = db.execute("SELECT value FROM meta WHERE key='repo'").fetchone()
            if prior_repo is not None and prior_repo[0] != str(self.repo):
                db.execute("DELETE FROM files")
            old = {row["path"]: row["sha256"] for row in db.execute("SELECT path, sha256 FROM files")}
            prior_layout = db.execute("SELECT value FROM meta WHERE key='layout'").fetchone()
            prior_embedding = db.execute("SELECT value FROM meta WHERE key='embedding'").fetchone()
            rebuild = prior_layout is None or prior_layout[0] != layout
            if prior_embedding is not None and prior_embedding[0] != embedding:
                db.execute("UPDATE chunks SET embedding=NULL")
            for rel, path in self._paths():
                try:
                    if path.stat().st_size > self.config.max_file_bytes:
                        stats["skipped"] += 1
                        continue
                    with path.open("rb") as source:
                        raw = source.read(self.config.max_file_bytes + 1)
                    if len(raw) > self.config.max_file_bytes or b"\0" in raw:
                        stats["skipped"] += 1
                        continue
                    content = raw.decode("utf-8-sig")
                except (OSError, UnicodeError):
                    stats["skipped"] += 1
                    continue
                seen.add(rel)
                digest = hashlib.sha256(raw).hexdigest()
                if old.get(rel) == digest and not rebuild:
                    stats["unchanged"] += 1
                    continue
                language = _language(rel)
                if rel in old:
                    db.execute("DELETE FROM chunks WHERE path=?", (rel,))
                    db.execute("DELETE FROM dependencies WHERE path=?", (rel,))
                    db.execute("UPDATE files SET sha256=?, language=? WHERE path=?", (digest, language, rel))
                    stats["updated"] += 1
                else:
                    db.execute("INSERT INTO files(path, sha256, language) VALUES (?,?,?)", (rel, digest, language))
                    stats["added"] += 1
                rows = ((rel, start, end, text, language, symbol, kind, normalized_source(text), normalized_source(symbol or ""))
                        for start, end, text, symbol, kind in _chunks(content, language, self.config.chunk_lines))
                db.executemany("INSERT INTO chunks(path,start_line,end_line,text,language,symbol,kind,search_text,search_symbol) "
                               "VALUES (?,?,?,?,?,?,?,?,?)", rows)
                db.executemany("INSERT INTO dependencies(path,line,target,kind) VALUES (?,?,?,?)",
                               ((rel, line, target, kind) for line, target, kind in _dependencies(content, language)))
            removed = set(old) - seen
            db.executemany("DELETE FROM files WHERE path=?", ((path,) for path in removed))
            stats["deleted"] = len(removed)
            db.execute("INSERT OR REPLACE INTO meta(key,value) VALUES ('layout',?),('embedding',?),('repo',?)",
                       (layout, embedding, str(self.repo)))
            stats["embedded"], error = self._embed_pending(db)
            if error:
                stats["embedding_error"] = error
            stats["chunks"] = db.execute("SELECT count(*) FROM chunks").fetchone()[0]
        return stats

    @staticmethod
    def _hit(row: sqlite3.Row, score: float, *, symbol: str | None = None,
             kind: str | None = None, reason: str = "indexed source excerpt") -> dict:
        hit = {key: row[key] for key in ("path", "start_line", "end_line", "text", "language")}
        hit["excerpt"] = row["text"]
        hit.update(score=round(score, 6), symbol=symbol or row["symbol"],
                   kind=kind or row["kind"], match_reason=reason)
        return hit

    def search(self, query: str, limit: int = 8, language: str | None = None) -> list[dict]:
        """Backward-compatible match list; structured callers use search_result()."""
        if not query.strip() or limit <= 0:
            return []
        return self.search_result(query, limit, language)["matches"]

    def search_result(self, query: str, limit: int = 8, language: str | None = None) -> dict:
        if not isinstance(query, str):
            raise TypeError("query must be a string")
        if not query.strip():
            raise ValueError("query must be nonempty")
        if isinstance(limit, bool) or not isinstance(limit, int):
            raise TypeError("limit must be an integer")
        if limit <= 0:
            raise ValueError("limit must be positive")
        if language is not None and (not isinstance(language, str) or not language.strip()):
            raise ValueError("language must be a nonempty string or null")
        started = time.perf_counter()
        parsed = analyze_query(query)
        matches: dict[int, tuple[sqlite3.Row, float, str | None, str, str]] = {}
        model = None
        if parsed.terms and limit > 0:
            with self._connect() as db:
                connector = " AND " if parsed.intent == "find_definition" else " OR "
                expression = connector.join('"' + term.replace('"', '""') + '"' for term in parsed.terms[:20])
                # Search original identifiers as well as their segmented spelling.
                original = re.findall(r"\w+", query, flags=re.UNICODE)
                raw_expression = " OR ".join('"' + term + '"' for term in original[:20])
                candidates = {}
                for table, expr in (("search_fts", expression), ("chunks_fts", raw_expression)):
                    if not expr:
                        continue
                    for row in db.execute(
                        f"SELECT c.id, {_FIELDS} FROM {table} f JOIN chunks c ON c.id=f.rowid "
                        f"WHERE {table} MATCH ? AND (? IS NULL OR c.language=?) "
                        f"ORDER BY bm25({table}) LIMIT ?", (expr, language, language, max(100, limit * 10)),
                    ):
                        candidates[row["id"]] = row
                # Restrict name candidates independently of body-token ranking.
                # This also finds compact input through normalized symbol tokens.
                for row in db.execute(
                    f"SELECT c.id, {_FIELDS} FROM search_fts f JOIN chunks c ON c.id=f.rowid "
                    "WHERE search_fts MATCH ? AND c.kind IN ('definition','declaration') "
                    "AND (? IS NULL OR c.language=?)",
                    ("search_symbol: (" + " AND ".join('"' + term + '"' for term in parsed.terms[:20]) + ")",
                     language, language),
                ):
                    if symbol_score(row["symbol"] or "", parsed.terms):
                        candidates[row["id"]] = row
                for ident, row in candidates.items():
                    name_score = symbol_score(row["symbol"] or "", parsed.terms)
                    tokens = set(identifier_terms(row["text"]))
                    coverage = sum(term in tokens for term in parsed.terms) / len(parsed.terms)
                    found_names = matching_identifiers(row["text"], row["language"], parsed.terms)
                    target = row["symbol"] if name_score else (found_names[0] if found_names else None)
                    kind = row["kind"] if name_score else ("reference" if target else "uncertain")
                    if parsed.intent == "find_definition" and not (name_score or found_names or coverage == 1):
                        continue
                    rank = (4.0 if kind == "definition" else 3.0 if kind == "declaration" else 1.0) if name_score else 0.0
                    score = rank + name_score + coverage
                    reason = ("identifier name matches; heuristic " + kind if name_score else
                              "matching identifier occurrence" if target else "query terms in source excerpt")
                    matches[ident] = (row, score, target, kind, reason)
                if self.config.embedding_model:
                    try:
                        from .telemetry import logged_client
                        client = logged_client(self.config, purpose="embedding")
                        query_embedding = client.embed([query])[0]
                        model = getattr(client, "last_call", None)
                        if not query_embedding:
                            raise ValueError("Empty query embedding")
                        vector_hits: list[tuple[float, int, sqlite3.Row]] = []
                        capacity = max(100, limit * 10)
                        for row in db.execute(
                            f"SELECT c.id, {_FIELDS}, c.embedding FROM chunks c "
                            "WHERE c.embedding IS NOT NULL AND (? IS NULL OR c.language=?)", (language, language),
                        ):
                            score = _cosine(query_embedding, json.loads(row["embedding"]))
                            if score > 0:
                                item = (score, row["id"], row)
                                if len(vector_hits) < capacity:
                                    heapq.heappush(vector_hits, item)
                                elif score > vector_hits[0][0]:
                                    heapq.heapreplace(vector_hits, item)
                        for score, ident, row in vector_hits:
                            if ident in matches:
                                old = matches[ident]
                                matches[ident] = (old[0], old[1] + score * .25, *old[2:])
                            elif parsed.intent != "find_definition":
                                matches[ident] = (row, score * .25, None, "uncertain", "embedding similarity")
                    except (OSError, ValueError, RuntimeError, TimeoutError, IndexError):
                        # Optional embeddings leave lexical evidence available.
                        if "client" in locals():
                            model = getattr(client, "last_call", None)
        hits = [self._hit(row, score, symbol=symbol, kind=kind, reason=reason)
                for row, score, symbol, kind, reason in sorted(matches.values(),
                    key=lambda item: (-item[1], item[0]["path"], item[0]["start_line"]))[:max(0, limit)]]
        elapsed = round((time.perf_counter() - started) * 1000, 3)
        return {"query": query, "intent": parsed.intent, "matches": hits,
                "timing": {"retrieval_ms": elapsed, "total_ms": elapsed}, "model": model}

    def symbols(self, name: str) -> list[dict]:
        if not name.strip():
            return []
        with self._connect() as db:
            rows = db.execute(f"SELECT {_FIELDS} FROM chunks c WHERE symbol=? COLLATE NOCASE "
                              "ORDER BY path,start_line", (name,)).fetchall()
        return [self._hit(row, 1.0) for row in rows]

    def file_chunks(self, path: str, limit: int = 4) -> list[dict]:
        """Return the first indexed excerpts for a file, in source order."""
        if limit <= 0:
            return []
        with self._connect() as db:
            rows = db.execute(f"SELECT {_FIELDS} FROM chunks c WHERE path=? "
                              "ORDER BY start_line LIMIT ?", (path, limit)).fetchall()
        return [self._hit(row, 1.0) for row in rows]

    def related(self, path: str) -> list[dict]:
        """Outgoing/imported and incoming references, plus explicit config links.

        Import targets are names from source, not guaranteed resolved file paths.
        Links accept ``from``/``to`` or ``source``/``target`` globs.
        """
        path = path.replace("\\", "/")
        with self._connect() as db:
            known = {row[0] for row in db.execute("SELECT path FROM files")}
            deps = db.execute("SELECT path,line,target,kind FROM dependencies "
                              "ORDER BY path,line,target").fetchall()

        def resolve(origin: str, raw: str, kind: str) -> str | None:
            candidates = [raw]
            if kind == "import" and raw.startswith(".") and not raw.startswith("./"):
                # Python relative imports use leading dots for parent levels.
                dots = len(raw) - len(raw.lstrip("."))
                parent = PurePosixPath(origin).parent
                for _ in range(dots - 1):
                    parent = parent.parent
                candidates.append(str(parent / raw[dots:].replace(".", "/")))
            elif kind == "import" and not raw.startswith(".") and "/" not in raw:
                candidates.append(raw.replace(".", "/"))
            if raw.startswith(".") or kind == "include":
                candidates.append(str(PurePosixPath(origin).parent / raw))
            for candidate in candidates:
                candidate = posixpath.normpath(candidate)
                for suffix in ("", ".py", ".pyi", ".js", ".jsx", ".ts", ".tsx",
                               ".h", ".hpp", ".cpp", "/__init__.py", "/index.js", "/index.ts"):
                    resolved = candidate + suffix
                    if resolved in known:
                        return resolved
            return None

        result = []
        for row in deps:
            resolved = resolve(row["path"], row["target"], row["kind"])
            if row["path"] != path and resolved != path:
                continue
            item = {"path": row["path"], "target": row["target"],
                    "line": row["line"], "kind": row["kind"]}
            if resolved:
                item["resolved_path"] = resolved
            result.append(item)
        for link in self.config.links:
            source = link.get("from", link.get("source"))
            target = link.get("to", link.get("target"))
            if not isinstance(source, str) or not isinstance(target, str):
                continue
            forward = fnmatch.fnmatchcase(path, source)
            backward = fnmatch.fnmatchcase(path, target)
            if forward or backward:
                opposite = target if forward else source
                matched = sorted(p for p in known if fnmatch.fnmatchcase(p, opposite))
                for resolved in matched[:100] or [None]:
                    item = {"path": source, "target": target, "kind": "explicit",
                            **({key: link[key] for key in ("label", "reason") if key in link})}
                    if resolved:
                        item["resolved_path"] = resolved
                    result.append(item)
        return result

    def status(self) -> dict:
        with self._connect() as db:
            files = db.execute("SELECT count(*) FROM files").fetchone()[0]
            chunks = db.execute("SELECT count(*) FROM chunks").fetchone()[0]
            embedded = db.execute("SELECT count(*) FROM chunks WHERE embedding IS NOT NULL").fetchone()[0]
        return {"files": files, "chunks": chunks, "embedded": embedded,
                "database": str(self.db_path)}
