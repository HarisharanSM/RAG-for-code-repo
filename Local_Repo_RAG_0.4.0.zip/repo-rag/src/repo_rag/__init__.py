"""Local repository RAG."""
__version__ = "0.4.0"
