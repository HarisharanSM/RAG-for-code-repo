"""Bounded, local-by-default HTTP adapters for model APIs."""

from __future__ import annotations

from contextlib import contextmanager
from copy import copy
from http.client import HTTPException
import ipaddress
import json
import math
import os
import socket
from time import perf_counter
from urllib import error, parse, request

from .config import Config


_MAX_RESPONSE_BYTES = 16 * 1024 * 1024


class ModelError(RuntimeError):
    """A model request failed or returned an unexpected response."""

    def __init__(self, message: str, error_type: str = "protocol_error"):
        super().__init__(message)
        self.error_type = error_type


class OllamaError(ModelError):
    """An Ollama request failed or returned an unexpected response."""


class OpenAIError(ModelError):
    """An OpenAI-compatible request failed or returned an unexpected response."""


class _NoRedirect(request.HTTPRedirectHandler):
    def __init__(self, error_class=ModelError):
        self.error_class = error_class

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise self.error_class("Model API redirects are disabled", "redirect")


class _HTTPClient:
    provider = ""
    label = "Model API"
    error_class = ModelError
    allow_base_path = False

    def __init__(self, config: Config):
        self.config = config
        self.base_url = self._validate_url(config.llm_url, config.allow_remote_model)
        if (isinstance(config.timeout, bool) or not isinstance(config.timeout, (int, float))
                or not math.isfinite(config.timeout) or config.timeout <= 0):
            raise ValueError("Model timeout must be positive and finite")
        self.last_call: dict | None = None
        # Ignore all environment proxies, including for loopback hostnames.
        self._opener = request.build_opener(
            request.ProxyHandler({}), _NoRedirect(self.error_class),
        )

    @classmethod
    def _validate_url(cls, url: str, allow_remote: bool) -> str:
        if not isinstance(url, str) or any(c.isspace() or ord(c) < 32 for c in url):
            raise ValueError("Invalid model API URL")
        try:
            parts = parse.urlsplit(url)
            host = parts.hostname
            port = parts.port
        except (TypeError, ValueError):
            raise ValueError("Invalid model API URL") from None
        if (parts.scheme not in ("http", "https") or not host or
                parts.username is not None or parts.password is not None or
                parts.query or parts.fragment or port == 0 or "\\" in url):
            raise ValueError("Model API URL must be an HTTP(S) base URL without credentials or query")
        if not cls.allow_base_path and parts.path not in ("", "/"):
            raise ValueError("Ollama URL must not include a path")
        if not allow_remote:
            try:
                loopback = host.lower() == "localhost" or ipaddress.ip_address(host).is_loopback
            except ValueError:
                loopback = False
            if not loopback:
                raise ValueError("Remote model API URL requires allow_remote_model=true")
        return url.rstrip("/")

    @contextmanager
    def _call(self, operation: str, model: str):
        started = perf_counter()
        self.last_call = {
            "provider": self.provider, "model": model, "operation": operation,
            "elapsed_ms": 0.0, "status": "success", "token_usage": None,
        }
        try:
            yield
        except Exception as exc:
            self.last_call["status"] = "error"
            self.last_call["error_type"] = (
                exc.error_type if isinstance(exc, ModelError) else
                "invalid_input" if isinstance(exc, (TypeError, ValueError)) else "client_error"
            )
            raise
        finally:
            self.last_call["elapsed_ms"] = round((perf_counter() - started) * 1000, 3)

    def _fail(self, message: str, error_type: str = "protocol_error") -> ModelError:
        return self.error_class(f"{self.label} {message}", error_type)

    def _post(self, endpoint: str, payload: dict) -> dict:
        headers = {"Content-Type": "application/json", "Accept": "application/json"}
        key_env = getattr(self.config, "api_key_env", "")
        if key_env:
            key = os.environ.get(key_env)
            if not key or any(ord(c) < 32 or ord(c) > 126 for c in key):
                raise self._fail("API key environment variable is unset or invalid", "authentication")
            headers["Authorization"] = "Bearer " + key
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        req = request.Request(self.base_url + endpoint, data=body, headers=headers, method="POST")
        try:
            with self._opener.open(req, timeout=self.config.timeout) as response:
                raw = response.read(_MAX_RESPONSE_BYTES + 1)
        except error.HTTPError as exc:
            code = exc.code
            exc.close()
            raise self._fail(f"returned HTTP {code} for {endpoint}", "http_error") from None
        except (TimeoutError, socket.timeout):
            raise self._fail("request timed out", "timeout") from None
        except error.URLError as exc:
            if isinstance(exc.reason, (TimeoutError, socket.timeout)):
                raise self._fail("request timed out", "timeout") from None
            raise self.error_class(f"Could not reach {self.label}", "connection_error") from None
        except HTTPException:
            raise self._fail("returned an invalid HTTP response") from None
        except OSError:
            raise self.error_class(f"Could not reach {self.label}", "connection_error") from None
        if len(raw) > _MAX_RESPONSE_BYTES:
            raise self._fail("response exceeds 16 MiB", "response_too_large")
        try:
            result = json.loads(raw)
        except (UnicodeDecodeError, ValueError):
            raise self._fail("returned invalid JSON") from None
        if not isinstance(result, dict):
            raise self._fail("returned an unexpected JSON value")
        self._record_usage(result)
        if result.get("error"):
            # Never echo server-controlled strings, which may include credentials.
            # Keep this existing, fixed diagnostic for compatibility.
            reason = "model unavailable" if result["error"] == "model unavailable" else "request failed"
            raise self._fail(reason, "server_error")
        return result

    def _record_usage(self, result: dict) -> None:
        usage = result.get("usage")
        fields = ("prompt_tokens", "completion_tokens", "total_tokens")
        counts = {k: usage[k] for k in fields if isinstance(usage, dict) and k in usage
                  and isinstance(usage[k], int) and not isinstance(usage[k], bool) and usage[k] >= 0}
        if self.provider == "ollama":
            for source, target in (("prompt_eval_count", "prompt_tokens"), ("eval_count", "completion_tokens")):
                value = result.get(source)
                if isinstance(value, int) and not isinstance(value, bool) and value >= 0:
                    counts[target] = value
        if counts and self.last_call is not None:
            self.last_call["token_usage"] = counts

    def _validate_vectors(self, vectors, count: int) -> list[list[float]]:
        if not isinstance(vectors, list) or len(vectors) != count:
            raise self._fail("returned the wrong number of embeddings")
        dimensions = None
        normalized = []
        for vector in vectors:
            if not isinstance(vector, list) or not vector:
                raise self._fail("returned an invalid embedding")
            try:
                valid = all(not isinstance(v, bool) and isinstance(v, (int, float))
                            and math.isfinite(v) for v in vector)
            except OverflowError:
                valid = False
            if not valid:
                raise self._fail("returned an invalid embedding")
            if dimensions is not None and len(vector) != dimensions:
                raise self._fail("returned inconsistent embedding dimensions")
            dimensions = len(vector)
            normalized.append([float(v) for v in vector])
        return normalized

    @staticmethod
    def _validate_texts(texts):
        if not isinstance(texts, list) or any(not isinstance(t, str) for t in texts):
            raise TypeError("texts must be a list of strings")


class OllamaClient(_HTTPClient):
    provider = "ollama"
    label = "Ollama"
    error_class = OllamaError

    def generate(self, prompt: str) -> str:
        with self._call("generate", self.config.model):
            if not isinstance(prompt, str):
                raise TypeError("prompt must be a string")
            result = self._post("/api/generate", {
                "model": self.config.model, "prompt": prompt, "stream": False,
            })
            answer = result.get("response")
            if not isinstance(answer, str):
                raise self._fail("generate response is missing text")
            return answer

    def embed(self, texts: list[str]) -> list[list[float]]:
        model = self.config.embedding_model or self.config.model
        with self._call("embed", model):
            self._validate_texts(texts)
            if not texts:
                return []
            result = self._post("/api/embed", {"model": model, "input": texts})
            return self._validate_vectors(result.get("embeddings"), len(texts))


class OpenAICompatibleClient(_HTTPClient):
    provider = "openai"
    label = "OpenAI-compatible API"
    error_class = OpenAIError
    allow_base_path = True

    def generate(self, prompt: str) -> str:
        with self._call("generate", self.config.model):
            if not isinstance(prompt, str):
                raise TypeError("prompt must be a string")
            result = self._post("/chat/completions", {
                "model": self.config.model,
                "messages": [{"role": "user", "content": prompt}], "stream": False,
            })
            choices = result.get("choices")
            if not isinstance(choices, list) or not choices or not isinstance(choices[0], dict):
                raise self._fail("chat response is missing choices")
            message = choices[0].get("message")
            answer = message.get("content") if isinstance(message, dict) else None
            if not isinstance(answer, str):
                raise self._fail("chat response is missing text")
            return answer

    def embed(self, texts: list[str]) -> list[list[float]]:
        model = self.config.embedding_model or self.config.model
        with self._call("embed", model):
            self._validate_texts(texts)
            if not texts:
                return []
            result = self._post("/embeddings", {
                "model": model, "input": texts, "encoding_format": "float",
            })
            data = result.get("data")
            if not isinstance(data, list) or len(data) != len(texts):
                raise self._fail("returned the wrong number of embeddings")
            ordered = [None] * len(texts)
            seen = set()
            for item in data:
                index = item.get("index") if isinstance(item, dict) else None
                if (not isinstance(index, int) or isinstance(index, bool) or
                        not 0 <= index < len(texts) or index in seen):
                    raise self._fail("returned invalid embedding indices")
                seen.add(index)
                ordered[index] = item.get("embedding")
            return self._validate_vectors(ordered, len(texts))


OpenAIClient = OpenAICompatibleClient


def create_client(config: Config, purpose: str = "generation") -> OllamaClient | OpenAICompatibleClient:
    """Create an adapter using generation settings or embedding overrides."""
    if purpose not in ("generation", "embedding"):
        raise ValueError("Model client purpose must be generation or embedding")
    provider = getattr(config, "provider", "ollama")
    selected = config
    if purpose == "embedding":
        provider = getattr(config, "embedding_provider", "") or provider
        selected = copy(config)
        selected.llm_url = getattr(config, "embedding_url", "") or config.llm_url
        selected.api_key_env = (getattr(config, "embedding_api_key_env", "") or
                                getattr(config, "api_key_env", ""))
    if provider == "ollama":
        return OllamaClient(selected)
    if provider == "openai":
        return OpenAICompatibleClient(selected)
    raise ValueError("Model provider must be ollama or openai")
