from dataclasses import dataclass, field
from pathlib import Path
import tomllib

@dataclass
class Config:
    repo: Path
    state_dir: Path
    llm_url: str = "http://127.0.0.1:11434"
    model: str = "qwen2.5-coder:7b"
    embedding_model: str = ""
    provider: str = "ollama"
    api_key_env: str = ""
    embedding_provider: str = ""
    embedding_url: str = ""
    embedding_api_key_env: str = ""
    logging_enabled: bool = True
    max_file_bytes: int = 1000000
    chunk_lines: int = 80
    context_chars: int = 24000
    timeout: int = 120
    commands: dict[str, list[str]] = field(default_factory=dict)
    links: list[dict] = field(default_factory=list)
    excludes: list[str] = field(default_factory=list)
    allow_remote_model: bool = False

    @classmethod
    def load(cls, path: str | Path):
        path = Path(path).resolve()
        with path.open('rb') as f:
            data = tomllib.load(f)
        root = path.parent
        if 'repo' not in data or not isinstance(data['repo'], str):
            raise ValueError('Configuration requires a repo path string')
        known = set(cls.__dataclass_fields__) - {'state_dir', 'repo'}
        unknown = set(data) - known - {'repo', 'state_dir'}
        if unknown:
            raise ValueError('Unknown configuration keys: ' + ', '.join(sorted(unknown)))
        if not isinstance(data.get('state_dir', '.repo-rag'), str):
            raise ValueError('state_dir must be a path string')
        repo = (root / data.pop('repo')).resolve()
        state = (root / data.pop('state_dir', '.repo-rag')).resolve()
        if repo.is_relative_to(state):
            raise ValueError('state_dir cannot be the repository or its ancestor')
        cfg = cls(repo=repo, state_dir=state, **data)
        if not repo.is_dir():
            raise ValueError(f'Repository does not exist: {repo}')
        for key in ('max_file_bytes', 'chunk_lines', 'context_chars', 'timeout'):
            if isinstance(getattr(cfg, key), bool) or not isinstance(getattr(cfg, key), int):
                raise ValueError(f'{key} must be an integer')
        if not isinstance(cfg.logging_enabled, bool):
            raise ValueError('logging_enabled must be a boolean')
        if any(not isinstance(getattr(cfg, k), str) for k in ('provider', 'api_key_env', 'embedding_provider', 'embedding_url', 'embedding_api_key_env')):
            raise ValueError('Provider settings must be strings')
        if cfg.provider not in ('ollama', 'openai') or cfg.embedding_provider not in ('', 'ollama', 'openai'):
            raise ValueError('Provider must be ollama or openai')
        if not isinstance(cfg.allow_remote_model, bool):
            raise ValueError('allow_remote_model must be a boolean')
        if any(not isinstance(getattr(cfg, key), str) for key in ('llm_url', 'model', 'embedding_model')) or not cfg.model.strip():
            raise ValueError('Model settings must be strings and model must be nonempty')
        if cfg.chunk_lines < 10 or cfg.context_chars < 1000 or cfg.timeout <= 0 or cfg.max_file_bytes <= 0:
            raise ValueError('Invalid size or timeout configuration')
        if not isinstance(cfg.commands, dict) or any(not isinstance(name, str) or not isinstance(argv, list) or not argv or any(not isinstance(a, str) or not a or '\x00' in a for a in argv) for name, argv in cfg.commands.items()):
            raise ValueError('Commands must map names to nonempty argument lists')
        if not isinstance(cfg.links, list) or any(not isinstance(link, dict) for link in cfg.links):
            raise ValueError('Links must be a list of tables')
        if not isinstance(cfg.excludes, list) or any(not isinstance(x, str) for x in cfg.excludes):
            raise ValueError('Excludes must be a list of strings')
        return cfg
